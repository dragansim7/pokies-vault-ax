
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "url": "https://bestpokieslist.online/",
  "name": "Best Pokies List",
  "alternateName": "Best Pokies List Australia"
}


/* ---- */


try { if (sessionStorage.getItem("bplFetcherCollapsed") === "0") document.getElementById("bplFetcher").classList.remove("bf-collapsed"); } catch (e) {}


/* ---- */



"use strict";

const BPL_HOMEPAGE_BUILD = "v11-original-added-dates";
console.info("Best Pokies List homepage:", BPL_HOMEPAGE_BUILD);

const FALLBACK_ICON =

    "data:image/svg+xml," +

    encodeURIComponent(`

        <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64">

            <rect width="64" height="64" rx="12" fill="#161616"/>

            <circle cx="32" cy="32" r="17" fill="none" stroke="#777" stroke-width="4"/>

        </svg>

    `);


const $ = selector => document.querySelector(selector);

const groupsElement = $("#groups");

const emptyElement = $("#empty");


let allDomains = [];

const INTEL_API = "https://intel.bestpokieslist.online";
let domainStatusMap = new Map();
let domainStatusLoaded = false;


let visitedDomains = new Set();


let loggedIn = false;
let currentAccountKey = null;
let walletMode = false;
let walletDataLoaded = false;
let walletDataByDomain = new Map();
let walletIdentityCatalog = [];
let ownReferlinkDomains = new Set();
let walletSavedAt = 0;
let fetcherApplyLock = false;
let fetcherAppliedSnap = "";
let currentMaskedPhone = "";
let visitedSyncInFlight = null;

let notVisitedMode = false;

const VIEW_MODES = ["default", "one", "two"];
let viewMode = "default";

let domainSortMode = "default";
let filterNotVisitedOnly = false;
let filterSignupBonusOnly = false;

// Card bonus display is intentionally OFF by default.
// Allowed values: none, signup, share, commission, referral, rebate.
let bonusDisplayMode = "none";


function normalizeDomain(value) {
    let domain = String(value || "").trim().toLowerCase();
    domain = domain.replace(/^https?:\/\//i, "");
    domain = domain.split("/")[0];
    domain = domain.replace(/^www\./i, "");
    return domain;
}


function letterIcon(domain) {
    const name = String(domain || "?").replace(/^www\./, "");
    const letter = (name.match(/[a-z0-9]/i)?.[0] || "?").toUpperCase();
    let hash = 0;
    for (const ch of name) hash = (hash * 31 + ch.charCodeAt(0)) >>> 0;
    const hue = hash % 360;
    return "data:image/svg+xml," + encodeURIComponent(
        `<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64"><rect width="64" height="64" rx="14" fill="hsl(${hue},55%,32%)"/><text x="32" y="43" text-anchor="middle" font-family="system-ui,-apple-system,Segoe UI,Arial,sans-serif" font-size="32" font-weight="800" fill="#fff">${letter}</text></svg>`
    );
}

function relativeAddedAt(value) {
    if (!value) return "";
    const date = new Date(String(value));
    if (Number.isNaN(date.getTime())) return "";
    const diff = Math.max(0, (Date.now() - date.getTime()) / 1000);
    if (diff < 3600) return diff < 120 ? "Just added" : `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    if (diff < 86400 * 30) return `${Math.floor(diff / 86400)}d ago`;
    const sameYear = date.getFullYear() === new Date().getFullYear();
    return new Intl.DateTimeFormat("en-AU", {timeZone: "Australia/Melbourne", day: "numeric", month: "short", ...(sameYear ? {} : {year: "numeric"})}).format(date);
}

function formatAddedAt(value) {
    if (!value) return "";

    const date = new Date(String(value));
    if (Number.isNaN(date.getTime())) return "";

    const datePart = new Intl.DateTimeFormat(
        "en-AU",
        {
            timeZone:"Australia/Melbourne",
            day:"2-digit",
            month:"2-digit",
            year:"numeric"
        }
    ).format(date);

    const timePart = new Intl.DateTimeFormat(
        "en-AU",
        {
            timeZone:"Australia/Melbourne",
            hour:"numeric",
            minute:"2-digit",
            hour12:true
        }
    ).format(date);

    return `${datePart} • ${timePart}`;
}

async function fetchVisitedDomainsFromServer() {
    if (!loggedIn || !currentAccountKey) {
        visitedDomains = new Set();
        return;
    }

    if (visitedSyncInFlight) {
        return visitedSyncInFlight;
    }

    visitedSyncInFlight = (async () => {
        const response = await fetch(
            "api/visited.php?t=" + Date.now(),
            {
                cache:"no-store",
                credentials:"same-origin"
            }
        );

        const result = await response.json();

        if (!response.ok || !result.ok) {
            throw new Error(result.error || `Visited API HTTP ${response.status}`);
        }

        if (String(result.accountKey || "") !== String(currentAccountKey || "")) {
            throw new Error("Visited account mismatch.");
        }

        visitedDomains = new Set(
            (Array.isArray(result.visited) ? result.visited : [])
                .map(normalizeDomain)
                .filter(Boolean)
        );
    })();

    try {
        await visitedSyncInFlight;
    } finally {
        visitedSyncInFlight = null;
    }
}

async function syncVisitedDomainsAndRefresh() {
    if (!loggedIn || !currentAccountKey) return;

    try {
        await fetchVisitedDomainsFromServer();
        if (notVisitedMode) {
            render();
        } else {
            updateProgress();
        }
    } catch (error) {
        console.error("Visited sync failed:", error);
    }
}

function statusLabel(info){
    if(!info) return {text:"Unknown",cls:"",title:"No VPS status available"};

    const status=String(info.status||"live").toLowerCase();

    if(status==="dead"){
        return {
            text:"Dead",
            cls:"dead",
            title:info.reason||"Domain is currently unreachable"
        };
    }

    if(status==="redirect"){
        const target=info.finalDomain && info.finalDomain!==info.domain
            ? ` → ${info.finalDomain}`
            : "";
        return {
            text:"Redirected",
            cls:"redirect",
            title:`Redirects${target}`
        };
    }

    if(status==="slow"){
        return {
            text:"Slow",
            cls:"slow",
            title:info.responseMs
                ? `Responded in ${info.responseMs} ms`
                : "Domain is responding slowly"
        };
    }

    return {
        text:"Live",
        cls:"live",
        title:info.responseMs
            ? `Responded in ${info.responseMs} ms`
            : "Domain is live"
    };
}

function applyDomainStatus(element,domainKey){
    if(!element) return;

    const info=domainStatusMap.get(normalizeDomain(domainKey));
    const label=statusLabel(info);

    element.className=`domain-status ${label.cls}`;
    element.title=label.title;
    element.replaceChildren(document.createTextNode(label.text));
    if(label.cls==="dead"){
        const fix=document.createElement("button");
        fix.type="button";
        fix.className="tld-fix";
        fix.textContent="New TLD";
        fix.title="If this casino works on a different ending, update this card.";
        fix.addEventListener("click",event=>{
            event.preventDefault();
            event.stopPropagation();
            openCommunityAddCorrection(normalizeDomain(domainKey));
        });
        element.append(fix);
    }
}

function refreshVisibleDomainStatuses(){
    document
        .querySelectorAll("[data-status-domain]")
        .forEach(element=>{
            applyDomainStatus(
                element,
                element.dataset.statusDomain
            );
        });
}

function applyBestStatusFilter() {
    if (applyBestStatusFilter.done) return;
    if (typeof viewMode === "undefined" || viewMode !== "default" || (typeof sortFilterIsActive === "function" && sortFilterIsActive())) return;
    if ((window.scrollY || 0) > 80) return;
    applyBestStatusFilter.done = true;
    if (typeof render === "function") render();
}

async function loadDomainStatuses(){
    const cacheKey="bpl-domain-status-v1";
    const controller=new AbortController();
    const timeout=setTimeout(()=>controller.abort(),5000);

    try{
        const response=await fetch(
            INTEL_API + "/public/statuses",
            {
                cache:"no-store",
                signal:controller.signal
            }
        );

        if(!response.ok){
            throw new Error(`HTTP ${response.status}`);
        }

        const payload=await response.json();
        const rows=Array.isArray(payload.domains)
            ? payload.domains
            : [];

        domainStatusMap=new Map(
            rows.map(row=>[
                normalizeDomain(row.domain),
                row
            ])
        );

        domainStatusLoaded=true;

        try{
            localStorage.setItem(
                cacheKey,
                JSON.stringify({
                    savedAt:Date.now(),
                    domains:rows
                })
            );
        }catch(_){}

        refreshVisibleDomainStatuses();
        applyBestStatusFilter();

        // Anything not represented in the VPS snapshot becomes Unknown,
        // never permanently "Checking".
        document
            .querySelectorAll("[data-status-domain]")
            .forEach(element=>{
                const key=normalizeDomain(
                    element.dataset.statusDomain
                );

                if(!domainStatusMap.has(key)){
                    element.className="domain-status";
                    element.textContent="Unknown";
                    element.title="No current VPS status available";
                }
            });

    }catch(error){
        console.warn("Domain status load failed:",error);

        // If the network/VPS briefly fails, reuse the most recently
        // downloaded snapshot from this browser.
        let restored=false;

        try{
            const cached=JSON.parse(
                localStorage.getItem(cacheKey) || "null"
            );

            if(
                cached &&
                Array.isArray(cached.domains) &&
                cached.domains.length
            ){
                domainStatusMap=new Map(
                    cached.domains.map(row=>[
                        normalizeDomain(row.domain),
                        row
                    ])
                );

                domainStatusLoaded=true;
                refreshVisibleDomainStatuses();
        applyBestStatusFilter();
                restored=true;
            }
        }catch(_){}

        if(!restored){
            document
                .querySelectorAll("[data-status-domain]")
                .forEach(element=>{
                    element.className="domain-status";
                    element.textContent="Unknown";
                    element.title="Domain Intelligence status unavailable";
                });
        }

    }finally{
        clearTimeout(timeout);

        // Final safety net: there should never be a card left indefinitely
        // saying Checking.
        document
            .querySelectorAll(".domain-status.checking")
            .forEach(element=>{
                element.className="domain-status";
                element.textContent="Unknown";
                element.title="No current VPS status available";
            });
    }
}

function moneyText(value) {
    const n = Number(value);
    if (!Number.isFinite(n)) return "";
    return new Intl.NumberFormat("en-AU", {
        style:"currency",
        currency:"AUD",
        minimumFractionDigits: n % 1 === 0 ? 0 : 2,
        maximumFractionDigits:2
    }).format(n);
}

function withdrawalValueText(value) {
    const n = Number(value);
    return Number.isFinite(n) && n > 0 ? moneyText(n) : "—";
}

function walletFreshnessText(savedAt) {
    const ts = Number(savedAt || 0);
    if (!Number.isFinite(ts) || ts <= 0) return "No saved fetch time";

    const now = Date.now() / 1000;
    const seconds = Math.max(0, now - ts);
    const mins = Math.floor(seconds / 60);
    const hours = Math.floor(mins / 60);
    const days = Math.floor(hours / 24);

    if (mins < 1) return "Fetched just now";
    if (mins < 60) return `Fetched ${mins} min ago`;
    if (hours < 24) return `Fetched ${hours} hr${hours === 1 ? "" : "s"} ago`;
    if (days < 7) return `Fetched ${days} day${days === 1 ? "" : "s"} ago`;

    return "Fetched " + new Intl.DateTimeFormat("en-AU", {
        day:"numeric",
        month:"short",
        hour:"numeric",
        minute:"2-digit"
    }).format(new Date(ts * 1000));
}

function friendlyWalletError(row) {
    const reason = String(row?.errorReason || "").trim();
    const type = String(row?.errorType || "").trim().toLowerCase();

    // Error cooldown: show the full "Skipped · last result: … 2h ago · retry in 2d" note.
    if (type === "skipped") return reason || "Skipped (recent errors)";
    if (/invalid\s*login/i.test(reason) || type === "invalid_login" || type === "invalid") {
        return "Invalid login";
    }
    if (/captcha/i.test(reason) || type === "captcha") return "CAPTCHA required";
    if (reason) return reason.length > 42 ? reason.slice(0, 39) + "…" : reason;
    return "Fetch error";
}

let walletLoadPromise = null;
let walletLoadedAt = 0;
async function loadWalletData() {
    if (!loggedIn) return;
    if (walletLoadPromise) return walletLoadPromise;
    if (walletDataLoaded && Date.now() - walletLoadedAt < 20000) return;
    walletLoadPromise = loadWalletDataNow().finally(() => { walletLoadPromise = null; });
    return walletLoadPromise;
}
window.bplLoadAccountData = loadWalletData;

async function loadWalletDataNow() {
    if (!loggedIn) return;
    const response = await fetch("api/account-data.php", {cache:"no-store", credentials:"same-origin"});
    const result = await response.json();
    if (!response.ok || !result.ok) throw new Error(result.error || "Could not load wallet data.");

    walletDataByDomain = new Map();
    walletIdentityCatalog = Array.isArray(result.identities) ? result.identities : [];
    for (const row of Array.isArray(result.rows) ? result.rows : []) {
        const key = normalizeDomain(row.domain || "");
        if (!key) continue;
        const list = walletDataByDomain.get(key) || [];
        list.push(row);
        walletDataByDomain.set(key, list);
    }
    ownReferlinkDomains = new Set(
        (Array.isArray(result.ownReferlinkDomains) ? result.ownReferlinkDomains : [])
            .map(d => normalizeDomain(d || ""))
            .filter(Boolean)
    );
    walletSavedAt = Number(result.savedAt || 0);
    walletDataLoaded = true;
    walletLoadedAt = Date.now();
    fetcherAppliedSnap = "";
    if (typeof window.bplOnAccountData === "function") window.bplOnAccountData(result);
}

function walletRowSnap(row) {
    const bonus = value => {
        if (!value || typeof value !== "object") return "";
        return [value.amount, value.minWithdrawal, value.maxWithdrawal, value.minBet, JSON.stringify(value.descriptionTags || [])].join(",");
    };
    const extras = Array.isArray(row?.availableBonuses) ? row.availableBonuses : [];
    return [
        normalizeDomain(row?.domain || ""),
        String(row?.casinoIdentity || "").replace(/\D/g, ""),
        row?.fetchState || "",
        row?.cash ?? "",
        row?.cashMinWithdrawal ?? "",
        row?.cashMaxWithdrawal ?? "",
        row?.errorType || "",
        row?.errorReason || "",
        row?.httpCode || "",
        row?.skippedNote || "",
        bonus(row?.commission),
        bonus(row?.share),
        bonus(row?.referral),
        bonus(row?.new),
        bonus(row?.rebate),
        extras.map(bonus).join(";")
    ].join("|");
}

function collectFetcherWalletRows(payload) {
    const out = [];
    const success = [...(payload?.rows || []), ...(payload?.emptyRows || [])];
    for (const row of success) {
        if (!row || typeof row !== "object") continue;
        out.push({
            ...row,
            fetchState: "success",
            casinoIdentity: String(row.casinoIdentity || "").replace(/\D/g, "")
        });
    }
    for (const row of payload?.errors || []) {
        if (!row || typeof row !== "object") continue;
        out.push({
            domain: row.domain || "",
            casinoIdentity: String(row.casinoIdentity || "").replace(/\D/g, ""),
            fetchState: "error",
            errorType: row.type || row.errorType || "",
            errorReason: row.reason || row.errorReason || "",
            httpCode: row.httpCode || ""
        });
    }
    return out;
}

function showFetcherFoldNote(note) {
    const counts = document.getElementById("bplFetcherDoneCounts");
    if (counts) counts.textContent = note || "";
    document.getElementById("bplFetcherDone")?.classList.remove("hidden");
}

function fetchedDomainsMissingFrom(items) {
    const known = new Set((items || []).map(item => normalizeDomain(item?.domain)));
    const extras = [];
    for (const [domain, list] of walletDataByDomain) {
        if (!domain || known.has(domain)) continue;
        const row = Array.isArray(list) ? list[0] : list;
        extras.push({
            domain: String(row?.domain || domain),
            url: "https://" + domain,
            group: "Fetched",
            addedAt: "",
            community: 0,
            external: true
        });
    }
    extras.sort((a, b) => a.domain.localeCompare(b.domain));
    return extras;
}

/* Live fetcher rows replace the saved wallet map and paint onto the homepage cards. */
window.bplApplyFetcherRows = function (payload) {
    if (fetcherApplyLock || !loggedIn || !payload) return;

    const incoming = collectFetcherWalletRows(payload);
    const snap = incoming.map(walletRowSnap).sort().join("\n");
    const dataChanged = snap !== fetcherAppliedSnap;
    const reveal = Boolean(payload.reveal);

    if (dataChanged) {
        fetcherAppliedSnap = snap;
        walletDataByDomain = new Map();
        for (const row of incoming) {
            const key = normalizeDomain(row.domain || "");
            if (!key) continue;
            const bucket = walletDataByDomain.get(key) || [];
            bucket.push(row);
            walletDataByDomain.set(key, bucket);
        }
        if (Array.isArray(payload.identities) && payload.identities.length) {
            walletIdentityCatalog = payload.identities
                .map(id => ({casinoIdentity: String(id || "").replace(/\D/g, "")}))
                .filter(item => item.casinoIdentity);
        }
        walletDataLoaded = incoming.length > 0;
        walletLoadedAt = Date.now();
        if (!walletSavedAt) walletSavedAt = Math.floor(Date.now() / 1000);
    }

    let turnedOn = false;
    if (reveal) {
        showFetcherFoldNote(payload.note || "");
        if (incoming.length && restoreWalletSort()) turnedOn = true;
        if (!walletMode || viewMode === "default") {
            walletMode = true;
            if (viewMode === "default") viewMode = "one";
            turnedOn = true;
            updateViewButton();
            updateWalletButton();
        }
    }

    if ((!dataChanged && !turnedOn) || !walletMode) return;

    const scrollY = window.scrollY;
    fetcherApplyLock = true;
    try {
        updateWalletButton();
        render();
    } finally {
        fetcherApplyLock = false;
    }
    if (payload.scroll) {
        document.getElementById("groups")?.scrollIntoView({behavior:"smooth", block:"start"});
    } else {
        window.scrollTo(0, scrollY);
    }
};

function updateWalletButton() {
    const button = document.getElementById("walletButton");
    if (!button) return;

    button.classList.toggle("active-wallet", walletMode);

    if (walletMode) {
        button.innerHTML = `<span>💰 Wallets: On</span><small class="wallet-freshness">${walletFreshnessText(walletSavedAt)}</small>`;
        button.title = walletFreshnessText(walletSavedAt);
    } else {
        button.textContent = "💰 Wallets: Off";
        button.title = "Show saved wallet balances on domain cards";
    }
}

function viewModeLabel(mode) {
    if (mode === "one") return "1 Column";
    if (mode === "two") return "2 Columns";
    return "Default";
}

function updateViewButton() {
    const button = document.getElementById("viewButton");
    if (!button) return;
    button.textContent = `👁 View: ${viewModeLabel(viewMode)}`;
    button.classList.toggle("active", viewMode !== "default");
    button.title = viewMode === "default"
        ? "Original homepage sections"
        : `All domains in a compact ${viewModeLabel(viewMode)} layout`;
}

/* BPL_BONUS_ONE_COLUMN: bonus views (Bonus display / "Chosen bonus"
   sorts) only work in 1 column. Multi-column = any view other than
   Default and 1 Column. */
function viewIsMultiColumn(mode) {
    return mode !== "default" && mode !== "one";
}

function bonusViewActive() {
    return bonusDisplayMode !== "none" || sortRequiresSelectedBonus(domainSortMode);
}

function bplViewToast(text) {
    let toast = document.getElementById("bplViewToast");
    if (!toast) {
        toast = document.createElement("div");
        toast.id = "bplViewToast";
        toast.setAttribute("role", "status");
        toast.setAttribute("aria-live", "polite");
        toast.style.cssText = "position:fixed;left:50%;bottom:calc(18px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);z-index:2147483000;max-width:calc(100vw - 32px);padding:9px 14px;border-radius:12px;background:#121218;color:#fff;font-size:.8rem;font-weight:700;line-height:1.3;text-align:center;border:1px solid rgba(255,255,255,.14);box-shadow:0 8px 24px rgba(0,0,0,.55);pointer-events:none;opacity:0;transition:opacity .2s ease";
        document.body.append(toast);
    }
    toast.textContent = text;
    toast.style.opacity = "1";
    clearTimeout(bplViewToast.timer);
    bplViewToast.timer = setTimeout(() => { toast.style.opacity = "0"; }, 2600);
}

function setViewMode(nextMode, {turnWalletOffOnDefault = true} = {}) {
    if (!VIEW_MODES.includes(nextMode)) nextMode = "default";
    if (viewIsMultiColumn(nextMode) && bonusViewActive()) {
        bonusDisplayMode = "none";
        if (sortRequiresSelectedBonus(domainSortMode)) domainSortMode = "default";
        if (typeof syncSortFilterForm === "function") syncSortFilterForm();
        updateSortFilterButton();
        bplViewToast("Bonus set to None \u2014 bonus view needs 1 column");
        viewMode = nextMode;
        rememberWalletSort();
    }
    viewMode = nextMode;
    if (viewMode === "default" && walletMode && turnWalletOffOnDefault) {
        walletMode = false;
        updateWalletButton();
    }
    updateViewButton();
    render();
}

function cycleViewMode() {
    const index = VIEW_MODES.indexOf(viewMode);
    const next = VIEW_MODES[(index + 1) % VIEW_MODES.length];

    /*
     * Returning to Default must mean the real curated homepage again.
     * An active sort/filter/bonus display forces render() into the flat
     * catalogue, so clear those list-level modes before switching back.
     */
    if (next === "default") {
        domainSortMode = "default";
        filterNotVisitedOnly = false;
        filterSignupBonusOnly = false;
        bonusDisplayMode = "none";
        updateSortFilterButton();
    }

    setViewMode(next);
}


function walletRowsForDomain(domain) {
    const value = walletDataByDomain.get(normalizeDomain(domain || ""));
    if (!value) return [];
    return Array.isArray(value) ? value : [value];
}

function walletRowForItem(item) {
    if (item?.walletRow) return item.walletRow;
    const rows = walletRowsForDomain(item?.domain);
    if (item?.casinoIdentity) {
        const match = rows.find(row =>
            String(row?.casinoIdentity || "") === String(item.casinoIdentity)
        );
        if (match) return match;
    }
    return rows[0] || null;
}

function casinoAccountLabel(identity) {
    const exact = String(identity || "").replace(/\D/g, "");
    const known = walletIdentityCatalog.find(item =>
        String(item?.casinoIdentity || "") === exact
    );
    if (known?.label) return String(known.label);
    if (!exact) return "";
    const ordered = walletIdentityCatalog
        .map(item => String(item?.casinoIdentity || ""))
        .filter(Boolean);
    const extras = [...new Set(
        [...walletDataByDomain.values()]
            .flat()
            .map(row => String(row?.casinoIdentity || ""))
            .filter(value => value && !ordered.includes(value))
    )].sort();
    const index = ordered.includes(exact)
        ? ordered.indexOf(exact)
        : ordered.length + extras.indexOf(exact);
    const last4 = exact.slice(-4);
    return `Account ${index + 1} · ••••${last4}`;
}

function expandCasinoIdentityCards(items) {
    const expanded = [];

    for (const item of items) {
        const rows = walletRowsForDomain(item.domain);
        const identities = [...new Set(
            rows.map(row => String(row?.casinoIdentity || "")).filter(Boolean)
        )];

        if (identities.length < 2) {
            expanded.push(item);
            continue;
        }

        for (const row of rows) {
            expanded.push({
                ...item,
                casinoIdentity: String(row.casinoIdentity || ""),
                walletRow: row
            });
        }
    }

    return expanded;
}

function signupBonusForDomain(item) {
    const row = walletRowForItem(item);
    if (!row || row.fetchState === "error") return null;
    const bonus = row.new;
    if (!bonus || typeof bonus !== "object") return null;

    const amount = Number(bonus.amount);
    if (!Number.isFinite(amount) || amount <= 0) return null;

    return bonus;
}

function signupTurnoverValue(bonus) {
    if (!bonus) return Number.POSITIVE_INFINITY;

    const explicit = Number(bonus.turnover);
    if (Number.isFinite(explicit) && explicit >= 0) {
        return explicit;
    }

    /*
     * Match Bonus Fetcher exactly:
     * turnover = minimum withdrawal / bonus amount.
     */
    const amount = Number(bonus.amount || 0);
    const minimum = Number(bonus.minWithdrawal);

    if (!(amount > 0) || !Number.isFinite(minimum) || minimum < 0) {
        return Number.POSITIVE_INFINITY;
    }

    return minimum / amount;
}

function addedAtTimestamp(item) {
    const raw = String(item?.addedAt || "").trim();
    if (!raw) return 0;

    const time = new Date(raw).getTime();
    return Number.isFinite(time) ? time : 0;
}

function sortRequiresAccountData(mode) {
    return [
        "balance_desc",
        "best_turnover_asc",
        "wallet_min_asc",
        "error_type",
        "selected_bonus_amount_desc",
        "selected_bonus_max_desc",
        "selected_bonus_turnover_asc"
    ].includes(mode);
}

function sortRequiresSelectedBonus(mode) {
    return [
        "selected_bonus_amount_desc",
        "selected_bonus_max_desc",
        "selected_bonus_turnover_asc"
    ].includes(mode);
}

function sortFilterNeedsAccountData() {
    return (
        sortRequiresAccountData(domainSortMode) ||
        filterSignupBonusOnly ||
        bonusDisplayMode !== "none"
    );
}

function sortFilterIsActive() {
    return (
        domainSortMode !== "default" ||
        filterNotVisitedOnly ||
        filterSignupBonusOnly ||
        bonusDisplayMode !== "none"
    );
}

/*
 * Sort memory (per browser). A plain page load always starts on the
 * default sort; a sort chosen while wallet results are showing is saved
 * and restored the next time wallet results load (fresh fetch or
 * View last fetch).
 */
const WALLET_SORT_MEMORY_KEY = "bplWalletSortV1";
const WALLET_SORT_BONUS_MODES = ["none", "signup", "share", "commission", "referral", "rebate"];

function rememberWalletSort() {
    if (!walletMode) return;
    try {
        if (domainSortMode === "default" && bonusDisplayMode === "none") {
            localStorage.removeItem(WALLET_SORT_MEMORY_KEY);
        } else {
            localStorage.setItem(WALLET_SORT_MEMORY_KEY, JSON.stringify({
                sort: domainSortMode,
                bonus: bonusDisplayMode,
                savedAt: Date.now()
            }));
        }
    } catch (error) {}
}

function restoreWalletSort() {
    /* Never override a sort the user already picked on this page. */
    if (domainSortMode !== "default" || bonusDisplayMode !== "none") return false;
    let saved = null;
    try {
        saved = JSON.parse(localStorage.getItem(WALLET_SORT_MEMORY_KEY) || "null");
    } catch (error) {
        saved = null;
    }
    if (!saved || typeof saved !== "object") return false;
    const sort = String(saved.sort || "default");
    const bonus = WALLET_SORT_BONUS_MODES.includes(saved.bonus) ? saved.bonus : "none";
    const known = sort === "default" || Boolean(
        document.querySelector(`input[name="domainSort"][value="${CSS.escape(sort)}"]`)
    );
    if (!known) return false;
    if (sortRequiresSelectedBonus(sort) && bonus === "none") return false;
    if (sort === "default" && bonus === "none") return false;
    domainSortMode = sort;
    bonusDisplayMode = bonus;
    if (bonusViewActive() && viewIsMultiColumn(viewMode)) {
        viewMode = "one";
        updateViewButton();
    }
    if (typeof syncSortFilterForm === "function") syncSortFilterForm();
    updateSortFilterButton();
    return true;
}

function accountErrorText(row) {
    return `${String(row?.errorType || "")} ${String(row?.errorReason || "")}`
        .trim()
        .toLowerCase();
}

function isInvalidAccountError(row) {
    if (!row || row.fetchState !== "error") return false;

    const text = accountErrorText(row);
    const httpCode = Number(row?.httpCode);

    const type = String(row?.errorType || "").trim().toLowerCase();
    return (
        type === "invalid_login" ||
        type === "invalid" ||
        text.includes("invalid access") ||
        text.includes("invalid login") ||
        text.includes("invalid_login") ||
        text.includes("invalid credential") ||
        text.includes("wrong credential") ||
        text.includes("invalid account") ||
        text.includes("account not found") ||
        text.includes("user not found") ||
        text.includes("no account") ||
        text.includes("unauthorized") ||
        text.includes("not authenticated") ||
        text.includes("authentication failed") ||
        text.includes("please login") ||
        text.includes("please log in") ||
        ((httpCode === 401 || httpCode === 403) && type !== "network")
    );
}

function cardNeedsAttention(item) {
    const row = walletRowForItem(item);
    const needsLink = typeof window.bplNeedsReferralLink === "function"
        && window.bplNeedsReferralLink(item?.domain);
    return isInvalidAccountError(row) || needsLink;
}

window.bplCardNeedsAttention = function (walletRow, needsLink) {
    return isInvalidAccountError(walletRow) || !!needsLink;
};

function accountErrorPriority(row) {
    // Likely no account / wrong credentials first.
    if (isInvalidAccountError(row)) return 0;

    // Every other actual fetch error directly underneath.
    if (row?.fetchState === "error") return 1;

    // Successful account fetches after errors.
    if (row?.fetchState === "success") return 2;

    // Domains absent from the saved fetch result go last.
    return 3;
}


let domainSearchQuery = "";

function normalizeDomainSearch(value) {
    let text = String(value || "")
        .toLowerCase()
        .trim();

    /*
     * Allow people to paste a complete casino URL.
     */
    text = text
        .replace(/^https?:\/\//i, "")
        .replace(/^www\./i, "")
        .split(/[/?#]/, 1)[0];

    /*
     * Smart/fuzzy form:
     * "true blue 777", "true-blue777" and
     * "trueblue777" all become comparable.
     */
    return text.replace(/[^a-z0-9]/g, "");
}

function domainSearchForms(item) {
    const rawDomain =
        String(item?.domain || "")
            .toLowerCase()
            .trim();

    const normalizedDomain =
        normalizeDomainSearch(rawDomain);

    /*
     * Also index the URL in case an item's displayed
     * domain and actual URL differ.
     */
    const rawUrl =
        String(item?.url || "")
            .toLowerCase()
            .trim();

    const normalizedUrl =
        normalizeDomainSearch(rawUrl);

    const rawAliases = Array.isArray(item?.aliases)
        ? item.aliases.map(value => String(value || "").toLowerCase().trim()).filter(Boolean)
        : [];
    const normalizedAliases = rawAliases.map(normalizeDomainSearch).filter(Boolean);

    return {
        rawDomain,
        normalizedDomain,
        rawUrl,
        normalizedUrl,
        rawAliases,
        normalizedAliases
    };
}

function domainMatchesSearch(item, query) {
    const rawQuery =
        String(query || "")
            .toLowerCase()
            .trim();

    if (!rawQuery) {
        return true;
    }

    const normalizedQuery =
        normalizeDomainSearch(rawQuery);

    if (!normalizedQuery) {
        return true;
    }

    const forms =
        domainSearchForms(item);

    /*
     * Straight substring matching handles partial names:
     *
     * bon      -> bonzaau.com
     * slotuna  -> slotunabets.com
     * 777      -> trueblue777au.com
     */
    const aliasHaystack = forms.normalizedAliases || [];
    if (
        forms.normalizedDomain.includes(normalizedQuery) ||
        forms.normalizedUrl.includes(normalizedQuery) ||
        aliasHaystack.some(alias => alias.includes(normalizedQuery))
    ) {
        return true;
    }

    /*
     * Token matching makes spaced searches forgiving.
     * Every meaningful token must occur somewhere in
     * the normalized domain/URL.
     */
    const tokens =
        rawQuery
            .replace(/^https?:\/\//i, "")
            .replace(/^www\./i, "")
            .split(/[^a-z0-9]+/)
            .map(normalizeDomainSearch)
            .filter(Boolean);

    if (!tokens.length) {
        return true;
    }

    return tokens.every(token =>
        forms.normalizedDomain.includes(token) ||
        forms.normalizedUrl.includes(token) ||
        aliasHaystack.some(alias => alias.includes(token))
    );
}

function updateDomainSearchClearButton() {
    const clear =
        document.getElementById(
            "domainSearchClear"
        );

    if (!clear) {
        return;
    }

    clear.classList.toggle(
        "hidden",
        domainSearchQuery.trim() === ""
    );
}

function prepareDomainsForDisplay(items) {
    const extras = walletMode ? fetchedDomainsMissingFrom(items) : [];
    // Keep one visible card per casino domain. Account-specific fetch rows remain
    // available to walletRowForItem() for badges, sorting and error details.
    let result = extras.length ? items.concat(extras) : items;

    if (domainSearchQuery.trim()) {
        result = result.filter(item =>
            domainMatchesSearch(
                item,
                domainSearchQuery
            )
        );
    }

    if (filterNotVisitedOnly) {
        result = result.filter(item =>
            !visitedDomains.has(normalizeDomain(item.domain))
        );
    }

    if (filterSignupBonusOnly) {
        result = result.filter(item =>
            Boolean(signupBonusForDomain(item))
        );
    }

    const originalIndex = new Map(
        items.map((item, index) => [normalizeDomain(item.domain), index])
    );

    const fallbackOrder = item =>
        originalIndex.get(normalizeDomain(item.domain)) ?? Number.MAX_SAFE_INTEGER;

    if (domainSortMode === "default") {
        result.sort((a, b) => (isDeadItem(a) - isDeadItem(b)) || (fallbackOrder(a) - fallbackOrder(b)));
        return scamLast(result);
    }

    result.sort((a, b) => compareDisplayItems(a, b, fallbackOrder(a) - fallbackOrder(b)));

    return scamLast(result);
}

function bestTurnoverOfRow(row) {
    if (!row || row.fetchState === "error") return Number.POSITIVE_INFINITY;
    const values = [];
    const consider = bonus => {
        const turn = signupTurnoverValue(bonus);
        if (Number.isFinite(turn) && turn < Number.POSITIVE_INFINITY) values.push(turn);
    };
    for (const key of ["commission", "share", "referral", "new", "rebate"]) {
        if (row[key] && typeof row[key] === "object") consider(row[key]);
    }
    const extras = Array.isArray(row.availableBonuses) ? row.availableBonuses : [];
    extras.forEach(consider);
    return values.length ? Math.min(...values) : Number.POSITIVE_INFINITY;
}

function isDeadItem(item) {
    const d = normalizeDomain((item && item.domain) || "");
    if (!d) return 0;
    const info = domainStatusMap.get(d);
    return (info && String(info.status || "").toLowerCase() === "dead") ? 1 : 0;
}

// A rate label such as "5%" is never a claimable dollar value.
function bonusDisplayIsRate(display) {
    return String(display ?? "").includes("%");
}

function bonusHasRealAmount(bonus) {
    if (!bonus || typeof bonus !== "object") return false;
    const amt = Number(bonus.amount);
    if (Number.isFinite(amt) && amt > 0) return true;
    if (bonus.amount && typeof bonus.amount === "object") {
        const mn = Number(bonus.amount.min);
        const mx = Number(bonus.amount.max);
        if ((Number.isFinite(mx) && mx > 0) || (Number.isFinite(mn) && mn > 0)) return true;
    }
    const disp = bonus.amountDisplay;
    if (disp !== undefined && disp !== null && !bonusDisplayIsRate(disp)) {
        const raw = String(disp).trim();
        if (raw && raw !== "\u2014" && raw !== "-" && /[1-9]/.test(raw)) return true;
    }
    return false;
}

function bonusAmountValue(bonus) {
    if (!bonus || typeof bonus !== "object") return NaN;
    const amt = Number(bonus.amount);
    if (Number.isFinite(amt) && amt > 0) return amt;
    if (bonus.amount && typeof bonus.amount === "object") {
        const mx = Number(bonus.amount.max);
        if (Number.isFinite(mx) && mx > 0) return mx;
        const mn = Number(bonus.amount.min);
        if (Number.isFinite(mn) && mn > 0) return mn;
    }
    const disp = bonus.amountDisplay;
    if (disp !== undefined && disp !== null && !bonusDisplayIsRate(disp)) {
        const match = String(disp).replace(/^\s*\$/, "").match(/\d+(?:\.\d+)?/);
        if (match) {
            const v = Number(match[0]);
            if (Number.isFinite(v) && v > 0) return v;
        }
    }
    return NaN;
}

function rowHasAnyBonus(row) {
    if (!row || row.fetchState === "error") return false;
    for (const key of ["commission", "share", "referral", "new", "rebate"]) {
        if (bonusHasRealAmount(row[key])) return true;
    }
    const extras = Array.isArray(row.availableBonuses) ? row.availableBonuses : [];
    for (const extra of extras) {
        if (bonusHasRealAmount(extra)) return true;
    }
    return false;
}

function sortPrimaryValue(mode, row, item) {
    if (mode === "balance_desc") {
        const v = Number(row?.cash);
        return {val: v, has: Number.isFinite(v), asc: false};
    }
    if (mode === "best_turnover_asc") {
        const v = bestTurnoverOfRow(row);
        return {val: v, has: Number.isFinite(v) && v < Number.POSITIVE_INFINITY, asc: true};
    }
    if (mode === "wallet_min_asc") {
        const v = Number(row?.cashMinWithdrawal);
        return {val: v, has: Number.isFinite(v) && v > 0, asc: true};
    }
    if (mode === "selected_bonus_amount_desc") {
        const v = bonusAmountValue(selectedBonusFromRow(row));
        return {val: v, has: Number.isFinite(v) && v > 0, asc: false};
    }
    if (mode === "selected_bonus_max_desc") {
        const v = Number(selectedBonusFromRow(row)?.maxWithdrawal);
        return {val: v, has: Number.isFinite(v) && v > 0, asc: false};
    }
    if (mode === "selected_bonus_turnover_asc") {
        const v = signupTurnoverValue(selectedBonusFromRow(row));
        return {val: v, has: Number.isFinite(v) && v < Number.POSITIVE_INFINITY, asc: true};
    }
    if (mode === "recent_desc") {
        const v = addedAtTimestamp(item);
        return {val: v, has: Number.isFinite(v) && v > 0, asc: false};
    }
    if (mode === "community_desc") {
        const v = Number(item?.community || 0);
        return {val: v, has: v > 0, asc: false};
    }
    return null;
}

function sortBottomTier(has, row) {
    // 0 has-metric, 1 no-metric-has-bonus, 2 no-bonus, 3 error (dead handled before this)
    if (row && row.fetchState === "error") return 3;
    if (!has) return rowHasAnyBonus(row) ? 1 : 2;
    return 0;
}

function compareDisplayItems(a, b, fallbackDelta) {
    const aRow = walletRowForItem(a);
    const bRow = walletRowForItem(b);
    const domainOptions = {numeric:true, sensitivity:"base"};
    const azDelta = () =>
        String(a.domain || "").localeCompare(String(b.domain || ""), undefined, domainOptions) || fallbackDelta;

    const deadDelta = isDeadItem(a) - isDeadItem(b);
    if (deadDelta) return deadDelta;

    if (domainSortMode === "domain_asc") {
        return azDelta();
    }
    if (domainSortMode === "domain_desc") {
        return String(b.domain || "").localeCompare(String(a.domain || ""), undefined, domainOptions) || fallbackDelta;
    }
    if (domainSortMode === "error_type") {
        const ae = aRow?.fetchState === "error";
        const be = bRow?.fetchState === "error";
        if (ae !== be) return ae ? -1 : 1;
        if (ae && be) {
            const order = friendlyWalletError(aRow).toLowerCase().localeCompare(
                friendlyWalletError(bRow).toLowerCase()
            );
            if (order) return order;
        }
        return azDelta();
    }
    if (domainSortMode === "account_no_referlink") {
        /* Same flag the card uses for "Add your link" (homepage-phase1.js):
           cards with no link of yours first, "Your link" cards last.
           Logged out: every card ties, so the A-Z order is kept. */
        const rank = item =>
            (typeof window.bplNeedsReferralLink === "function" && window.bplNeedsReferralLink(item?.domain)) ? 0 : 1;
        const ra = rank(a);
        const rb = rank(b);
        if (ra !== rb) return ra - rb;
        return azDelta();
    }

    const pa = sortPrimaryValue(domainSortMode, aRow, a);
    const pb = sortPrimaryValue(domainSortMode, bRow, b);
    if (pa && pb) {
        const ta = sortBottomTier(pa.has, aRow);
        const tb = sortBottomTier(pb.has, bRow);
        if (ta !== tb) return ta - tb;
        if (ta !== 0) return azDelta();
        const valueDelta = pa.asc ? (pa.val - pb.val) : (pb.val - pa.val);
        return valueDelta || azDelta();
    }

    return fallbackDelta;
}

window.bplSortFilterIsActive = function () {
    return sortFilterIsActive();
};

window.bplOrderFetcherCards = function (cards) {
    const source = Array.isArray(cards) ? cards : [];
    const homepageOrder = new Map();
    const addedAtByDomain = new Map();
    allDomains.forEach((item, index) => {
        const key = normalizeDomain(item.domain);
        if (!homepageOrder.has(key)) homepageOrder.set(key, index);
        if (!addedAtByDomain.has(key)) addedAtByDomain.set(key, item.addedAt || "");
    });

    let list = source.map((card, index) => ({
        ...card,
        addedAt: card.addedAt || addedAtByDomain.get(normalizeDomain(card.domain)) || "",
        _i: Number.isFinite(card.index) ? card.index : index
    }));

    if (filterNotVisitedOnly) {
        list = list.filter(card => !visitedDomains.has(normalizeDomain(card.domain)));
    }
    if (filterSignupBonusOnly) {
        list = list.filter(card => Boolean(signupBonusForDomain(card)));
    }

    const fallbackDelta = (a, b) =>
        (homepageOrder.get(normalizeDomain(a.domain)) ?? Number.MAX_SAFE_INTEGER) -
        (homepageOrder.get(normalizeDomain(b.domain)) ?? Number.MAX_SAFE_INTEGER) ||
        a._i - b._i;

    list.sort((a, b) =>
        (isDeadItem(a) - isDeadItem(b)) ||
        (domainSortMode === "default"
            ? fallbackDelta(a, b)
            : compareDisplayItems(a, b, fallbackDelta(a, b)))
    );
    return list;
};

function sortModeShortLabel(mode) {
    if (mode === "domain_asc") return "A → Z";
    if (mode === "domain_desc") return "Z → A";
    if (mode === "balance_desc") return "Balance ↓";
    if (mode === "best_turnover_asc") return "Best turnover";
    if (mode === "wallet_min_asc") return "Cash-out";
    if (mode === "error_type") return "Errors";
    if (mode === "community_desc") return "Most popular";
    if (mode === "account_no_referlink") return "No referlink";
    if (mode === "selected_bonus_amount_desc") return "Bonus amount ↓";
    if (mode === "selected_bonus_max_desc") return "Bonus max ↓";
    if (mode === "selected_bonus_turnover_asc") return "Bonus turnover ↑";
    if (mode === "recent_desc") return "Newest";
    return "Sort / Filter";
}

function updateSortFilterButton() {
    const button = document.getElementById("sortFilterButton");
    if (!button) return;

    const filterCount =
        Number(filterNotVisitedOnly) +
        Number(filterSignupBonusOnly);

    const parts = [];

    if (domainSortMode !== "default") {
        parts.push(sortModeShortLabel(domainSortMode));
    }

    if (bonusDisplayMode !== "none") {
        const displayLabels = {
            signup: "Signup",
            share: "Share",
            commission: "Commission",
            referral: "Referral",
            rebate: "Rebate"
        };
        parts.push(displayLabels[bonusDisplayMode] || "Bonus");
    }

    if (filterCount) {
        parts.push(`${filterCount} Filter${filterCount === 1 ? "" : "s"}`);
    }

    if (visibleCardCount > 0) parts.push(String(visibleCardCount));

    button.textContent = parts.length === 1 && visibleCardCount > 0
        ? `⇅ Sort / Filter • ${visibleCardCount}`
        : (parts.length ? `⇅ ${parts.join(" • ")}` : "⇅ Sort / Filter");

    button.classList.toggle("active-filter", sortFilterIsActive());
}

async function ensureSortFilterDataLoaded() {
    if (!sortFilterNeedsAccountData()) return true;

    if (!loggedIn) {
        alert("Please complete at least one fetch in the Bonus Fetcher first. Bonus display and wallet sorting use your saved account fetch data.");
        return false;
    }

    if (!walletDataLoaded) {
        await loadWalletData();
        updateWalletButton();
    }

    return true;
}

let visibleCardCount = 0;

function makeAllDomainsView(items) {
    const section = document.createElement("section");
    section.className = "section all-domains-view-section";
    const grid = document.createElement("div");
    grid.className = "cards all-domains-grid";
    windowCards(grid, items);
    section.append(grid);
    return section;
}


function bonusAmountText(bonus) {
    if (!bonus) return "—";

    const display = bonus.amountDisplay;
    if (display !== undefined && display !== null && String(display).trim() !== "" && !bonusDisplayIsRate(display)) {
        const raw = String(display).trim();

        if (/^\$/.test(raw)) return raw;

        if (/^\d+(?:\.\d+)?-\d+(?:\.\d+)?$/.test(raw)) {
            const [a, b] = raw.split("-");
            return `${moneyText(Number(a)) || a}–${moneyText(Number(b)) || b}`;
        }

        const numeric = Number(raw);
        if (Number.isFinite(numeric)) {
            return moneyText(numeric) || `$${numeric}`;
        }

        return raw;
    }

    const value = bonus.amount;
    if (value && typeof value === "object") {
        const min = Number(value.min);
        const max = Number(value.max);
        if (Number.isFinite(min) && Number.isFinite(max)) {
            if (min === max) return moneyText(min) || `$${min}`;
            return `${moneyText(min) || `$${min}`}–${moneyText(max) || `$${max}`}`;
        }
    }

    return moneyText(value) || "—";
}

function signupAmountText(bonus) {
    return bonusAmountText(bonus);
}

function signupTurnoverText(bonus) {
    if (!bonus) return "—";

    const explicit = Number(bonus.turnover);
    if (Number.isFinite(explicit) && explicit >= 0) {
        const rounded = Math.round(explicit * 100) / 100;
        return `${rounded.toFixed(rounded % 1 === 0 ? 0 : 2)}x`;
    }

    const value = signupTurnoverValue(bonus);
    if (!Number.isFinite(value)) return "—";
    const rounded = Math.round(value * 100) / 100;
    return `${rounded.toFixed(rounded % 1 === 0 ? 0 : 2)}x`;
}

function selectedBonusFromRow(walletRow) {
    if (!walletRow || walletRow.fetchState === "error") return null;

    if (bonusDisplayMode === "signup") return walletRow.new || null;
    if (bonusDisplayMode === "share") return walletRow.share || null;
    if (bonusDisplayMode === "commission") return walletRow.commission || null;
    if (bonusDisplayMode === "referral") return walletRow.referral || null;
    if (bonusDisplayMode === "rebate") return walletRow.rebate || null;

    return null;
}

function bonusDescriptionLabels(bonus) {
    const tags = Array.isArray(bonus?.descriptionTags) ? bonus.descriptionTags : [];
    return [tags.includes("tasks") ? "Tasks" : "", tags.includes("redeposit") ? "Redeposit" : ""].filter(Boolean);
}

function appendBonusDescriptionTags(container, bonus, extraClass = "") {
    const labels = bonusDescriptionLabels(bonus);
    if (!labels.length) return;
    const tags = document.createElement("span");
    tags.className = `bonus-description-tags ${extraClass}`.trim();
    tags.title = "Mentioned in this bonus description";
    for (const label of labels) {
        const tag = document.createElement("span");
        tag.className = "bonus-description-tag";
        tag.textContent = label;
        tags.append(tag);
    }
    container.append(tags);
}

function appendSelectedBonusLine(domainInfo, walletRow) {
    if (bonusDisplayMode === "none") return;

    const bonus = selectedBonusFromRow(walletRow);
    if (!bonus || typeof bonus !== "object") return;

    const line = document.createElement("span");
    line.className = `signup-bonus-line bonus-type-${bonusDisplayMode}`;

    const amount = bonusAmountText(bonus);
    const minText = withdrawalValueText(bonus.minWithdrawal);
    const maxText = withdrawalValueText(bonus.maxWithdrawal);

    if (bonusDisplayMode === "signup") {
        const turnover = signupTurnoverText(bonus);
        line.innerHTML = `
            <span class="signup-amount">🎁 Signup ${amount}</span>
            <span class="signup-withdraw">Min ${minText} • Max ${maxText}</span>
            <span class="signup-turnover">Turnover ${turnover}</span>
        `;
    } else if (bonusDisplayMode === "share") {
        line.innerHTML = `
            <span class="signup-amount">🤝 Share ${amount}</span>
            <span class="signup-withdraw">Min ${minText} • Max ${maxText}</span>
        `;
    } else if (bonusDisplayMode === "commission") {
        const minBet = withdrawalValueText(bonus.minBet);
        line.innerHTML = `
            <span class="signup-amount">💸 Commission ${amount}</span>
            <span class="signup-withdraw">Min bet ${minBet} • Max ${maxText}</span>
        `;
    } else if (bonusDisplayMode === "referral") {
        line.innerHTML = `
            <span class="signup-amount">👥 Referral ${amount}</span>
            <span class="signup-withdraw">Min ${minText} • Max ${maxText}</span>
        `;
    } else if (bonusDisplayMode === "rebate") {
        line.innerHTML = `
            <span class="signup-amount">♻️ Rebate ${amount}</span>
            <span class="signup-withdraw">Min ${minText} • Max ${maxText}</span>
        `;
    }

    if (bonusDisplayMode === "share" || bonusDisplayMode === "referral") {
        appendBonusDescriptionTags(line, bonus);
    }
    domainInfo.append(line);
}

const WALLET_BONUS_COLUMNS = [
    {key:"commission", mode:"commission", label:"Com", icon:"💸"},
    {key:"share", mode:"share", label:"Share", icon:"🤝"},
    {key:"referral", mode:"referral", label:"Ref", icon:"👥"},
    {key:"new", mode:"signup", label:"New", icon:"🎁"},
    {key:"rebate", mode:"rebate", label:"Rebate", icon:"♻️"}
];

function walletTurnover(bonus) {
    const amount = Number(bonus?.amount || 0);
    const minimum = Number(bonus?.minWithdrawal);
    if (!(amount > 0) || !(minimum > 0)) return null;
    return minimum / amount;
}

function walletTurnoverText(value) {
    if (value === null || !Number.isFinite(value)) return "";
    return `${Number(value >= 10 ? value.toFixed(1) : value.toFixed(2))}×`;
}

function walletEl(tag, className, text) {
    const el = document.createElement(tag);
    if (className) el.className = className;
    if (text !== undefined) el.textContent = text;
    return el;
}

function walletBalanceBlock(walletRow) {
    const block = walletEl("span", "wallet-data-line wc-balance");
    if (!walletRow) {
        block.classList.add("wallet-no-fetch");
        block.textContent = "Not in last fetch";
        return block;
    }
    if (walletRow.fetchState === "error") {
        block.classList.add("wallet-error");
        if (String(walletRow.errorType || "").toLowerCase() === "skipped") block.classList.add("wallet-skipped");
        block.textContent = `⚠ ${friendlyWalletError(walletRow)}`;
        return block;
    }
    const cash = Number(walletRow.cash) || 0;
    block.classList.toggle("wc-has-cash", cash > 0);
    block.append(
        walletEl("span", "wc-bal-label", "Balance"),
        walletEl("span", "wallet-balance", moneyText(cash) || "$0"),
        walletEl("span", "wallet-withdraw", `\u2193 ${withdrawalValueText(walletRow.cashMinWithdrawal)} · \u2191 ${withdrawalValueText(walletRow.cashMaxWithdrawal)}`)
    );
    return block;
}

function walletBonusPanel(walletRow) {
    if (!walletRow || walletRow.fetchState === "error") return null;
    const all = [];
    const seenBonuses = new Set();
    // The COM tile bonus lives only in its tile: leave it out of the expanded
    // list, and drop one list entry that is that same bonus (older stored rows
    // and the account-data fallback can carry it there). Other commissions
    // (extras with their own ids) stay listed.
    const comBonus = walletRow.commission && typeof walletRow.commission === "object" ? walletRow.commission : null;
    const sameWalletBonus = (a, b) => {
        const idA = String(a?.id ?? "").trim();
        const idB = String(b?.id ?? "").trim();
        if (idA || idB) return idA !== "" && idA === idB;
        const norm = value => String(value ?? "").replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim().toLowerCase();
        return norm(a?.name) !== "" && norm(a?.name) === norm(b?.name)
            && Math.abs(Number(a?.amount) - Number(b?.amount)) < 0.0001;
    };
    let comListed = !comBonus;
    const listExtras = (Array.isArray(walletRow.availableBonuses) ? walletRow.availableBonuses : []).filter(bonus => {
        if (comListed || !bonus || typeof bonus !== "object") return true;
        if (sameWalletBonus(bonus, comBonus)) {
            comListed = true;
            return false;
        }
        return true;
    });
    const candidates = [
        walletRow.share,
        walletRow.referral,
        walletRow.new,
        walletRow.rebate,
        ...listExtras
    ];
    for (const bonus of candidates) {
        if (!bonus || typeof bonus !== "object") continue;
        const id = String(bonus.id || "").trim();
        const fallback = [bonus.name || "", bonus.amountDisplay ?? bonus.amount ?? ""]
            .map(value => String(value).trim().toLowerCase()).join("|");
        const key = id ? `id:${id}` : `name:${fallback}`;
        if (seenBonuses.has(key)) continue;
        seenBonuses.add(key);
        all.push(bonus);
    }

    const panel = walletEl("span", "wc-panel");
    const grid = walletEl("span", "wc-grid");

    for (const col of WALLET_BONUS_COLUMNS) {
        const bonus = walletRow[col.key];
        const cell = walletEl("span", `wc-cell wc-${col.key}`);
        cell.append(walletEl("span", "wc-label", col.label));
        if (bonus && typeof bonus === "object" && bonusHasRealAmount(bonus)) {
            cell.classList.add("wc-yes");
            cell.append(walletEl("span", "wc-amt", bonusAmountText(bonus)));
            if (col.key === "commission") {
                cell.append(walletEl("span", "wc-sub", `Bet ${withdrawalValueText(bonus.minBet)}`));
            } else {
                cell.append(walletEl("span", "wc-sub", `\u2193 ${withdrawalValueText(bonus.minWithdrawal)}`));
            }
            cell.append(walletEl("span", "wc-sub", `\u2191 ${withdrawalValueText(bonus.maxWithdrawal)}`));
            const turn = walletTurnoverText(walletTurnover(bonus));
            if (turn && col.key !== "commission") cell.append(walletEl("span", "wc-turn", turn));
        } else {
            cell.append(walletEl("span", "wc-none", "\u2014"));
            cell.append(walletEl("span", "wc-sub", col.key === "commission" ? "Bet \u2014" : "\u2193 \u2014"));
            cell.append(walletEl("span", "wc-sub", "\u2191 \u2014"));
        }
        if (bonusDisplayMode === col.mode) cell.classList.add("wc-selected");
        grid.append(cell);
    }
    panel.append(grid);
    const conditions = walletEl("span", "wc-description-summary");
    for (const col of WALLET_BONUS_COLUMNS) {
        if (col.key !== "share" && col.key !== "referral") continue;
        const bonus = walletRow[col.key];
        if (!bonusHasRealAmount(bonus) || !bonusDescriptionLabels(bonus).length) continue;
        const row = walletEl("span", "wc-description-row");
        row.dataset.bonusKind = col.key;
        row.append(walletEl("span", "wc-description-label", col.key === "share" ? "Share:" : "Referral:"));
        appendBonusDescriptionTags(row, bonus);
        conditions.append(row);
    }
    if (conditions.childElementCount) panel.append(conditions);


    if (all.length) {
        const sorted = [...all].sort((a, b) =>
            (walletTurnover(a) ?? Infinity) - (walletTurnover(b) ?? Infinity)
            || Number(b?.amount || 0) - Number(a?.amount || 0)
        );
        const list = walletEl("span", "wc-list");
        list.hidden = true;
        for (const bonus of sorted) {
            const row = walletEl("span", "wc-list-row");
            const amount = typeof bonus?.amountDisplay === "string" && bonus.amountDisplay.includes("-")
                ? `$${bonus.amountDisplay}`
                : (moneyText(bonus?.amount) || "—");
            row.append(
                walletEl("span", "wc-list-name", String(bonus?.name || "Available bonus")),
                walletEl("span", "wc-list-amt", amount),
                walletEl("span", "wc-list-sub", `Min ${withdrawalValueText(bonus?.minWithdrawal)} \u00B7 Max ${withdrawalValueText(bonus?.maxWithdrawal)}`)
            );
            appendBonusDescriptionTags(row, bonus, "wc-list-description-tags");
            list.append(row);
        }
        list.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();
        });
        panel.append(list);
    } else {
        /* Nothing besides the tiles: say so instead of opening an empty list. */
        const list = walletEl("span", "wc-list wc-list-empty");
        list.hidden = true;
        const emptyRow = walletEl("span", "wc-list-row", "No other claimable bonuses in your last fetch.");
        emptyRow.style.color = "#9aa3b2";
        emptyRow.style.fontSize = ".72rem";
        list.append(emptyRow);
        list.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();
        });
        panel.append(list);
    }
    return panel;
}

function makeCard(item) {

    const domainKey =

        normalizeDomain(item.domain);

    const isVisited =

        visitedDomains.has(domainKey);

    const card =

        document.createElement("a");

    card.className = "card";

    card.dataset.domain = domainKey;

    card.href = item.url;

    card.target = "_blank";

    card.rel = "nofollow sponsored noopener noreferrer";
    card.title = "Open referral link in a new tab";

    if (loggedIn && notVisitedMode) {

        card.classList.add(

            isVisited

                ? "visited"

                : "unvisited"

        );

    }

    const icon =

        document.createElement("img");

    icon.className = "icon";

    icon.alt = "";

    if (!window.bplFaviconSeen) window.bplFaviconSeen = 0;
    const faviconEager = window.bplFaviconSeen < 24;
    window.bplFaviconSeen += 1;
    icon.loading = faviconEager ? "eager" : "lazy";
    icon.decoding = "async";
    icon.fetchPriority = faviconEager ? "high" : "low";

    icon.referrerPolicy = "no-referrer";

    const mainFaviconCandidates = [
        "api/favicon.php?domain=" +
            encodeURIComponent(domainKey),

        INTEL_API + "/favicon/" +
            encodeURIComponent(domainKey),

        letterIcon(domainKey)
    ];

    let mainFaviconIndex = 0;

    const loadNextMainFavicon = () => {
        if (
            mainFaviconIndex >=
            mainFaviconCandidates.length
        ) {
            icon.onerror = null;
            icon.src = letterIcon(domainKey);
            return;
        }

        icon.src =
            mainFaviconCandidates[
                mainFaviconIndex++
            ];
    };

    icon.bplLoad = loadNextMainFavicon;
    icon.onerror =
        loadNextMainFavicon;

    icon.onload = () => {
        if (icon.naturalWidth > 0) {
            if (!window.bplFaviconOk) window.bplFaviconOk = new Map();
            const okSrc = icon.getAttribute("src");
            if (okSrc) window.bplFaviconOk.set(domainKey, okSrc);
        }
    };

    const cachedFaviconSrc =
        window.bplFaviconOk ? window.bplFaviconOk.get(domainKey) : null;

    if (cachedFaviconSrc) {
        icon.loading = "eager";
        icon.fetchPriority = "high";
        icon.src = cachedFaviconSrc;
    } else if (faviconEager || !("IntersectionObserver" in window)) {
        loadNextMainFavicon();
    } else {
        const faviconObserver = new IntersectionObserver(entries => {
            if (!entries.some(entry => entry.isIntersecting)) return;
            faviconObserver.disconnect();
            icon.bplObserver = null;
            loadNextMainFavicon();
        }, {rootMargin: "600px 0px"});
        icon.bplObserver = faviconObserver;
        faviconObserver.observe(icon);
    }
    schedulePrimeFavicons();

    const domainInfo = document.createElement("span");
    domainInfo.className = "domain-info";

    const domain = document.createElement("span");
    domain.className = "domain";
    if (item.listPlace) {
        const index = document.createElement("span");
        index.className = "card-index";
        index.textContent = String(item.listPlace.n);
        index.title = `Card ${item.listPlace.n} of ${item.listPlace.total}`;
        index.setAttribute("aria-hidden", "true");
        domain.append(index);
    }
    const domainName = document.createElement("span");
    domainName.className = "domain-name";
    domainName.textContent = item.domain;
    domain.append(domainName);

    const status = document.createElement("span");
    status.className = "domain-status";
    status.dataset.statusDomain = domainKey;
    status.textContent = "Unknown";

    applyDomainStatus(status, domainKey);

    const added = document.createElement("span");
    added.className = "domain-added";
    added.textContent = relativeAddedAt(item.addedAt);
    added.title = formatAddedAt(item.addedAt);
    if (!added.textContent) {
        added.hidden = true;
    }

    if (item.casinoIdentity) {
        const identities = new Set(
            walletRowsForDomain(domainKey)
                .map(row => String(row?.casinoIdentity || ""))
                .filter(Boolean)
        );
        if (identities.size > 1) {
            const badge = document.createElement("span");
            badge.className = "casino-account-badge";
            badge.textContent = casinoAccountLabel(item.casinoIdentity);
            domainInfo.append(badge);
        }
    }

    domainInfo.append(domain, status, added);

    let walletPanel = null;

    if (loggedIn && viewMode !== "default" && walletDataLoaded) {
        const walletRow = walletRowForItem(item);

        if (walletMode && walletRow) {
            card.classList.add("wallet-card");
            if (walletRow.fetchState === "error") card.classList.add("wallet-error-card");
            const titleRow = document.createElement("span");
            titleRow.className = "wc-title";
            titleRow.append(domain, status);
            const facts = document.createElement("span");
            facts.className = "wc-facts";
            facts.append(added);
            if (walletRow.fetchState === "success" && walletRow.skippedNote) {
                // Error cooldown kept this site's last good data.
                const skipNote = document.createElement("span");
                skipNote.className = "wc-skip-note";
                skipNote.style.cssText = "display:block;font-size:.66rem;opacity:.72;margin-top:2px;";
                skipNote.textContent = "Last good data · " + String(walletRow.skippedNote).replace(/^Skipped\s*·\s*/i, "Skipped: ");
                facts.append(skipNote);
            }
            domainInfo.append(titleRow, facts, walletBalanceBlock(walletRow));
            walletPanel = walletBonusPanel(walletRow);
        } else if (walletMode && domainSortMode === "error_type" && !walletRow) {
            const note = document.createElement("span");
            note.className = "card-nofetch";
            note.textContent = "Not in last fetch";
            domainInfo.append(note);
        } else if (domainSortMode === "error_type" && walletRow?.fetchState === "error") {
            // This sort is specifically about account/fetch failures, so show
            // the reason even when the separate Wallets display is switched off.
            const errorLine = document.createElement("span");
            errorLine.className = "wallet-data-line wallet-error";
            errorLine.textContent = `⚠ ${friendlyWalletError(walletRow)}`;
            domainInfo.append(errorLine);
        }

        if (!walletMode) appendSelectedBonusLine(domainInfo, walletRow);
    }

    const communityCount = Number(item.community || 0);
    if (!item.placeholder && communityCount > 0) {
        const members = communityCount === 1 ? "1 member's link" : `${communityCount} members' links`;
        const badge = document.createElement("span");
        badge.className = "community-badge";
        badge.dataset.communityCount = String(communityCount);
        badge.setAttribute("role", "button");
        badge.tabIndex = 0;
        badge.title = `${members} take${communityCount === 1 ? "s" : ""} turns here. Tap for details`;
        badge.setAttribute("aria-label", `${members} take${communityCount === 1 ? "s" : ""} turns on this card. Show details`);
        badge.innerHTML = `👥 <b>${communityCount}</b>`;
        if (card.classList.contains("wallet-card")) {
            const titleRow = card.querySelector(".wc-title");
            if (titleRow) titleRow.append(badge);
            else status.after(badge);
        } else {
            // Badge sits on the title row, right after the domain name.
            const row = document.createElement("span");
            row.className = "domain-row";
            domain.replaceWith(row);
            row.append(domain, badge);
        }
    }

    card.append(
        icon,
        domainInfo
    );
    if (walletPanel) {
        card.append(walletPanel);
        const bonusList = walletPanel.querySelector(".wc-list");
        const chevron = document.createElement("span");
        chevron.className = "card-expand";
        chevron.setAttribute("role", "button");
        chevron.tabIndex = 0;
        chevron.setAttribute("aria-expanded", "false");
        chevron.setAttribute("aria-label", "Show bonus details");
        chevron.textContent = "⌄";
        const flipCard = event => {
            if (event) { event.preventDefault(); event.stopPropagation(); }
            const open = !card.classList.contains("is-expanded");
            card.classList.toggle("is-expanded", open);
            if (bonusList) bonusList.hidden = !open;
            chevron.setAttribute("aria-expanded", String(open));
        };
        chevron.addEventListener("click", flipCard);
        chevron.addEventListener("keydown", event => {
            if (event.key === "Enter" || event.key === " ") flipCard(event);
        });
        card.append(chevron);
    }

    if (loggedIn && notVisitedMode) {

        const indicator =

            document.createElement("span");

        indicator.className =

            "visit-indicator";

        indicator.textContent =

            isVisited

                ? "✓"

                : "●";

        indicator.title =

            isVisited

                ? "Visited"

                : "Not visited";

        card.append(indicator);

    }

    if (!item.placeholder && !item.external) {
        card.addEventListener(
            "click",
            async event => {
                if (event.defaultPrevented || event.button !== 0) {
                    return;
                }

                event.preventDefault();
                if (card.dataset.refreshing === "1") return;
                card.dataset.refreshing = "1";

                // Open synchronously so iOS/Safari treats this as the user's
                // tap even if it suspended the page while in the background.
                const opened = window.open("about:blank", "_blank");
                if (opened) opened.opener = null;

                recordVisit(item.domain, item.url);

                try {
                    const response = await fetch(
                        "api/homepage-domains.php?domain=" +
                            encodeURIComponent(domainKey) +
                            "&t=" + Date.now(),
                        {
                            cache:"no-store",
                            credentials:"same-origin"
                        }
                    );
                    const refreshed = await response.json();
                    if (
                        !response.ok ||
                        !refreshed?.ok ||
                        !/^\/go\.php\?t=/.test(String(refreshed.url || ""))
                    ) {
                        throw new Error("Could not refresh link");
                    }

                    item.url = String(refreshed.url);
                    card.href = item.url;
                    if (opened) opened.location.replace(item.url);
                    else window.location.assign(item.url);
                } catch (error) {
                    if (opened) opened.close();
                    console.warn("Referral link refresh failed:", error);
                    alert("Could not open this casino right now. Please try again.");
                } finally {
                    card.dataset.refreshing = "0";
                }
            }
        );
    }

    if (isScamItem(item)) {
        card.classList.add("card-scam");
        card.title = "Confirmed scam: reported by members and checked by the admin";
        const scamTag = document.createElement("span");
        scamTag.className = "card-scam-tag";
        scamTag.textContent = "SCAM";
        scamTag.setAttribute("aria-label", "Confirmed scam casino");
        card.append(scamTag);
        /* No outbound link for confirmed scams (go.php also refuses them). */
        card.removeAttribute("href");
        card.removeAttribute("target");
        card.addEventListener("click", (e) => { e.preventDefault(); e.stopImmediatePropagation(); }, true);
    }
    if (item.casinoIdentity) card.dataset.casinoIdentity = String(item.casinoIdentity);
    if (typeof window.bplDecorateCard === "function") window.bplDecorateCard(card, item);

    return card;

}

function makeNormalSection(title, items) {

    const section =

        document.createElement("section");

    section.className = "section regular-section";

    const heading =

        document.createElement("h2");

    heading.className =

        "section-title";

    heading.textContent =

        `${title} (${items.length})`;

    const cards =

        document.createElement("div");

    cards.className = "cards";

    items.forEach(item => {

        cards.append(

            makeCard(item)

        );

    });

    section.append(

        heading,

        cards

    );

    return section;

}


function isUnverifiedGroup(name) {
    const value = String(name || "")
        .trim()
        .toLowerCase()
        .replace(/[•·|_-]+/g, " ")
        .replace(/\s+/g, " ");

    return value.includes("unverified") ||
           value.includes("untested");
}

function isBestGroup(name) {
    const value = String(name || "").trim().toLowerCase();
    return value === "best" ||
           value.startsWith("best ") ||
           value.includes("best sites") ||
           value.includes("best pokies");
}

function isLatestGroup(name) {
    const value = String(name || "").trim().toLowerCase();
    return value === "latest" ||
           value.startsWith("latest ");
}

function makeBestSection(title, items) {
    const section = document.createElement("section");
    section.className = "section best-section";

    const heading = document.createElement("h2");
    heading.className = "section-title";
    heading.textContent = `★ ${title} (${items.length})`;

    const intro = document.createElement("div");
    intro.className = "best-explainer";
    intro.textContent = "Curated share bonuses — earned when a new downline qualifies. Live casinos only.";

    const cards = document.createElement("div");
    cards.className = "best-grid";

    items.forEach(item => {
        cards.append(makeCard(item));
    });

    section.append(heading, intro, cards);
    return section;
}

function primeVisibleFavicons() {
    let left = 24;
    document.querySelectorAll("#groups img.icon").forEach(icon => {
        if (left <= 0) return;
        if (icon.getBoundingClientRect().top > window.innerHeight + 400) return;
        left -= 1;
        icon.loading = "eager";
        icon.fetchPriority = "high";
        if (!icon.getAttribute("src") && typeof icon.bplLoad === "function") icon.bplLoad();
    });
}

function schedulePrimeFavicons() {
    if (schedulePrimeFavicons.queued) return;
    schedulePrimeFavicons.queued = true;
    requestAnimationFrame(() => {
        schedulePrimeFavicons.queued = false;
        primeVisibleFavicons();
    });
}

function windowCards(grid, items) {
    const total = Array.isArray(items) ? items.length : 0;
    const heavy = grid.classList.contains("all-domains-grid");
    const maxCards = heavy ? 40 : 60;
    const withPlace = (item, index) => ({...item, listPlace:{n:index + 1, total}});
    if (typeof windowCards.detach === "function") windowCards.detach();
    windowCards.detach = null;
    if (!Array.isArray(items) || total <= maxCards) {
        (items || []).forEach((item, index) => grid.append(makeCard(withPlace(item, index))));
        return;
    }

    const heights = new Array(total).fill(0);
    const topSpacer = document.createElement("div");
    const bottomSpacer = document.createElement("div");
    for (const spacer of [topSpacer, bottomSpacer]) {
        spacer.className = "bpl-window-spacer";
        spacer.setAttribute("aria-hidden", "true");
        spacer.style.gridColumn = "1 / -1";
        spacer.style.height = "0px";
        spacer.style.margin = "0";
        spacer.style.padding = "0";
        spacer.style.border = "0";
        spacer.style.pointerEvents = "none";
    }
    grid.append(topSpacer, bottomSpacer);

    let mountedStart = -1;
    let mountedEnd = -1;
    let frame = 0;

    const releaseCard = card => {
        card.querySelectorAll("img.icon").forEach(img => {
            if (img.bplObserver) {
                img.bplObserver.disconnect();
                img.bplObserver = null;
            }
        });
        card.remove();
    };

    const measure = () => {
        grid.querySelectorAll(":scope > a.card").forEach(card => {
            const index = Number(card.dataset.windowIndex);
            const height = card.offsetHeight;
            if (Number.isInteger(index) && index >= 0 && height > 0) heights[index] = height;
        });
    };

    const estimate = () => {
        let sum = 0;
        let count = 0;
        for (let i = 0; i < total; i++) {
            if (heights[i] > 0) {
                sum += heights[i];
                count++;
            }
        }
        return count ? sum / count : (heavy ? 120 : 56);
    };

    const columnCount = () => {
        if (!grid.isConnected) return 1;
        const template = getComputedStyle(grid).gridTemplateColumns;
        if (!template || template === "none") return 1;
        return Math.max(1, template.trim().split(/\s+/).length);
    };

    const gapSize = () => {
        if (!grid.isConnected) return 0;
        const value = parseFloat(getComputedStyle(grid).rowGap);
        return Number.isFinite(value) ? value : 0;
    };

    /* Cap by rows, not cards: N columns can mount N x maxCards cards, so
       the mounted window covers the same height as in 1 column. */
    const capFor = cols => maxCards * Math.max(1, Math.min(4, cols));

    const rowHeight = (row, cols, est) => {
        let max = 0;
        for (let col = 0; col < cols; col++) {
            const index = row * cols + col;
            if (index >= total) break;
            max = Math.max(max, heights[index] || est);
        }
        return max || est;
    };

    const rowsHeight = (fromRow, toRow, cols, est, gap) => {
        let sum = 0;
        for (let row = fromRow; row < toRow; row++) sum += rowHeight(row, cols, est) + gap;
        return sum;
    };

    const setBottom = () => {
        const cols = columnCount();
        const est = estimate();
        const gap = gapSize();
        const rowCount = Math.ceil(total / cols);
        const endRow = Math.ceil(Math.max(mountedEnd, 0) / cols);
        bottomSpacer.style.height = Math.round(rowsHeight(endRow, rowCount, cols, est, gap)) + "px";
    };

    const mount = (startIndex, endIndex) => {
        measure();
        const keepCards = new Map();
        grid.querySelectorAll(":scope > a.card").forEach(card => {
            const existingIndex = Number(card.dataset.windowIndex);
            if (Number.isInteger(existingIndex) && existingIndex >= startIndex && existingIndex < endIndex) {
                keepCards.set(existingIndex, card);
            } else {
                releaseCard(card);
            }
        });
        mountedStart = startIndex;
        mountedEnd = endIndex;
        for (let i = startIndex; i < endIndex; i++) {
            let card = keepCards.get(i);
            if (!card) {
                card = makeCard(withPlace(items[i], i));
                card.dataset.windowIndex = String(i);
            }
            grid.insertBefore(card, bottomSpacer);
        }
        const cols = columnCount();
        const est = estimate();
        const gap = gapSize();
        const rowCount = Math.ceil(total / cols);
        const startRow = Math.floor(startIndex / cols);
        const endRow = Math.ceil(endIndex / cols);
        topSpacer.style.height = Math.round(rowsHeight(0, startRow, cols, est, gap)) + "px";
        bottomSpacer.style.height = Math.round(rowsHeight(endRow, rowCount, cols, est, gap)) + "px";
        requestAnimationFrame(() => {
            if (!grid.isConnected || mountedEnd >= total) return;
            measure();
            if (mountedEnd - mountedStart >= capFor(columnCount())) return;
            if (bottomSpacer.getBoundingClientRect().top > (window.innerHeight || 800) + 280) return;
            mountedStart = -1;
            sync();
        });
    };

    const sync = () => {
        if (!grid.isConnected) return;
        measure();
        const cols = columnCount();
        const est = estimate();
        const gap = gapSize();
        const rowCount = Math.ceil(total / cols);
        const view = window.innerHeight || 800;
        const overscan = Math.max(360, Math.round(view * 0.75));
        const anchor = Math.max(0, -grid.getBoundingClientRect().top - overscan);
        let y = 0;
        let row = 0;
        while (row < rowCount - 1 && y + rowHeight(row, cols, est) + gap < anchor) {
            y += rowHeight(row, cols, est) + gap;
            row++;
        }
        const startIndex = row * cols;
        const slack = cols * 6;
        if (mountedStart >= 0 && startIndex >= mountedStart && startIndex <= mountedStart + slack) {
            setBottom();
            const spacerTop = bottomSpacer.getBoundingClientRect().top;
            /* BPL_WINDOW_ROWS_FIX: remount whenever the unrendered area is
               near the viewport, even when the window is already full (it
               then slides down). Before, a full window returned here, so in
               2 columns the bottom half of the screen stayed empty. */
            const needsMore = mountedEnd < total
                && spacerTop <= (window.innerHeight || 800) + 280;
            if (!needsMore) return;
        }
        let covered = 0;
        let endRow = row;
        let count = 0;
        const target = overscan * 2 + view;
        const cap = capFor(cols);
        while (endRow < rowCount && covered < target && count < cap) {
            covered += rowHeight(endRow, cols, est) + gap;
            count += cols;
            endRow++;
        }
        mount(startIndex, Math.min(total, endRow * cols));
    };

    const schedule = () => {
        if (frame) return;
        frame = requestAnimationFrame(() => {
            frame = 0;
            sync();
        });
    };

    const boot = () => {
        if (!grid.isConnected) {
            frame = requestAnimationFrame(boot);
            return;
        }
        frame = 0;
        sync();
    };
    frame = requestAnimationFrame(boot);
    const onResize = () => {
        mountedStart = -1;
        mountedEnd = -1;
        schedule();
    };
    window.addEventListener("scroll", schedule, {passive: true});
    window.addEventListener("resize", onResize, {passive: true});
    windowCards.detach = () => {
        cancelAnimationFrame(frame);
        window.removeEventListener("scroll", schedule);
        window.removeEventListener("resize", onResize);
    };
    if (!window.bplDirectoryFillers) window.bplDirectoryFillers = [];
    window.bplDirectoryFillers.push(sync);
}

function makeLatestSection(title, items) {
    const section = document.createElement("section");
    section.className = "section regular-section latest-section";
    const heading = document.createElement("h2");
    heading.className = "section-title";
    heading.textContent = `${title} (${items.length})`;
    const cards = document.createElement("div");
    cards.className = "cards";
    windowCards(cards, items);
    section.append(heading, cards);
    return section;
}

function isFavouritesGroup(name) {
    const value = String(name || "").trim().toLowerCase();
    return value === "favourites" || value === "favorites";
}

function makeFavouritesSection(title, items) {
    const section = document.createElement("section");
    section.className = "section favourites-section";

    const heading = document.createElement("h2");
    heading.className = "section-title";
    heading.textContent = `⭐ ${title} (${items.length})`;

    const cards = document.createElement("div");
    cards.className = "favourites-grid";

    // Keep every saved entry, including duplicate domains with different referlinks.
    items.forEach(item => {
        cards.append(makeCard(item));
    });

    section.append(heading, cards);
    return section;
}


/* BPL_LIZZY_NATIVE_V4_START */

function makeLizzySection() {

    const links = [
        {
            domain: "win19au.com",
            url: "https://win19au.com/RF306387373"
        },
        {
            domain: "gofun33.com",
            url: "https://gofun33.com/RF295A85995"
        },
        {
            domain: "supermateau.com",
            url: "https://supermateau.com/RF22121821"
        },
        {
            domain: "fortunex99.com",
            url: "https://fortunex99.com/RF323872987"
        },
        {
            domain: "slotunabets.com",
            url: "https://slotunabets.com/RF268A8015"
        },
        {
            domain: "cbr8aus.casino",
            url: "https://cbr8aus.casino/RF1825028A5"
        },
        {
            domain: "truemateaustralia.com",
            url: "https://truemateaustralia.com/RFA53A29752"
        }
    ];

    /*
     * SAME outer component as
     * Instant Withdrawal.
     */
    const section =
        document.createElement("section");

    section.className =
        "bonus-section lizzy-section";

    /*
     * SAME heading class.
     */
    const heading =
        document.createElement("h2");

    heading.className =
        "section-title";

    heading.textContent =
        `💜 LIZZY (${links.length})`;

    /*
     * SAME grid as Instant Withdrawal.
     *
     * This is the important part.
     */
    const grid =
        document.createElement("div");

    grid.className =
        "bonus-grid lizzy-grid";

    for (const item of links) {

        /*
         * Use the homepage's REAL card
         * renderer instead of creating
         * separate Lizzy markup.
         */
        const card =
            makeCard({
                domain: item.domain,
                url: item.url,
                group: "Lizzy"
            });

        card.classList.add(
            "lizzy-card"
        );

        /*
         * makeCard() creates the same:
         *
         * .icon
         * .domain
         * .domain-status
         * .domain-added
         *
         * as every other homepage card.
         */

        const status =
            card.querySelector(
                ".domain-status"
            );

        if (status) {

            /*
             * Stop the normal live/dead
             * status updater replacing
             * our Lizzy label.
             */
            status.removeAttribute(
                "data-status-domain"
            );

            status.className =
                "domain-status lizzy-status";

            status.textContent =
                "Lizzy";
        }

        /*
         * Lizzy links do not need a fake
         * added date.
         *
         * Card dimensions remain identical
         * because .bonus-grid .card has the
         * same min-height.
         */
        const added =
            card.querySelector(
                ".domain-added"
            );

        if (added) {
            added.remove();
        }

        /*
         * Ensure the supplied referral URL
         * is preserved exactly.
         */
        card.href =
            item.url;

        card.target =
            "_blank";

        card.rel =
            "nofollow sponsored noopener noreferrer";

        grid.appendChild(
            card
        );
    }

    section.append(
        heading,
        grid
    );

    return section;
}

/* BPL_LIZZY_NATIVE_V4_END */


function isInstantWithdrawalGroup(name) {
    const value = String(name || "").toLowerCase();
    return value.includes("instant") &&
           value.includes("withdraw") &&
           value.includes("share") &&
           value.includes("bonus");
}

function makeBonusSection(title, items) {
    const section = document.createElement("section");
    section.className = "section bonus-section";

    const heading = document.createElement("h2");
    heading.className = "section-title";
    heading.textContent = `🎁 ${title} (${items.length})`;

    const cards = document.createElement("div");
    cards.className = "bonus-grid";

    items.forEach(item => {
        cards.append(makeCard(item));
    });

    section.append(heading, cards);
    return section;
}



function makeExtraRentalSection() {
    const START_SLOT = 8;
    const END_SLOT = 16;
    const COUNT = END_SLOT - START_SLOT + 1;

    const section =
        document.createElement("section");

    section.className =
        "extra-rental-section";

    const heading =
        document.createElement("h2");

    heading.className =
        "section-title extra-rental-heading";

    heading.textContent =
        `🎰 MORE RENTAL CARDS (${COUNT})`;

    const grid =
        document.createElement("div");

    grid.className =
        "extra-rental-grid";

    for (
        let slotNumber = START_SLOT;
        slotNumber <= END_SLOT;
        slotNumber++
    ) {
        const card =
            document.createElement("a");

        card.className =
            "card newest-card rental-placeholder-card extra-rental-card";

        card.dataset.rentalSlot =
            String(slotNumber);

        card.dataset.rentalPlaceholder =
            "1";

        card.dataset.domain =
            `Rental Slot ${slotNumber}`;

        card.href = "#";
        card.target = "_blank";
        card.rel = "noopener noreferrer";

        card.title =
            `Rental slot ${slotNumber} • available`;

        const icon =
            document.createElement("img");

        icon.className =
            "icon rental-placeholder-icon";

        icon.alt = "";
        icon.loading = "lazy";

        icon.src =
            "data:image/svg+xml;charset=UTF-8," +
            encodeURIComponent(
                `<svg xmlns="http://www.w3.org/2000/svg"
                      width="64"
                      height="64"
                      viewBox="0 0 64 64">
                    <rect width="64"
                          height="64"
                          rx="14"
                          fill="#18131f"/>
                    <text x="32"
                          y="43"
                          text-anchor="middle"
                          font-size="34">🎰</text>
                </svg>`
            );

        const domainInfo =
            document.createElement("span");

        domainInfo.className =
            "domain-info";

        const domain =
            document.createElement("span");

        domain.className =
            "domain";

        domain.textContent =
            "Available to Rent";

        const status =
            document.createElement("span");

        status.className =
            "domain-status rental-available-status";

        status.textContent =
            `Slot ${slotNumber} • Available`;

        const added =
            document.createElement("span");

        added.className =
            "domain-added";

        added.hidden = true;

        domainInfo.append(
            domain,
            status,
            added
        );

        card.append(
            icon,
            domainInfo
        );

        applyActiveRentalToCard(
            card,
            {
                domain:
                    `rent-slot-${slotNumber}`,
                url: "#",
                group:
                    "RENT A DOMAIN CARD",
                rentalPlaceholder: true,
                rentalSlot:
                    slotNumber
            },
            slotNumber
        );

        card.addEventListener(
            "click",
            event => {
                if (
                    card.dataset.rentalActive
                        !== "1"
                    &&
                    !document.body.classList.contains(
                        "domain-rental-mode"
                    )
                ) {
                    event.preventDefault();
                }
            }
        );

        grid.append(card);
    }

    section.append(
        heading,
        grid
    );

    return section;
}



function makeTripleTopSection(
    firstName,
    firstItems,
    secondName,
    secondItems,
    suppliedUnverifiedItems = []
) {
    const TOP_COUNT = 7;

    const placeholderItems = [
        {domain:"newspin88.com", url:"#", group:"New • Unverified", placeholder:true},
        {domain:"freshpokies.au", url:"#", group:"New • Unverified", placeholder:true},
        {domain:"playnew777.com", url:"#", group:"New • Unverified", placeholder:true},
        {domain:"rapidspin.co", url:"#", group:"New • Unverified", placeholder:true},
        {domain:"luckynewau.com", url:"#", group:"New • Unverified", placeholder:true},
        {domain:"vaultnew88.com", url:"#", group:"New • Unverified", placeholder:true},
        {domain:"wildnewplay.com", url:"#", group:"New • Unverified", placeholder:true}
    ];

    const firstTop = firstItems.slice(0, TOP_COUNT);

    /*
     * RENT A CARD is no longer backed by ordinary homepage
     * referral links. It always contains exactly seven dedicated
     * rental slots.
     */
    const secondTop = Array.from(
        {length: TOP_COUNT},
        (_, index) => ({
            domain: `rent-slot-${index + 1}`,
            url: "#",
            group: "RENT A CARD",
            rentalPlaceholder: true,
            rentalSlot: index + 1
        })
    );

    // Once the admin adds real "New • Unverified" domains, those replace
    // the preview placeholders automatically.
    const usingPlaceholders = !suppliedUnverifiedItems.length;
    const unverifiedItems = (
        usingPlaceholders
            ? placeholderItems
            : suppliedUnverifiedItems.slice(0, TOP_COUNT)
    );

    const block = document.createElement("section");
    block.className = "top-block";

    const headings = document.createElement("div");
    headings.className = "top-headings";

    const firstHeading = document.createElement("h2");
    firstHeading.className = "section-title new-heading";
    firstHeading.textContent = `🌿 ${firstName} (${firstTop.length})`;

    const secondHeading = document.createElement("h2");
    secondHeading.className = "section-title newest-heading";
    secondHeading.textContent = `🎰 RENT A CARD (${TOP_COUNT})`;

    const thirdHeadingWrap = document.createElement("div");
    thirdHeadingWrap.className = "unverified-column-wrap";

    const thirdHeading = document.createElement("h2");
    thirdHeading.className = "section-title unverified-heading new-heading";
    thirdHeading.textContent = `🌿 NEW (${unverifiedItems.length})`;

    thirdHeadingWrap.append(thirdHeading);
    headings.append(firstHeading, thirdHeadingWrap);

    const grid = document.createElement("div");
    grid.className = "top-grid";

    const rentBlock = document.createElement("section");
    rentBlock.className = "top-block rent-block";
    const rentGrid = document.createElement("div");
    rentGrid.className = "top-grid rent-grid";
    const rentFrame = document.createElement("div");
    rentFrame.className = "featured-frame";
    rentFrame.append(secondHeading, rentGrid);
    rentBlock.append(rentFrame);

    for (let index = 0; index < TOP_COUNT; index++) {
        const first = firstTop[index];
        const second = secondTop[index];
        const third = unverifiedItems[index];

        if (first) {
            const card = makeCard(first);
            card.classList.add("new-card");
            grid.append(card);
        } else {
            grid.append(document.createElement("div"));
        }

        if (second) {
            const slotNumber = index + 1;

            /*
             * Dedicated rental placeholder.
             * It contains the same child classes that
             * applyActiveRentalToCard() expects, so an active
             * rental can replace it automatically.
             */
            const card = document.createElement("a");

            card.className =
                "card newest-card rental-placeholder-card";

            card.dataset.rentalSlot =
                String(slotNumber);

            card.dataset.rentalPlaceholder = "1";

            /*
             * The rental modal requires data-domain to be present.
             * Permanent rental placeholders are synthetic cards,
             * so give each one its own stable display name.
             */
            card.dataset.domain =
                `Rental Slot ${slotNumber}`;

            card.href = "#";
            card.target = "_blank";
            card.rel = "noopener noreferrer";

            card.title =
                `Rental slot ${slotNumber} • available`;

            const icon =
                document.createElement("img");

            icon.className =
                "icon rental-placeholder-icon";

            icon.alt = "";
            icon.loading = "lazy";

            /*
             * Transparent placeholder until the slot is rented.
             * applyActiveRentalToCard() replaces src with the
             * renter's favicon.
             */
            icon.src =
                "data:image/svg+xml;charset=UTF-8," +
                encodeURIComponent(
                    `<svg xmlns="http://www.w3.org/2000/svg"
                          width="64"
                          height="64"
                          viewBox="0 0 64 64">
                        <rect width="64"
                              height="64"
                              rx="14"
                              fill="#18131f"/>
                        <text x="32"
                              y="43"
                              text-anchor="middle"
                              font-size="34">🎰</text>
                    </svg>`
                );

            const domainInfo =
                document.createElement("span");

            domainInfo.className =
                "domain-info";

            const domain =
                document.createElement("span");

            domain.className = "domain";
            domain.textContent =
                "Available to Rent";

            const status =
                document.createElement("span");

            status.className =
                "domain-status rental-available-status";

            status.textContent =
                `Slot ${slotNumber} • Available`;

            const added =
                document.createElement("span");

            added.className = "domain-added";
            added.hidden = true;

            domainInfo.append(
                domain,
                status,
                added
            );

            card.append(
                icon,
                domainInfo
            );

            /*
             * If this slot currently has a rental, convert
             * the placeholder into the renter's real card.
             */
            applyActiveRentalToCard(
                card,
                second,
                slotNumber
            );

            /*
             * Empty placeholders do not open "#".
             * Rental-mode handling can still select them.
             */
            card.addEventListener(
                "click",
                event => {
                    if (
                        card.dataset.rentalActive !== "1"
                        && !document.body.classList.contains(
                            "domain-rental-mode"
                        )
                    ) {
                        event.preventDefault();
                    }
                }
            );

            rentGrid.append(card);
        }

        if (third) {
            const card = makeCard(third);
            card.classList.add("unverified-card");
            card.title = "Newly found — withdrawal not yet verified";

            const status = card.querySelector(".domain-status");
            if (status) {
                status.className = "domain-status";
                status.textContent = "Untested";
                status.removeAttribute("data-status-domain");
                status.title = "Withdrawal not yet verified";
            }

            if (third.placeholder) {
                card.href = "#";
                card.removeAttribute("target");
                card.removeAttribute("rel");
                card.addEventListener(
                    "click",
                    event => event.preventDefault()
                );
            }

            grid.append(card);
        } else {
            grid.append(document.createElement("div"));
        }
    }

    const featuredFrame = document.createElement("div");
    featuredFrame.className = "featured-frame";
    featuredFrame.append(headings, grid);

    block.append(featuredFrame);

    const element = document.createDocumentFragment();
    element.append(block);

    return {
        element,
        firstRemaining:firstItems.slice(TOP_COUNT),
        secondRemaining:secondItems.slice(TOP_COUNT),
        unverifiedRemaining:usingPlaceholders
            ? []
            : suppliedUnverifiedItems.slice(TOP_COUNT)
    };
}


const PINNED_BEST_DOMAINS = [
    "iw99au.com",
    "pokies7bet.com",
    "spinroo9.com",
    "oakfold.net",
    "bonzaau.com",
    "ig9aus.win",
    "mrblueyau.com"
];
let communityPromoted = [];
let communityPromotedSig = "";
const NEW_SECTION_LIMIT = 20;
/* Confirmed scam casinos (admin/reports.php): red SCAM cards, never in Best/New/Promoted, listed last. */
window.bplScamDomains = new Set(["auium.com","aussie789.net","boomerangaus.com","crownbetking.com","cunt9.com","cuntspider.xyz","favspin.net","hallowin88.online","hexqueen.site","ii89.io","ilovejili.vip","legit99.net","parabet99.vip","royalwin96.com","slotmeth.net","springmateau.com","steambet.site","upwin.com","upwin.store","wthslot.org"]);
function isScamItem(item) {
    const set = window.bplScamDomains;
    return Boolean(set && set.size && set.has(homepageDomainKey(item)));
}
function scamLast(list) {
    if (!window.bplScamDomains || !window.bplScamDomains.size) return list;
    const ok = [], bad = [];
    for (const item of list) (isScamItem(item) ? bad : ok).push(item);
    return bad.length ? ok.concat(bad) : list;
}
function makeScamSection(items) {
    const section = makeNormalSection("⚠️ Confirmed scams", items);
    section.classList.add("scam-section");
    const note = document.createElement("p");
    note.className = "scam-explainer";
    note.textContent = "Reported by members and confirmed by the admin. We don't recommend signing up.";
    const heading = section.querySelector(".section-title");
    if (heading) heading.after(note);
    return section;
}

function homepageDomainKey(item) {
    return String(item?.domain || "").trim().toLowerCase().replace(/^www\./, "");
}

function newestSectionItems(data) {
    const pinned = new Set(PINNED_BEST_DOMAINS);
    const excluded = new Set([
        "megah5pgk.ink",
        "acegoal918.com",
        "kinapgk.online",
        "kumulgold.com"
    ]);
    const placedInBest = new Set(bestSectionItems(data).map(homepageDomainKey));
    const seen = new Set();
    const pool = [];
    for (const item of data) {
        const key = homepageDomainKey(item);
        if (!key || excluded.has(key) || pinned.has(key) || placedInBest.has(key) || seen.has(key) || isScamItem(item)) continue;
        seen.add(key);
        pool.push(item);
    }
    for (const item of communityPromoted) {
        const key = homepageDomainKey(item);
        if (!key || excluded.has(key) || pinned.has(key) || placedInBest.has(key) || seen.has(key) || isScamItem(item)) continue;
        seen.add(key);
        pool.push(item);
    }
    pool.sort((a, b) => addedAtTimestamp(b) - addedAtTimestamp(a) || homepageDomainKey(a).localeCompare(homepageDomainKey(b)));
    return pool.slice(0, NEW_SECTION_LIMIT);
}

function latestSectionItems(data, shown) {
    const pinned = new Set(PINNED_BEST_DOMAINS);
    const items = [];
    for (const item of data) {
        const key = homepageDomainKey(item);
        if (!key || shown.has(key) || pinned.has(key) || isScamItem(item)) continue;
        const group = String(item.group || "");
        if (isBestGroup(group) || isInstantWithdrawalGroup(group) || isUnverifiedGroup(group)) continue;
        if (!(isLatestGroup(group) || group.trim().toLowerCase() === "new")) continue;
        items.push(item);
    }
    items.sort((a, b) => addedAtTimestamp(b) - addedAtTimestamp(a) || homepageDomainKey(a).localeCompare(homepageDomainKey(b)));
    return items;
}

function bestDisplayEligible(item) {
    if (isScamItem(item)) return false;
    const info = domainStatusMap.get(homepageDomainKey(item));
    if (!info) return true;
    const status = String(info.status || "").toLowerCase();
    return status !== "dead" && status !== "redirect";
}

function bestSectionItems(data) {
    const byDomain = new Map();
    for (const item of data) {
        const key = homepageDomainKey(item);
        if (key && !byDomain.has(key)) byDomain.set(key, item);
    }
    const used = new Set();
    const out = [];
    for (const domain of PINNED_BEST_DOMAINS) {
        const item = byDomain.get(domain);
        if (!item || !bestDisplayEligible(item)) continue;
        used.add(domain);
        out.push(item);
    }
    for (const item of data) {
        if (!isBestGroup(item.group)) continue;
        const key = homepageDomainKey(item);
        if (!key || used.has(key) || !bestDisplayEligible(item)) continue;
        used.add(key);
        out.push(item);
    }
    for (const item of data) {
        if (!isInstantWithdrawalGroup(item.group)) continue;
        const key = homepageDomainKey(item);
        if (!key || used.has(key) || !bestDisplayEligible(item)) continue;
        used.add(key);
        out.push(item);
    }
    return out;
}

function makeNewLatestSection(items) {
    const section = document.createElement("section");
    section.className = "section new-latest-section";
    const heading = document.createElement("h2");
    heading.className = "section-title";
    heading.textContent = `🌿 NEW (${items.length})`;
    const cards = document.createElement("div");
    cards.className = "new-latest-grid";
    items.forEach(item => cards.append(makeCard(item)));
    section.append(heading, cards);
    return section;
}

function render() {
    window.bplFaviconSeen = 0;
    window.bplDirectoryFillers = [];
    if (typeof window.bplSyncEmptyCopy === "function") window.bplSyncEmptyCopy();
    groupsElement.innerHTML = "";
    groupsElement.classList.remove("view-default", "view-one", "view-two");
    groupsElement.classList.add(`view-${viewMode}`);

    const data = prepareDomainsForDisplay(allDomains);

    if (viewMode !== "default" || sortFilterIsActive()) {
        visibleCardCount = data.length;
        updateSortFilterButton();
        if (!data.length) {
            emptyElement.classList.remove("hidden");
            updateProgress();
            refreshFetcherAfterRender();
            return;
        }
        emptyElement.classList.add("hidden");
        groupsElement.append(makeAllDomainsView(data));
        updateProgress();
        refreshFetcherAfterRender();
        return;
    }
    if (visibleCardCount) {
        visibleCardCount = 0;
        updateSortFilterButton();
    }

    const orderedGroups = [...new Set(data.map(item => String(item.group || "Domains")))];
    if (!orderedGroups.length) {
        emptyElement.classList.remove("hidden");
        updateProgress();
        refreshFetcherAfterRender();
        return;
    }
    emptyElement.classList.add("hidden");

    const newItems = newestSectionItems(data);
    const bestItems = bestSectionItems(data);
    const shown = new Set([...newItems, ...bestItems].map(homepageDomainKey));

    if (newItems.length) groupsElement.append(makeNewLatestSection(newItems));
    if (bestItems.length) groupsElement.append(makeBestSection("Best", bestItems));

    const latestItems = latestSectionItems(data, shown);
    if (latestItems.length) groupsElement.append(makeLatestSection("latest", latestItems));

    orderedGroups.forEach(groupName => {
        const normalized = String(groupName || "").trim().toLowerCase();
        if (normalized === "new" || isUnverifiedGroup(groupName) || isBestGroup(groupName) || isInstantWithdrawalGroup(groupName) || isLatestGroup(groupName)) return;
        const items = data.filter(item =>
            String(item.group || "Domains") === groupName && !shown.has(homepageDomainKey(item)) && !isScamItem(item)
        );
        if (!items.length) return;
        if (isFavouritesGroup(groupName)) groupsElement.append(makeFavouritesSection(groupName, items));
        else if (isLatestGroup(groupName)) groupsElement.append(makeLatestSection(groupName, items));
        else groupsElement.append(makeNormalSection(groupName, items));
    });

    const scamItems = [];
    const scamSeen = new Set();
    for (const item of data.concat(communityPromoted)) {
        const key = homepageDomainKey(item);
        if (!key || scamSeen.has(key) || !isScamItem(item)) continue;
        scamSeen.add(key);
        scamItems.push(item);
    }
    if (scamItems.length) groupsElement.append(makeScamSection(scamItems));

    updateProgress();
    refreshFetcherAfterRender();
}

function refreshFetcherAfterRender() {
    if (typeof window.bplRefreshFetcherOrder === "function") {
        window.bplRefreshFetcherOrder();
    }
}

function sendAnalytics(payload) {

    const json = JSON.stringify(payload);

    /*
        sendBeacon is much harder for Safari to cancel when a referral
        link opens immediately in a new tab.
    */
    if (navigator.sendBeacon) {

        try {

            const blob = new Blob(
                [json],
                {
                    type:"application/json"
                }
            );

            if (
                navigator.sendBeacon(
                    "api/track.php",
                    blob
                )
            ) {
                return;
            }

        } catch(error) {
            console.warn("sendBeacon fallback:", error);
        }
    }

    fetch(
        "api/track.php",
        {
            method:"POST",
            headers:{
                "Content-Type":"application/json"
            },
            body:json,
            keepalive:true
        }
    ).catch(error => {
        console.error("Analytics request failed:", error);
    });
}


function trackPageVisit() {

    sendAnalytics({
        action:"visit"
    });
}


async function recordVisit(domain, url) {

    const domainKey = normalizeDomain(domain);

    /*
        Count EVERY click:
        - logged in
        - logged out
        - repeat clicks
    */
    sendAnalytics({
        action:"click",
        domain:domainKey,
        url:String(url || "")
    });

    /*
        Visited history is a separate per-account feature.
    */
    if (!loggedIn) {
        return;
    }

    const wasAlreadyVisited = visitedDomains.has(domainKey);
    visitedDomains.add(domainKey);

    try {
        const response = await fetch(
            "api/visited.php",
            {
                method:"POST",
                credentials:"same-origin",
                headers:{
                    "Content-Type":"application/json"
                },
                body:JSON.stringify({
                    domain:domainKey
                })
            }
        );

        const result = await response.json();

        if (!response.ok || !result.ok) {
            throw new Error(result.error || `Visited API HTTP ${response.status}`);
        }

        if (String(result.accountKey || "") !== String(currentAccountKey || "")) {
            throw new Error("Visited account mismatch.");
        }

    } catch(error) {
        if (!wasAlreadyVisited) {
            visitedDomains.delete(domainKey);
        }

        console.error(
            "Could not save visit:",
            error
        );
    }

    if (notVisitedMode) {
        render();
    } else {
        updateProgress();
    }
}


function updateProgress() {

    const progress =

        $("#progress");

    if (!loggedIn) {

        progress.classList.add(

            "hidden"

        );

        return;

    }

    const total =

        allDomains.length;

    let visitedCount = 0;

    for (const item of allDomains) {

        if (

            visitedDomains.has(

                normalizeDomain(item.domain)

            )

        ) {

            visitedCount++;

        }

    }

    const remaining =

        Math.max(

            0,

            total - visitedCount

        );

    const totalSitesCount = document.getElementById("totalSitesCount");
    const visitedSitesCount = document.getElementById("visitedSitesCount");
    const notVisitedCount = document.getElementById("notVisitedCount");

    if (totalSitesCount) totalSitesCount.textContent = String(total);
    if (visitedSitesCount) visitedSitesCount.textContent = String(visitedCount);
    if (notVisitedCount) notVisitedCount.textContent = String(remaining);

    progress.textContent = "";
    progress.classList.add("hidden");

}

let currentDiscordReferralUrl = "";


async function loadDiscordReferralProfile(
    createIfMissing = false
) {
    const box =
        document.getElementById(
            "profileDiscordReferralBox"
        );

    const stats =
        document.getElementById(
            "profileDiscordReferralStats"
        );

    const link =
        document.getElementById(
            "profileDiscordReferralLink"
        );

    const getButton =
        document.getElementById(
            "getDiscordReferralButton"
        );

    const copyButton =
        document.getElementById(
            "copyDiscordReferralButton"
        );

    const shareButton =
        document.getElementById(
            "shareDiscordReferralButton"
        );

    if (!box) {
        return;
    }

    try {
        if (getButton) {
            getButton.disabled = true;

            if (createIfMissing) {
                getButton.textContent =
                    "⏳ Getting Referral Link…";
            }
        }

        const response = await fetch(
            "api/discord-referral-self.php?t="
            + Date.now(),
            {
                method:"POST",
                credentials:"same-origin",
                cache:"no-store",
                headers:{
                    "Content-Type":
                        "application/json"
                },
                body:JSON.stringify({
                    action:
                        createIfMissing
                            ? "getOrCreate"
                            : "get"
                })
            }
        );

        const result =
            await response.json();

        if (
            !response.ok
            || !result.ok
        ) {
            throw new Error(
                result.error
                || `HTTP ${response.status}`
            );
        }

        if (!result.linked) {
            box.classList.add(
                "hidden"
            );

            currentDiscordReferralUrl =
                "";

            return;
        }

        box.classList.remove(
            "hidden"
        );

        const joined =
            Number(
                result.joined
                || 0
            );

        const linkedReferrals =
            Number(
                result.linkedReferrals
                ?? result.successful
                ?? 0
            );

        const joinCredits =
            Number(
                result.joinCredits
                || 0
            );

        const linkCredits =
            Number(
                result.linkCredits
                || 0
            );

        const creditsEarned =
            Number(
                result.creditsEarned
                || 0
            );

        if (stats) {
            stats.innerHTML =
                `👥 Discord Joins: <strong>${joined}</strong><br>`
                + `🔗 Accounts Linked: <strong>${linkedReferrals}</strong><br>`
                + `🎟️ Join Credits: <strong>+${joinCredits}</strong><br>`
                + `🔗 Link Credits: <strong>+${linkCredits}</strong><br>`
                + `💳 Total Earned: <strong>+${creditsEarned}</strong>`;
        }

        currentDiscordReferralUrl =
            String(
                result.inviteUrl
                || ""
            ).trim();

        if (
            currentDiscordReferralUrl
        ) {
            if (link) {
                link.textContent =
                    currentDiscordReferralUrl;
            }

            if (copyButton) {
                copyButton.classList.remove(
                    "hidden"
                );
            }

            if (shareButton) {
                shareButton.classList.remove(
                    "hidden"
                );
            }

            if (getButton) {
                getButton.textContent =
                    "🎟️ My Discord Referral Link";
            }
        } else {
            if (link) {
                link.textContent =
                    "You don't have a Discord referral link yet.";
            }

            if (copyButton) {
                copyButton.classList.add(
                    "hidden"
                );
            }

            if (shareButton) {
                shareButton.classList.add(
                    "hidden"
                );
            }

            if (getButton) {
                getButton.textContent =
                    "🎟️ Get My Discord Referral Link";
            }
        }

    } catch (error) {
        console.error(
            "Discord referral:",
            error
        );

        if (link) {
            link.textContent =
                "Could not load Discord referral link.";
        }

        if (getButton) {
            getButton.textContent =
                "🎟️ Try Again";
        }

    } finally {
        if (getButton) {
            getButton.disabled = false;
        }
    }
}



const topMenuButton =
    document.getElementById(
        "topMenuButton"
    );

const topUtilityMenu =
    document.getElementById(
        "topUtilityMenu"
    );

topMenuButton
    ?.addEventListener(
        "click",
        () => {
            if (!topUtilityMenu) {
                return;
            }

            const opening =
                topUtilityMenu.classList.contains(
                    "hidden"
                );

            topUtilityMenu.classList.toggle(
                "hidden",
                !opening
            );

            topMenuButton.setAttribute(
                "aria-expanded",
                opening
                    ? "true"
                    : "false"
            );

            const symbol =
                topMenuButton.querySelector(
                    ".drawer-icon-action-symbol"
                );

            const label =
                topMenuButton.querySelector(
                    ".drawer-icon-action-label"
                );

            if (symbol) {
                symbol.textContent =
                    opening
                        ? "×"
                        : "☰";
            }

            if (label) {
                label.textContent =
                    opening
                        ? "Close"
                        : "Menu";
            }
        }
    );



function closeSideDrawerBeforeAction() {
    const menu =
        document.getElementById(
            "topUtilityMenu"
        );

    const button =
        document.getElementById(
            "topMenuButton"
        );

    if (menu) {
        menu.classList.add(
            "hidden"
        );
    }

    if (button) {
        button.setAttribute(
            "aria-expanded",
            "false"
        );

        const symbol =
            button.querySelector(
                ".drawer-icon-action-symbol"
            );

        const label =
            button.querySelector(
                ".drawer-icon-action-label"
            );

        if (symbol) {
            symbol.textContent =
                "☰";
        }

        if (label) {
            label.textContent =
                "Menu";
        }
    }
}


[
    "profileButton",
    "promoterRentLauncherButton",
    "promoterRentInfoButton",
    "domainSubmitButton",
    "reportScamMenuButton"
].forEach(
    id => {
        document
            .getElementById(id)
            ?.addEventListener(
                "click",
                () => {
                    closeSideDrawerBeforeAction();
                },
                true
            );
    }
);


document
    .getElementById(
        "getDiscordReferralButton"
    )
    ?.addEventListener(
        "click",
        () => {
            loadDiscordReferralProfile(
                true
            );
        }
    );


document
    .getElementById(
        "shareDiscordReferralButton"
    )
    ?.addEventListener(
        "click",
        async () => {
            if (
                !currentDiscordReferralUrl
            ) {
                return;
            }

            const shareData = {
                title:
                    "Best Pokies List",
                text:
                    "Join the Best Pokies List Discord community:",
                url:
                    currentDiscordReferralUrl
            };

            try {
                if (
                    navigator.share
                ) {
                    await navigator.share(
                        shareData
                    );

                    return;
                }

                await navigator.clipboard.writeText(
                    currentDiscordReferralUrl
                );

                alert(
                    "Discord referral link copied."
                );

            } catch (error) {
                if (
                    error?.name ===
                    "AbortError"
                ) {
                    return;
                }

                try {
                    await navigator.clipboard.writeText(
                        currentDiscordReferralUrl
                    );

                    alert(
                        "Discord referral link copied."
                    );

                } catch (_) {
                    alert(
                        currentDiscordReferralUrl
                    );
                }
            }
        }
    );


document
    .getElementById(
        "copyDiscordReferralButton"
    )
    ?.addEventListener(
        "click",
        async () => {
            if (
                !currentDiscordReferralUrl
            ) {
                return;
            }

            try {
                await navigator.clipboard.writeText(
                    currentDiscordReferralUrl
                );

                const button =
                    document.getElementById(
                        "copyDiscordReferralButton"
                    );

                if (button) {
                    const oldText =
                        button.textContent;

                    button.textContent =
                        "✅ Copied Discord Referral Link";

                    setTimeout(
                        () => {
                            button.textContent =
                                oldText;
                        },
                        1500
                    );
                }

            } catch (error) {
                alert(
                    currentDiscordReferralUrl
                );
            }
        }
    );


async function syncDiscordLinkButtons() {
    const mainButton =
        document.getElementById(
            "discordLinkButton"
        );

    const profileButton =
        document.getElementById(
            "profileDiscordLinkButton"
        );

    const unlinkButton =
        document.getElementById(
            "profileDiscordUnlinkButton"
        );

    const setNotLinked = () => {
        const referralBox =
            document.getElementById(
                "profileDiscordReferralBox"
            );

        if (referralBox) {
            referralBox.classList.add(
                "hidden"
            );
        }

        currentDiscordReferralUrl = "";

        if (mainButton) {
            mainButton.innerHTML =
                "<span>🔗 Link Discord</span>";

            mainButton.href =
                "discord-connect.php";

            mainButton.classList.remove(
                "discord-linked"
            );

            mainButton.removeAttribute(
                "aria-disabled"
            );

            mainButton.title =
                "Link your Discord account";
        }

        if (profileButton) {
            profileButton.textContent =
                "🔗 Link Discord Account";

            profileButton.href =
                "discord-connect.php";

            profileButton.classList.remove(
                "discord-linked"
            );

            profileButton.removeAttribute(
                "aria-disabled"
            );

            profileButton.title =
                "Link your Discord account";
        }

        if (unlinkButton) {
            unlinkButton.classList.add("hidden");
        }
    };

    const setLinked = username => {
        const cleanUsername =
            String(username || "").trim();

        const referralBox =
            document.getElementById(
                "profileDiscordReferralBox"
            );

        if (referralBox) {
            referralBox.classList.remove(
                "hidden"
            );
        }

        loadDiscordReferralProfile(
            false
        );

        if (mainButton) {
            mainButton.innerHTML =
                "<span>✅ Discord Linked</span>";

            mainButton.removeAttribute(
                "href"
            );

            mainButton.classList.add(
                "discord-linked"
            );

            mainButton.setAttribute(
                "aria-disabled",
                "true"
            );

            mainButton.title =
                cleanUsername
                    ? `Linked to Discord: ${cleanUsername}`
                    : "Discord account linked";
        }

        if (profileButton) {
            profileButton.textContent =
                cleanUsername
                    ? `✅ Discord Linked — ${cleanUsername}`
                    : "✅ Discord Linked";

            profileButton.removeAttribute(
                "href"
            );

            profileButton.classList.add(
                "discord-linked"
            );

            profileButton.setAttribute(
                "aria-disabled",
                "true"
            );

            profileButton.title =
                cleanUsername
                    ? `Linked to Discord: ${cleanUsername}`
                    : "Discord account linked";
        }

        if (unlinkButton) {
            unlinkButton.classList.remove("hidden");
        }
    };

    if (unlinkButton) {
        unlinkButton.addEventListener("click", async () => {
            if (!window.confirm("Unlink Discord from this Best Pokies account?")) {
                return;
            }

            unlinkButton.disabled = true;
            unlinkButton.textContent = "Unlinking…";

            try {
                const response = await fetch("discord-unlink.php", {
                    method: "POST",
                    credentials: "same-origin",
                    headers: {"Accept": "application/json"}
                });
                const result = await response.json();

                if (!response.ok || !result.ok) {
                    throw new Error(result.error || "Could not unlink Discord.");
                }

                setNotLinked();
            } catch (error) {
                window.alert(error.message || "Could not unlink Discord. Please try again.");
                unlinkButton.classList.remove("hidden");
            } finally {
                unlinkButton.disabled = false;
                unlinkButton.textContent = "Unlink Discord";
            }
        });
    }

    /*
     * No Best Pokies List account is active.
     * Keep the normal Link Discord appearance.
     */
    if (!loggedIn) {
        setNotLinked();
        return;
    }

    try {
        const response =
            await fetch(
                "api/discord-link-status.php?t="
                + Date.now(),
                {
                    cache:"no-store",
                    credentials:"same-origin"
                }
            );

        const result =
            await response.json();

        if (
            !response.ok
            || !result.ok
        ) {
            throw new Error(
                result.error
                || `Discord status HTTP ${response.status}`
            );
        }

        if (result.linked) {
            setLinked(
                result.discordUsername
            );
        } else {
            setNotLinked();
        }

    } catch (error) {
        console.warn(
            "Discord link status check failed:",
            error
        );

        /*
         * Failure to check Discord must never
         * interfere with the rest of the homepage.
         */
        setNotLinked();
    }
}


const domainSearchInput =
    document.getElementById(
        "domainSearchInput"
    );

const domainSearchClear =
    document.getElementById(
        "domainSearchClear"
    );

let domainSearchRenderTimer = null;
let searchSwitchedView = false;

function restoreViewAfterSearch() {
    if (searchSwitchedView && !domainSearchQuery.trim() && viewMode === "one") {
        viewMode = "default";
        updateViewButton();
    }
    searchSwitchedView = false;
}

function applyDomainSearch(value) {
    domainSearchQuery =
        String(value || "");

    updateDomainSearchClearButton();

    /*
     * Search results use the catalogue view rather than
     * leaving empty holes throughout curated sections.
     */
    if (
        domainSearchQuery.trim() &&
        viewMode === "default"
    ) {
        viewMode = "one";
        searchSwitchedView = true;
        updateViewButton();
    }

    if (!domainSearchQuery.trim()) {
        restoreViewAfterSearch();
    }

    clearTimeout(
        domainSearchRenderTimer
    );

    /*
     * Tiny debounce keeps typing smooth on mobile even
     * with hundreds of domains.
     */
    domainSearchRenderTimer =
        setTimeout(() => {
            render();
        }, 70);
}

domainSearchInput?.addEventListener(
    "input",
    event => {
        applyDomainSearch(
            event.target.value
        );
    }
);

domainSearchInput?.addEventListener(
    "search",
    event => {
        applyDomainSearch(
            event.target.value
        );
    }
);

domainSearchClear?.addEventListener(
    "click",
    () => {
        domainSearchQuery = "";

        if (domainSearchInput) {
            domainSearchInput.value = "";
            domainSearchInput.focus();
        }

        updateDomainSearchClearButton();
        restoreViewAfterSearch();
        render();
    }
);

updateDomainSearchClearButton();


const sortFilterButton = document.getElementById("sortFilterButton");
/* BPL_SCROLL_LOCK (2026-10-31): iOS-safe page lock for overlays
   (Community drawer, Sort/Filter). iOS Safari ignores overflow:hidden on
   html/body, so a drag that reaches the end of an inner list (or starts on
   a header/backdrop) scrolled the homepage behind. While any overlay holds
   the lock: body is position:fixed at -scrollY (restored exactly on
   release) and vertical touchmoves are cancelled unless an element inside
   the overlay can still scroll that way. */
(function () {
    const holders = new Map();
    let savedY = 0;
    let startX = 0;
    let startY = 0;
    const scrollableY = el => {
        const style = getComputedStyle(el);
        return /(auto|scroll)/.test(style.overflowY) && el.scrollHeight > el.clientHeight + 1;
    };
    const onTouchStart = event => {
        const t = event.touches && event.touches[0];
        if (!t) return;
        startX = t.clientX;
        startY = t.clientY;
    };
    const onTouchMove = event => {
        if (!holders.size || !event.cancelable) return;
        const t = event.touches && event.touches[0];
        if (!t || event.touches.length > 1) return;
        const dx = t.clientX - startX;
        const dy = t.clientY - startY;
        if (Math.abs(dx) > Math.abs(dy)) return; /* horizontal (tab bars) */
        let root = null;
        for (const el of holders.values()) {
            if (el && el.contains(event.target)) { root = el; break; }
        }
        for (let el = event.target; root && el && el !== root.parentElement; el = el.parentElement) {
            if (el.nodeType !== 1 || !scrollableY(el)) continue;
            if (dy > 0 && el.scrollTop > 0) return;
            if (dy < 0 && el.scrollTop + el.clientHeight < el.scrollHeight - 1) return;
            if (dy === 0) return;
        }
        event.preventDefault();
    };
    window.bplScrollLock = function (key, on, rootEl) {
        const html = document.documentElement;
        const body = document.body;
        if (on) {
            if (holders.has(key)) { holders.set(key, rootEl || holders.get(key)); return; }
            holders.set(key, rootEl || null);
            if (holders.size > 1) return;
            savedY = window.scrollY || window.pageYOffset || 0;
            body.style.position = "fixed";
            body.style.top = `-${savedY}px`;
            body.style.left = "0";
            body.style.right = "0";
            body.style.width = "100%";
            html.classList.add("bpl-scroll-locked");
            document.addEventListener("touchstart", onTouchStart, {passive: true, capture: true});
            document.addEventListener("touchmove", onTouchMove, {passive: false, capture: true});
        } else {
            if (!holders.delete(key) || holders.size) return;
            document.removeEventListener("touchstart", onTouchStart, {capture: true});
            document.removeEventListener("touchmove", onTouchMove, {capture: true});
            html.classList.remove("bpl-scroll-locked");
            body.style.position = "";
            body.style.top = "";
            body.style.left = "";
            body.style.right = "";
            body.style.width = "";
            const previous = html.style.scrollBehavior;
            html.style.scrollBehavior = "auto";
            window.scrollTo(0, savedY);
            html.style.scrollBehavior = previous;
        }
    };
})();

const sortFilterMenu = document.getElementById("sortFilterMenu");
const closeSortFilterButton = document.getElementById("closeSortFilter");
const sortFilterResetButton = document.getElementById("sortFilterReset");
const sortFilterApplyButton = document.getElementById("sortFilterApply");

function syncSortFilterForm() {
    const selected = document.querySelector(
        `input[name="domainSort"][value="${domainSortMode}"]`
    );
    if (selected) selected.checked = true;

    const notVisited = document.getElementById("filterNotVisited");
    const signup = document.getElementById("filterSignupBonus");
    const bonusDisplay = document.querySelector(
        `input[name="bonusDisplay"][value="${bonusDisplayMode}"]`
    );

    if (notVisited) notVisited.checked = filterNotVisitedOnly;
    if (signup) signup.checked = filterSignupBonusOnly;
    if (bonusDisplay) bonusDisplay.checked = true;
    refreshChosenBonusSortLabels();
}

function refreshChosenBonusSortLabels() {
    const names = {
        none: "Chosen bonus",
        signup: "Signup",
        share: "Share",
        commission: "Commission",
        referral: "Referral",
        rebate: "Rebate"
    };
    const value = document.querySelector('input[name="bonusDisplay"]:checked')?.value || "none";
    const name = names[value] || "Chosen bonus";
    const amount = document.getElementById("sortBonusAmountLabel");
    const max = document.getElementById("sortBonusMaxLabel");
    const turn = document.getElementById("sortBonusTurnoverLabel");
    if (amount) amount.textContent = `${name} — biggest amount`;
    if (max) max.textContent = `${name} — highest max`;
    if (turn) turn.textContent = `${name} — lowest turnover`;
}

const CARD_COLORS = ["classic","pink","blue","purple","green","teal","yellow","gold","orange","red","white"];

function savedCardColor() {
    try {
        localStorage.removeItem("bplCardColor");
        const stored = localStorage.getItem("bplCardColorChoice");
        if (CARD_COLORS.includes(stored)) return stored;
    } catch (error) {}
    return "classic";
}

let cardColor = savedCardColor();

function applyCardColor(next, {persist = false} = {}) {
    cardColor = CARD_COLORS.includes(next) ? next : "classic";
    document.documentElement.dataset.cardColor = cardColor;
    if (persist) {
        try { localStorage.setItem("bplCardColorChoice", cardColor); } catch (error) {}
    }
    syncCardColorSwatches();
}

function syncCardColorSwatches() {
    document.querySelectorAll("#cardColorRow [data-card-color]").forEach(button => {
        const on = button.dataset.cardColor === cardColor;
        button.classList.toggle("is-selected", on);
        button.setAttribute("aria-pressed", on ? "true" : "false");
    });
}

applyCardColor(cardColor);

function closeSortFilterMenu() {
    sortFilterMenu?.classList.add("hidden");
    window.bplScrollLock("sortFilter", false);
}

const compactToolbarQuery = window.matchMedia("(max-width:600px)");
const quickToggleIds = ["notVisitedButton", "viewButton", "walletButton"];

function placeQuickToggles() {
    const quick = document.getElementById("sortFilterQuick");
    const row = quick?.querySelector(".sort-filter-quick-row");
    const toolbarRow = document.getElementById("loggedInControls");
    if (!quick || !row || !toolbarRow) return;
    const compact = compactToolbarQuery.matches;
    for (const id of quickToggleIds) {
        const button = document.getElementById(id);
        if (!button) continue;
        if (compact && button.parentElement !== row) row.append(button);
        if (!compact && button.parentElement === row) toolbarRow.insertBefore(button, sortFilterButton);
    }
    quick.hidden = !compact;
}

placeQuickToggles();
compactToolbarQuery.addEventListener?.("change", placeQuickToggles);

sortFilterButton?.addEventListener("click", () => {
    syncSortFilterForm();
    syncCardColorSwatches();
    sortFilterMenu?.classList.remove("hidden");
    window.bplScrollLock("sortFilter", true, sortFilterMenu);
});

document.getElementById("cardColorRow")?.addEventListener("click", event => {
    const button = event.target.closest("[data-card-color]");
    if (!button) return;
    applyCardColor(button.dataset.cardColor, {persist: true});
});

document.querySelectorAll('input[name="bonusDisplay"]').forEach(input => {
    input.addEventListener("change", refreshChosenBonusSortLabels);
});

closeSortFilterButton?.addEventListener("click", closeSortFilterMenu);

sortFilterMenu?.addEventListener("click", event => {
    if (event.target === sortFilterMenu) {
        closeSortFilterMenu();
    }
});

sortFilterResetButton?.addEventListener("click", () => {
    const defaultRadio = document.querySelector(
        'input[name="domainSort"][value="default"]'
    );
    if (defaultRadio) defaultRadio.checked = true;

    const notVisited = document.getElementById("filterNotVisited");
    const signup = document.getElementById("filterSignupBonus");
    const noBonus = document.querySelector(
        'input[name="bonusDisplay"][value="none"]'
    );
    if (notVisited) notVisited.checked = false;
    if (signup) signup.checked = false;
    if (noBonus) noBonus.checked = true;
});

sortFilterApplyButton?.addEventListener("click", async () => {
    const chosen = document.querySelector('input[name="domainSort"]:checked');
    const nextSort = chosen?.value || "default";
    const nextNotVisited = Boolean(
        document.getElementById("filterNotVisited")?.checked
    );
    const nextSignup = Boolean(
        document.getElementById("filterSignupBonus")?.checked
    );
    const nextBonusDisplay =
        document.querySelector('input[name="bonusDisplay"]:checked')?.value || "none";

    if (sortRequiresSelectedBonus(nextSort) && nextBonusDisplay === "none") {
        alert("Pick Signup, Share, Commission, Referral, or Rebate first. That bonus is what this sort uses, on the list and in the fetcher.");
        return;
    }

    if (nextNotVisited && !loggedIn) {
        alert("Please complete at least one fetch in the Bonus Fetcher first. Not Visited is an account feature.");
        return;
    }

    domainSortMode = nextSort;
    filterNotVisitedOnly = nextNotVisited;
    filterSignupBonusOnly = nextSignup;
    bonusDisplayMode = ["none", "signup", "share", "commission", "referral", "rebate"].includes(nextBonusDisplay)
        ? nextBonusDisplay
        : "none";

    sortFilterApplyButton.disabled = true;

    try {
        const ready = await ensureSortFilterDataLoaded();
        if (!ready) {
            syncSortFilterForm();
            return;
        }

        /*
         * Sorted/filtered results are shown as one clean flat catalogue,
         * rather than trying to scramble the curated Default sections.
         */
        if (sortFilterIsActive() && viewMode === "default") {
            viewMode = "one";
            updateViewButton();
        }

        /* BPL_BONUS_SORT_AUTO_WALLETS: a chosen bonus (display or the
           "chosen bonus" sorts) turns Wallets on, same as the toggle. */
        if (loggedIn && !walletMode &&
            (bonusDisplayMode !== "none" || sortRequiresSelectedBonus(domainSortMode))) {
            if (!walletDataLoaded) await loadWalletData();
            if (viewMode === "default") viewMode = "one";
            walletMode = true;
            updateViewButton();
            updateWalletButton();
        }

        /* BPL_BONUS_ONE_COLUMN: bonus views need 1 column. */
        if (bonusViewActive() && viewIsMultiColumn(viewMode)) {
            viewMode = "one";
            updateViewButton();
            bplViewToast("Switched to 1 column for bonus view");
        }

        updateSortFilterButton();
        closeSortFilterMenu();
        render();
        rememberWalletSort();
    } catch (error) {
        console.error(error);
        alert(error.message || "Could not apply sort/filter.");
    } finally {
        sortFilterApplyButton.disabled = false;
    }
});


async function loadAccount(options = {}) {

    const renderAfter =
        options.renderAfter !== false;

    try {

        const response =

            await fetch(

                "api/me.php",

                {

                    cache:"no-store",
                    credentials:"same-origin"

                }

            );

        const result =

            await response.json();

        if (!response.ok || !result.ok) {
            throw new Error(result.error || `Account API HTTP ${response.status}`);
        }

        loggedIn = Boolean(result.loggedIn);
        currentAccountKey = loggedIn
            ? String(result.account?.key ?? result.accountKey ?? "") || null
            : null;
        currentMaskedPhone = loggedIn
            ? String(result.account?.maskedPhone ?? result.maskedPhone ?? "")
            : "";

        await syncDiscordLinkButtons();

        if (loggedIn) {

            $("#loggedInControls")
                .classList
                .remove("hidden");
            document.getElementById("accountHelpBanner")?.classList.add("hidden");

            


const profileButton = document.getElementById("profileButton");
            if (profileButton) profileButton.classList.remove("hidden");
            const profilePhone = document.getElementById("profilePhone");
            if (profilePhone) {
                profilePhone.textContent = currentMaskedPhone
                    ? `📱 ${currentMaskedPhone}`
                    : "📱 Logged in";
            }

            await fetchVisitedDomainsFromServer();

        }

        else {

            $("#loggedInControls")
                .classList
                .remove("hidden");
            document.getElementById("accountHelpBanner")?.classList.remove("hidden");

            visitedDomains =

                new Set();

            currentAccountKey = null;
            currentMaskedPhone = "";
            document.getElementById("profileMenu")?.classList.add("hidden");
            walletMode = false;
            walletDataLoaded = false;
            walletDataByDomain = new Map();
            walletIdentityCatalog = [];
            walletSavedAt = 0;
            domainSortMode = "default";
            filterNotVisitedOnly = false;
            filterSignupBonusOnly = false;
            bonusDisplayMode = "none";

            notVisitedMode =

                false;

        }

        updateNotVisitedButton();
        updateWalletButton();
        updateSortFilterButton();
        updatePromoterRentLauncher();

        if (renderAfter) {
            render();
        }

    }

    catch(error) {

        console.error(

            "Account load failed:",

            error

        );

        if (renderAfter) {
            render();
        }

    }

}

function updateNotVisitedButton() {

    const button =

        $("#notVisitedButton");

    button.textContent =

        "● Not Visited: " +

        (

            notVisitedMode

                ? "On"

                : "Off"

        );

    button.classList.toggle(

        "active",

        notVisitedMode

    );

    const stats = document.getElementById("visitStats");
    if (stats) stats.classList.toggle("hidden", !notVisitedMode);

}


$("#notVisitedButton")

    .addEventListener(

        "click",

        () => {
            if (!loggedIn) {
                alert("Please sign in first through the Bonus Fetcher. No fetch is required.");
                return;
            }

            notVisitedMode =

                !notVisitedMode;

            updateNotVisitedButton();

            render();

        }

    );

const viewButton = document.getElementById("viewButton");
if (viewButton) {
    viewButton.addEventListener("click", async () => {
        const index = VIEW_MODES.indexOf(viewMode);
        const next = VIEW_MODES[(index + 1) % VIEW_MODES.length];

        if (
            loggedIn &&
            next !== "default" &&
            !walletDataLoaded
        ) {
            try {
                await loadWalletData();
            } catch (error) {
                console.warn("Could not preload account bonus data:", error);
            }
        }

        setViewMode(next);
    });
}

const walletButton = document.getElementById("walletButton");
if (walletButton) {
    walletButton.addEventListener("click", async () => {
        if (!loggedIn) {
            openFetcher();
            return;
        }
        walletButton.disabled = true;
        try {
            if (!walletMode && !walletDataLoaded) {
                walletButton.textContent = "💰 Loading…";
                await loadWalletData();
            }
            if (!walletMode && viewMode === "default") {
                viewMode = "one";
            }
            walletMode = !walletMode;
            updateViewButton();
            updateWalletButton();
            render();
        } catch (error) {
            console.error(error);
            alert(error.message || "Could not load wallet data.");
            updateWalletButton();
        } finally {
            walletButton.disabled = false;
        }
    });
}

const FETCHER_ASSET_VERSION = "1794964431";
const fetcherState = {booted:false, busy:false, pendingShop:false, visible:true};

function bootFetcher() {
    if (fetcherState.booted || !window.BPLFetcherBoot || !document.getElementById("runBtn")) return;
    fetcherState.booted = true;
    window.BPLFetcherBoot({loggedIn: true, openShop: fetcherState.pendingShop});
}

function loadFetcherScript() {
    if (!document.getElementById("bplFetcher")) return;
    const script = document.createElement("script");
    script.src = `fetcher-panel.js?v=${encodeURIComponent(FETCHER_ASSET_VERSION)}`;
    script.async = true;
    script.onload = bootFetcher;
    document.head.appendChild(script);
}

if (document.readyState === "complete") loadFetcherScript();
else window.addEventListener("load", loadFetcherScript, {once:true});

/*
 * Sections start minimised on a fresh visit; within the same tab session
 * (including when a phone discards and reloads the page in the background)
 * the scroll position and section state come back.
 */
const SCROLL_STATE_KEY = "bplScrollState";
const skipScrollRestore = Boolean(location.hash) || new URLSearchParams(location.search).has("fetcher");
let scrollStateReady = false;
let scrollSaveTimer = 0;

try {
    localStorage.removeItem("bplFetcherCollapsed");
    localStorage.removeItem("bplHubOpen");
} catch (error) {}
if ("scrollRestoration" in history) history.scrollRestoration = "manual";

function scrollAnchorTop() {
    const sticky = document.querySelector(".toolbar");
    if (!sticky) return 0;
    const style = getComputedStyle(sticky);
    if (style.position !== "sticky") return 0;
    const rect = sticky.getBoundingClientRect();
    const stuckTop = parseFloat(style.top) || 0;
    return rect.top <= stuckTop + 1 ? Math.max(0, rect.bottom) : 0;
}

function saveScrollState() {
    if (!scrollStateReady) return;
    const state = {y: Math.round(scrollY)};
    const top = scrollAnchorTop();
    const card = [...groupsElement.querySelectorAll(".card[data-domain]")]
        .find(el => el.getBoundingClientRect().bottom > top + 8);
    if (card && scrollY > 0) {
        const same = [...groupsElement.querySelectorAll(`.card[data-domain="${CSS.escape(card.dataset.domain)}"]`)];
        state.domain = card.dataset.domain;
        state.index = same.indexOf(card);
        state.offset = Math.round(card.getBoundingClientRect().top);
    }
    try { sessionStorage.setItem(SCROLL_STATE_KEY, JSON.stringify(state)); } catch (error) {}
}

window.addEventListener("scroll", () => {
    clearTimeout(scrollSaveTimer);
    scrollSaveTimer = setTimeout(saveScrollState, 150);
}, {passive:true});
window.addEventListener("pagehide", saveScrollState);
document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") saveScrollState();
});

function restoreScrollState() {
    let state = null;
    try { state = JSON.parse(sessionStorage.getItem(SCROLL_STATE_KEY) || "null"); } catch (error) {}
    if (skipScrollRestore || !state || !(state.y > 0)) {
        scrollStateReady = true;
        return;
    }

    const apply = () => {
        if (Array.isArray(window.bplDirectoryFillers)) {
            window.bplDirectoryFillers.forEach(fn => { try { fn(); } catch (error) {} });
        }
        let target = state.y;
        if (state.domain) {
            const same = groupsElement.querySelectorAll(`.card[data-domain="${CSS.escape(state.domain)}"]`);
            const card = same[state.index] || same[0];
            if (card) target = scrollY + card.getBoundingClientRect().top - state.offset;
        }
        window.scrollTo(0, Math.max(0, target));
    };

    /* Late content (community row, wallet data) can shift the page, so keep
       re-applying briefly until the user takes over. */
    let settling = true;
    const stop = () => {
        if (!settling) return;
        settling = false;
        scrollStateReady = true;
        ["touchstart", "wheel", "keydown", "mousedown"].forEach(type => removeEventListener(type, stop, true));
    };
    ["touchstart", "wheel", "keydown", "mousedown"].forEach(type => addEventListener(type, stop, {capture:true, passive:true}));
    apply();
    let ticks = 0;
    const timer = setInterval(() => {
        if (!settling || ++ticks > 20) {
            clearInterval(timer);
            stop();
            return;
        }
        apply();
    }, 150);
}

function setFetcherCollapsed(collapsed) {
    const section = document.getElementById("bplFetcher");
    const toggle = document.getElementById("bfCollapse");
    if (!section || !toggle) return;
    section.classList.toggle("bf-collapsed", collapsed);
    toggle.textContent = collapsed ? "Show ▾" : "Hide ▴";
    toggle.setAttribute("aria-expanded", String(!collapsed));
    try { sessionStorage.setItem("bplFetcherCollapsed", collapsed ? "1" : "0"); } catch (error) {}
}

{
    const section = document.getElementById("bplFetcher");
    const toggle = document.getElementById("bfCollapse");
    if (section && toggle) {
        if (!loggedIn) setFetcherCollapsed(false);
        else {
            let remember = null;
            try { remember = sessionStorage.getItem("bplFetcherCollapsed"); } catch (error) {}
            setFetcherCollapsed(remember === "0" ? false : true);
        }
        toggle.addEventListener("click", () => setFetcherCollapsed(!section.classList.contains("bf-collapsed")));
    }
}

function openFetcher({shop = false, focus = true} = {}) {
    const section = document.getElementById("bplFetcher");
    if (!section) return;
    setFetcherCollapsed(false);
    section.scrollIntoView({behavior:"smooth", block:"start"});
    if (shop) {
        if (fetcherState.booted) document.getElementById("buyFetchesBtn")?.click();
        else fetcherState.pendingShop = true;
        return;
    }
    const phone = document.getElementById("phoneInput");
    // Only focus the phone box when the user tapped something (not on page load:
    // on iPhone home-screen apps that popped the keyboard every launch).
    if (focus && phone && !phone.value && !loggedIn) setTimeout(() => phone.focus({preventScroll:true}), 350);
}

function updateFetcherPill() {
    let pill = document.getElementById("bplFetcherPill");
    if (!pill) {
        if (!fetcherState.busy) return;
        pill = document.createElement("button");
        pill.id = "bplFetcherPill";
        pill.type = "button";
        pill.className = "bfp-pill";
        pill.textContent = "⚡ Fetching your bonuses… tap to view";
        pill.addEventListener("click", () => openFetcher());
        document.body.appendChild(pill);
    }
    pill.hidden = !fetcherState.busy || fetcherState.visible;
}

if ("IntersectionObserver" in window && document.getElementById("bplFetcher")) {
    new IntersectionObserver(entries => {
        fetcherState.visible = entries.some(entry => entry.isIntersecting);
        updateFetcherPill();
    }).observe(document.getElementById("bplFetcher"));
}

async function showFetchOnCards() {
    if (!loggedIn) await loadAccount({renderAfter:false});
    if (!loggedIn) return false;
    try {
        walletDataLoaded = false;
        await loadWalletData();
        walletMode = true;
        if (viewMode === "default") viewMode = "one";
        updateViewButton();
        updateWalletButton();
        render();
        return true;
    } catch (error) {
        console.error(error);
        return false;
    }
}

window.openBonusFetcher = openFetcher;

window.addEventListener("bpl:fetcher-login", () => {
    loadAccount();
});

window.addEventListener("bpl:fetcher-busy", event => {
    fetcherState.busy = Boolean(event.detail);
    updateFetcherPill();
    if (fetcherState.busy) document.getElementById("bplFetcherDone")?.classList.add("hidden");
});

window.addEventListener("bpl:fetcher-saved", event => {
    const detail = event.detail || {};
    const parts = [];
    if (detail.withData) parts.push(`${detail.withData} with bonuses`);
    if (detail.empty) parts.push(`${detail.empty} empty`);
    if (detail.errors) parts.push(`${detail.errors} to fix`);
    showFetcherFoldNote(parts.join(" · "));
    // Refresh wallet rows and savedAt so cards show the just-saved fetch state.
    // Invalidate the short cache first; otherwise a save within 20 seconds of
    // the previous account-data load leaves the cards and timestamp stale.
    walletDataLoaded = false;
    loadWalletData().catch(() => {});
});

window.addEventListener("bpl:fetcher-show-cards", async () => {
    if (await showFetchOnCards()) {
        document.getElementById("groups")?.scrollIntoView({behavior:"smooth", block:"start"});
    } else {
        alert("No saved fetch yet. Run the Bonus Fetcher first, then your balances and bonuses will show on the casino cards.");
    }
});

document.addEventListener("click", event => {
    if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const link = event.target.closest("a[href]");
    if (!link) return;
    const href = link.getAttribute("href") || "";
    if (!/^\/?bonus-fetch\.php(#[\w-]*)?$/.test(href) && href !== "#bplFetcher") return;
    event.preventDefault();
    if (link.closest("#topUtilityMenu")) closeSideDrawerBeforeAction();
    openFetcher({shop: href.endsWith("#buy-fetches")});
}, true);

{
    const params = new URLSearchParams(location.search);
    if (params.has("fetcher")) {
        const shop = location.hash === "#buy-fetches";
        params.delete("fetcher");
        const query = params.toString();
        history.replaceState(null, "", location.pathname + (query ? `?${query}` : ""));
        window.addEventListener("load", () => setTimeout(() => openFetcher({shop, focus:false}), 300), {once:true});
    }
}

const profileButton = document.getElementById("profileButton");
const profileMenu = document.getElementById("profileMenu");
const closeProfileButton = document.getElementById("closeProfile");
const profileLogoutButton = document.getElementById("profileLogoutButton");

function closeProfileMenu() {
    profileMenu?.classList.add("hidden");
}

profileButton?.addEventListener("click", async () => {

    /*
     * The homepage may have been restored from the browser's
     * back/forward cache after the user logged in through the
     * Bonus Fetcher. Recheck the server before deciding that
     * no account is active.
     */
    if (!loggedIn) {
        await loadAccount({
            renderAfter:false
        });
    }

    if (!loggedIn) {
        openFetcher();
        return;
    }

    profileMenu?.classList.toggle("hidden");
    if (profileMenu && !profileMenu.classList.contains("hidden")) loadProfilePhones();
});

async function loadProfilePhones() {
    const list = document.getElementById("profilePhonesList");
    const message = document.getElementById("profilePhoneMessage");
    if (!list) return;
    list.innerHTML = "<li>Loading…</li>";
    try {
        const response = await fetch("api/account-phones.php", {credentials:"same-origin", cache:"no-store"});
        const data = await response.json();
        if (!response.ok || !data.ok) {
            list.innerHTML = "<li>Couldn’t load phone numbers.</li>";
            return;
        }
        list.innerHTML = "";
        for (const phone of data.phones || []) {
            const item = document.createElement("li");
            item.textContent = phone.phone + (phone.primary ? " (primary)" : "");
            list.appendChild(item);
        }
        if (!list.children.length) list.innerHTML = "<li>No phone number is linked yet.</li>";
        if (message && !message.dataset.hold) message.textContent = "";
    } catch (error) {
        list.innerHTML = "<li>Couldn’t load phone numbers.</li>";
    }
}

let profileMergeGrant = "";

document.getElementById("profileAddPhoneForm")?.addEventListener("submit", async event => {
    event.preventDefault();
    const input = document.getElementById("profileAddPhoneInput");
    const password = document.getElementById("profileAddPhonePassword");
    const message = document.getElementById("profilePhoneMessage");
    const button = document.getElementById("profileAddPhoneButton");
    const confirmBox = document.getElementById("profileMergeConfirm");
    const phone = (input?.value || "").trim();
    if (!phone || !password?.value || !message || !button) {
        if (message) message.textContent = "Enter the phone number and password for the other account.";
        return;
    }
    button.disabled = true;
    message.dataset.hold = "1";
    message.textContent = "Checking that account…";
    try {
        const response = await fetch("api/account-phones.php", {
            method: "POST",
            credentials: "same-origin",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({action: "verify", phone, password: password.value})
        });
        const data = await response.json();
        password.value = "";
        if (data.status === "verified" && data.grant) {
            profileMergeGrant = data.grant;
            if (confirmBox) confirmBox.classList.remove("hidden");
            message.textContent = "Account verified.";
            return;
        }
        profileMergeGrant = "";
        if (confirmBox) confirmBox.classList.add("hidden");
        message.textContent = data.error || "That number was not added.";
        if (data.ok) {
            if (input) input.value = "";
            await loadProfilePhones();
        }
    } catch (error) {
        message.textContent = "That number was not added.";
    } finally {
        button.disabled = false;
    }
});

document.getElementById("profileMergeCancel")?.addEventListener("click", async () => {
    const message = document.getElementById("profilePhoneMessage");
    const confirmBox = document.getElementById("profileMergeConfirm");
    const grant = profileMergeGrant;
    profileMergeGrant = "";
    if (confirmBox) confirmBox.classList.add("hidden");
    if (message) message.textContent = "Merge cancelled. Both accounts are unchanged.";
    if (!grant) return;
    try {
        await fetch("api/account-phones.php", {
            method: "POST",
            credentials: "same-origin",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({action: "cancel", grant})
        });
    } catch (error) {}
});

document.getElementById("profileMergeConfirmButton")?.addEventListener("click", async () => {
    const message = document.getElementById("profilePhoneMessage");
    const button = document.getElementById("profileMergeConfirmButton");
    const confirmBox = document.getElementById("profileMergeConfirm");
    const input = document.getElementById("profileAddPhoneInput");
    if (!profileMergeGrant || !message || !button) return;
    button.disabled = true;
    message.textContent = "Merging accounts…";
    try {
        const response = await fetch("api/account-phones.php", {
            method: "POST",
            credentials: "same-origin",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({action: "merge", grant: profileMergeGrant})
        });
        const data = await response.json();
        message.textContent = data.error || (data.ok ? "Accounts linked. Both logins now share this profile and its balances." : "The accounts were not merged.");
        if (data.ok) {
            profileMergeGrant = "";
            if (confirmBox) confirmBox.classList.add("hidden");
            if (input) input.value = "";
            await loadProfilePhones();
        }
    } catch (error) {
        message.textContent = "The accounts were not merged. It is safe to try again.";
    } finally {
        button.disabled = false;
    }
});
closeProfileButton?.addEventListener("click", closeProfileMenu);
profileMenu?.addEventListener("click", event => {
    if (event.target === profileMenu) closeProfileMenu();
});
profileLogoutButton?.addEventListener("click", async () => {
    profileLogoutButton.disabled = true;
    profileLogoutButton.textContent = "Logging out…";
    try {
        await fetch("api/logout.php", {method:"POST", credentials:"same-origin"});
        location.reload();
    } finally {
        profileLogoutButton.disabled = false;
        profileLogoutButton.textContent = "Logout";
    }
});

window.addEventListener("focus", () => {
    syncVisitedDomainsAndRefresh();
});

document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") {
        syncVisitedDomainsAndRefresh();
    }
});

// ============================================================
// PROMOTER / REFERRAL SYSTEM
// BPL_PROMOTER_UI_V1
// ============================================================

let promoterSummary = null;
let promoterReferralLink = "";

// BPL_DOMAIN_RENT_MODE_V3
const PROMOTER_RENT_ACTION = "rent";
const RENTAL_PRICE_FALLBACK = {
    "1d": {credits:2, label:"24 hours"},
    "3d": {credits:5, label:"3 days"},
    "7d": {credits:10, label:"7 days"}
};

const TOP_RENTAL_PRICE_FALLBACK = {
    "1d": {credits:4, label:"24 hours"},
    "3d": {credits:10, label:"3 days"},
    "7d": {credits:20, label:"7 days"}
};

let domainRentalMode = false;
let selectedRentalDomain = "";
let selectedRentalSlot = 0;
let selectedRentalPeriod = "1d";
let activeRentalRows = [];
let activeRentalBySlot = new Map();
let rentalServerOffsetMs = 0;

async function promoterPost(payload) {
    const response = await fetch(
        "api/promoter.php",
        {
            method:"POST",
            headers:{
                "Content-Type":"application/json"
            },
            body:JSON.stringify(payload),
            cache:"no-store"
        }
    );

    const result = await response.json();

    if (!response.ok || !result.ok) {
        throw new Error(
            result.error ||
            `Promoter API HTTP ${response.status}`
        );
    }

    return result;
}

function rentalPlan(period) {
    const isTopRental =
        Number.isInteger(selectedRentalSlot) &&
        selectedRentalSlot >= 1 &&
        selectedRentalSlot <= 7;

    const fallback =
        isTopRental
            ? TOP_RENTAL_PRICE_FALLBACK
            : RENTAL_PRICE_FALLBACK;

    const fromServer =
        isTopRental
            ? promoterSummary?.topPrices?.[period]
            : (
                promoterSummary?.standardPrices?.[period] ||
                promoterSummary?.prices?.[period]
            );

    if (
        fromServer &&
        Number.isFinite(
            Number(fromServer.credits)
        )
    ) {
        return {
            credits:
                Number(fromServer.credits),

            label:
                String(
                    fromServer.label ||
                    fallback[period]?.label ||
                    period
                )
        };
    }

    return fallback[period] ||
        fallback["1d"];
}

function promoterCreditBalance() {
    return Number(
        promoterSummary?.creditBalance || 0
    );
}

function rentalDestination(row) {
    return String(
        row?.destinationUrl ??
        row?.referralUrl ??
        row?.url ??
        ""
    ).trim();
}

function rentalExpiry(row) {
    return Number(
        row?.expiresAt ??
        row?.expires_at ??
        0
    );
}

function activeRentalForSlot(slot) {
    const row = activeRentalBySlot.get(
        Number(slot)
    );

    if (!row) return null;

    const expiresAt = rentalExpiry(row);
    const nowSeconds =
        Math.floor(
            (Date.now() + rentalServerOffsetMs) / 1000
        );

    if (expiresAt && expiresAt <= nowSeconds) {
        activeRentalBySlot.delete(Number(slot));
        return null;
    }

    return row;
}

function rentalTimeLeftText(expiresAt) {
    expiresAt = Number(expiresAt || 0);
    if (!expiresAt) return "Rented";

    const nowSeconds =
        Math.floor(
            (Date.now() + rentalServerOffsetMs) / 1000
        );

    let left = Math.max(
        0,
        expiresAt - nowSeconds
    );

    if (left <= 0) return "Expired";

    const days = Math.floor(left / 86400);
    left %= 86400;
    const hours = Math.floor(left / 3600);
    const minutes = Math.floor(
        (left % 3600) / 60
    );

    if (days > 0) {
        return `${days}d ${hours}h left`;
    }

    if (hours > 0) {
        return `${hours}h ${minutes}m left`;
    }

    return `${Math.max(1, minutes)}m left`;
}

function rentalFaviconCandidates(destinationUrl) {
    try {
        const parsed = new URL(destinationUrl);

        return [
            "api/rental-favicon.php?url=" +
                encodeURIComponent(parsed.href),

            "https://www.google.com/s2/favicons" +
                "?sz=64&domain=" +
                encodeURIComponent(parsed.hostname),

            parsed.origin + "/favicon.ico",

            FALLBACK_ICON
        ];
    } catch {
        return [FALLBACK_ICON];
    }
}

function setRentalFavicon(icon, destinationUrl) {
    if (!icon) return;

    const candidates =
        rentalFaviconCandidates(destinationUrl);

    let index = 0;

    const tryNext = () => {
        if (index >= candidates.length) {
            icon.onerror = null;
            icon.src = FALLBACK_ICON;
            return;
        }

        icon.src = candidates[index++];
    };

    icon.onerror = tryNext;

    tryNext();
}

function applyActiveRentalToCard(
    card,
    originalItem,
    slotNumber
) {
    const rental =
        activeRentalForSlot(slotNumber);

    if (!rental) return;

    const destination =
        rentalDestination(rental);

    if (!destination) return;

    let host = "";
    try {
        host = new URL(destination).hostname;
    } catch {
        return;
    }

    card.classList.add("rented-card");
    card.dataset.rentalActive = "1";
    card.href = destination;
    card.title =
        `Rented card • opens ${host}`;

    const icon = card.querySelector(".icon");
    if (icon) {
        setRentalFavicon(icon, destination);
    }

    const domain = card.querySelector(".domain");
    if (domain) {
        domain.textContent = host;
    }

    const status = card.querySelector(
        ".domain-status"
    );

    if (status) {
        status.removeAttribute(
            "data-status-domain"
        );
        status.className =
            "domain-status rental-countdown";
        status.dataset.rentalExpiresAt =
            String(rentalExpiry(rental) || "");
        status.textContent =
            "🎟 " +
            rentalTimeLeftText(
                rentalExpiry(rental)
            );
    }

    const added = card.querySelector(
        ".domain-added"
    );
    if (added) {
        added.hidden = true;
    }
}

async function loadActiveRentals() {
    const fetchRentals = async (url, options) => {
        const response = await fetch(url, options);
        const data = await response.json();
        if (!response.ok || !data?.ok || !Array.isArray(data.rentals)) {
            throw new Error(data?.error || `Rental API HTTP ${response.status}`);
        }
        return data;
    };
    let result;
    const controller = new AbortController();
    const deadline = setTimeout(() => controller.abort(), 4000);
    try {
        result = await fetchRentals(
            "https://fetch.bestpokieslist.online/api/promoter/rentals",
            {cache:"no-store", credentials:"omit", signal:controller.signal}
        );
    } catch (error) {
        clearTimeout(deadline);
        console.warn("Direct rental load failed; using cPanel", error);
        result = await fetchRentals(
            "api/promoter.php?action=rentals&t=" + Date.now(),
            {cache:"no-store", credentials:"same-origin"}
        );
    } finally {
        clearTimeout(deadline);
    }

    activeRentalRows =
        Array.isArray(result.rentals)
            ? result.rentals
            : [];

    if (Number(result.serverTime)) {
        rentalServerOffsetMs =
            Number(result.serverTime) * 1000 -
            Date.now();
    }

    activeRentalBySlot = new Map();

    for (const row of activeRentalRows) {
        const slot = Number(
            row?.slot ??
            row?.slotNumber ??
            row?.cardSlot ??
            0
        );

        if (
            Number.isInteger(slot) &&
            slot >= 1 &&
            slot <= 19
        ) {
            activeRentalBySlot.set(slot, row);
        }
    }

    return result;
}

function updateRentalCountdowns() {
    let expiredFound = false;
    const nowSeconds =
        Math.floor(
            (Date.now() + rentalServerOffsetMs) / 1000
        );

    document.querySelectorAll(
        ".rental-countdown"
    ).forEach(element => {
        const expiresAt = Number(
            element.dataset.rentalExpiresAt || 0
        );

        if (expiresAt && expiresAt <= nowSeconds) {
            expiredFound = true;
            return;
        }

        element.textContent =
            "🎟 " +
            rentalTimeLeftText(expiresAt);
    });

    if (expiredFound) {
        loadActiveRentals()
            .then(() => render())
            .catch(error =>
                console.warn(
                    "Could not refresh expired rentals:",
                    error
                )
            );
    }
}

function updatePromoterProfile() {
    const credits =
        document.getElementById(
            "promoterCredits"
        );

    const referrals =
        document.getElementById(
            "promoterVerifiedReferrals"
        );

    const rentals =
        document.getElementById(
            "promoterActiveRentals"
        );

    const code =
        document.getElementById(
            "promoterReferralCode"
        );

    const link =
        document.getElementById(
            "promoterReferralLink"
        );

    const copyButton =
        document.getElementById(
            "copyPromoterLinkButton"
        );

    if (!promoterSummary) {
        if (credits) credits.textContent = "—";
        if (referrals) referrals.textContent = "—";
        if (rentals) rentals.textContent = "—";
        if (code) code.textContent = "—";

        if (link) {
            link.textContent =
                loggedIn
                    ? "Loading referral link…"
                    : "Login required";
        }

        if (copyButton) {
            copyButton.disabled = true;
        }

        updatePromoterRentLauncher();
        return;
    }

    const referralCode =
        String(
            promoterSummary.referralCode ||
            ""
        ).trim();

    promoterReferralLink =
        referralCode
            ? `${location.origin}/?ref=${encodeURIComponent(referralCode)}`
            : "";

    if (credits) {
        credits.textContent =
            String(
                Number(
                    promoterSummary.creditBalance ||
                    0
                )
            );
    }

    if (referrals) {
        referrals.textContent =
            String(
                Number(
                    promoterSummary.verifiedReferrals ||
                    0
                )
            );
    }

    if (rentals) {
        rentals.textContent =
            String(
                Array.isArray(
                    promoterSummary.activeRentals
                )
                    ? promoterSummary.activeRentals.length
                    : 0
            );
    }

    if (code) {
        code.textContent =
            referralCode || "—";
    }

    if (link) {
        link.textContent =
            promoterReferralLink ||
            "Referral link unavailable";
    }

    if (copyButton) {
        copyButton.disabled =
            !promoterReferralLink;
    }

    updatePromoterRentLauncher();
}

function updatePromoterRentLauncher() {
    const launcher = document.getElementById(
        "promoterRentLauncher"
    );
    const button = document.getElementById(
        "promoterRentLauncherButton"
    );
    const subtext = document.getElementById(
        "promoterRentLauncherSubtext"
    );

    if (!launcher || !button || !subtext) {
        return;
    }

    launcher.classList.remove("hidden");

    if (!loggedIn) {
        button.disabled = false;
        subtext.textContent =
            "2 credits • account required";
        return;
    }

    const credits =
        promoterCreditBalance();

    button.disabled = false;

    subtext.textContent =
        `${credits} credit${credits === 1 ? "" : "s"} • rentals from 2 credits`;
}

function exitDomainRentalMode() {
    domainRentalMode = false;

    document.body.classList.remove(
        "domain-rental-mode"
    );

    document.getElementById(
        "rentalModeBanner"
    )?.classList.add("hidden");
}

function enterDomainRentalMode() {
    if (!loggedIn) {
        alert(
            "Sign in first through the Bonus Fetcher with your pokies phone number and password. No fetch is required. Then come back here to earn credits and rent a Domain Card."
        );
        return;
    }

    if (promoterCreditBalance() < 2) {
        alert(
            "You need at least 2 credits to rent a Domain Card."
        );
        return;
    }

    if (
        viewMode !== "default" ||
        sortFilterIsActive()
    ) {
        viewMode = "default";
        domainSortMode = "default";
        filterNotVisitedOnly = false;
        filterSignupBonusOnly = false;
        updateViewButton();
        updateSortFilterButton();
        render();
    }

    domainRentalMode = true;

    document.body.classList.add(
        "domain-rental-mode"
    );

    document.getElementById(
        "rentalModeBanner"
    )?.classList.remove("hidden");

    document.querySelector(
        ".extra-rental-heading"
    )?.scrollIntoView({
        behavior:"smooth",
        block:"center"
    });
}

function closeRentalModal() {
    document.getElementById(
        "rentalModal"
    )?.classList.add("hidden");

    const error = document.getElementById(
        "rentalModalError"
    );

    if (error) error.textContent = "";
}

function selectedRentalPrice() {
    return Number(
        rentalPlan(
            selectedRentalPeriod
        ).credits || 0
    );
}

function updateRentalPurchaseUi() {
    const balance =
        promoterCreditBalance();

    const cost =
        selectedRentalPrice();

    const balanceText =
        document.getElementById(
            "rentalBalanceText"
        );

    const after =
        document.getElementById(
            "rentalAfterPurchase"
        );

    const confirm =
        document.getElementById(
            "rentalConfirmButton"
        );

    if (balanceText) {
        balanceText.textContent =
            `${balance} credit${balance === 1 ? "" : "s"}`;
    }

    if (after) {
        after.textContent =
            balance >= cost
                ? `After purchase: ${balance - cost} credit${balance - cost === 1 ? "" : "s"}`
                : `You need ${cost - balance} more credit${cost - balance === 1 ? "" : "s"}`;
    }

    if (confirm) {
        confirm.textContent =
            `Rent Card — ${cost} Credits`;
        confirm.disabled =
            balance < cost;
    }

    document.querySelectorAll(
        "[data-rental-period]"
    ).forEach(button => {
        const period =
            button.dataset.rentalPeriod ||
            "1d";

        button.classList.toggle(
            "selected",
            period === selectedRentalPeriod
        );

        const price =
            rentalPlan(period);

        const priceText =
            button.querySelector("span");

        if (priceText) {
            priceText.textContent =
                `${price.credits} credit${
                    Number(price.credits) === 1
                        ? ""
                        : "s"
                }`;
        }
    });
}

function openRentalModal(card) {
    selectedRentalDomain = String(
        card?.dataset?.domain || ""
    ).trim();

    selectedRentalSlot = Number(
        card?.dataset?.rentalSlot || 0
    );

    if (
        !selectedRentalDomain ||
        !Number.isInteger(selectedRentalSlot) ||
        selectedRentalSlot < 1 ||
        selectedRentalSlot > 19
    ) {
        return;
    }

    if (
        activeRentalForSlot(
            selectedRentalSlot
        )
    ) {
        alert(
            "That card is already rented. Choose another available card."
        );
        return;
    }

    selectedRentalPeriod = "1d";

    const selected =
        document.getElementById(
            "rentalSelectedDomain"
        );

    const input =
        document.getElementById(
            "rentalReferralInput"
        );

    const error =
        document.getElementById(
            "rentalModalError"
        );

    if (selected) {
        selected.textContent =
            `Slot ${selectedRentalSlot} • ${selectedRentalDomain}`;
    }

    if (input) {
        input.value = "";
    }

    if (error) {
        error.textContent = "";
    }

    updateRentalPurchaseUi();

    document.getElementById(
        "rentalModal"
    )?.classList.remove("hidden");

    setTimeout(
        () => input?.focus(),
        80
    );
}

function validateRentalReferralUrl(rawUrl) {
    const value =
        String(
            rawUrl || ""
        ).trim();

    if (!value) {
        throw new Error(
            "Paste the URL you want to use first."
        );
    }

    let parsed;

    try {
        parsed = new URL(value);
    } catch {
        throw new Error(
            "Enter a complete URL starting with https:// or http://"
        );
    }

    if (
        !["https:", "http:"].includes(
            parsed.protocol
        )
    ) {
        throw new Error(
            "Only http:// and https:// URLs are allowed."
        );
    }

    if (!parsed.hostname) {
        throw new Error(
            "That URL does not contain a valid hostname."
        );
    }

    return parsed.href;
}

async function confirmDomainCardRental() {
    const input =
        document.getElementById(
            "rentalReferralInput"
        );

    const button =
        document.getElementById(
            "rentalConfirmButton"
        );

    const error =
        document.getElementById(
            "rentalModalError"
        );

    if (
        !Number.isInteger(selectedRentalSlot) ||
        selectedRentalSlot < 1 ||
        selectedRentalSlot > 19
    ) {
        return;
    }

    let destinationUrl;

    try {
        destinationUrl =
            validateRentalReferralUrl(
                input?.value
            );
    } catch (validationError) {
        if (error) {
            error.textContent =
                validationError.message;
        }
        return;
    }

    const cost =
        selectedRentalPrice();

    if (
        promoterCreditBalance() < cost
    ) {
        if (error) {
            error.textContent =
                "You no longer have enough credits for this rental.";
        }
        return;
    }

    if (button) {
        button.disabled = true;
        button.textContent =
            "Creating rental…";
    }

    if (error) {
        error.textContent = "";
    }

    try {
        await promoterPost({
            action:PROMOTER_RENT_ACTION,
            slot:selectedRentalSlot,
            destinationUrl,
            period:selectedRentalPeriod
        });

        closeRentalModal();
        exitDomainRentalMode();

        await Promise.all([
            loadPromoterSummary(),
            loadActiveRentals()
        ]);

        render();

        alert(
            `Rental activated for slot ${selectedRentalSlot}.`
        );
    } catch (requestError) {
        console.error(
            "Could not create Domain Card rental:",
            requestError
        );

        if (error) {
            error.textContent =
                requestError.message ||
                "Could not create the rental.";
        }
    } finally {
        updateRentalPurchaseUi();
    }
}

function bindDomainRentalUi() {
    const rentalInfoModal = document.getElementById(
        "rentalInfoModal"
    );

    document.getElementById(
        "promoterRentInfoButton"
    )?.addEventListener(
        "click",
        () => rentalInfoModal?.classList.remove("hidden")
    );

    document.getElementById(
        "rentalInfoModalClose"
    )?.addEventListener(
        "click",
        () => rentalInfoModal?.classList.add("hidden")
    );

    rentalInfoModal?.addEventListener(
        "click",
        event => {
            if (event.target === rentalInfoModal) {
                rentalInfoModal.classList.add("hidden");
            }
        }
    );

    document.getElementById(
        "promoterRentLauncherButton"
    )?.addEventListener(
        "click",
        enterDomainRentalMode
    );

    document.getElementById(
        "rentalModeCancel"
    )?.addEventListener(
        "click",
        exitDomainRentalMode
    );

    document.getElementById(
        "rentalModalClose"
    )?.addEventListener(
        "click",
        closeRentalModal
    );

    document.getElementById(
        "rentalModal"
    )?.addEventListener(
        "click",
        event => {
            if (
                event.target.id ===
                "rentalModal"
            ) {
                closeRentalModal();
            }
        }
    );

    document.querySelectorAll(
        "[data-rental-period]"
    ).forEach(button => {
        button.addEventListener(
            "click",
            () => {
                selectedRentalPeriod =
                    button.dataset.rentalPeriod ||
                    "1d";
                updateRentalPurchaseUi();
            }
        );
    });

    document.getElementById(
        "rentalConfirmButton"
    )?.addEventListener(
        "click",
        confirmDomainCardRental
    );

    document.addEventListener(
        "click",
        event => {
            if (!domainRentalMode) return;

            const card =
                event.target.closest(
                    ".newest-card"
                );

            if (!card) return;

            event.preventDefault();
            event.stopPropagation();
            event.stopImmediatePropagation();

            if (
                card.classList.contains(
                    "rented-card"
                )
            ) {
                alert(
                    "That card is already rented. Choose another available card."
                );
                return;
            }

            openRentalModal(card);
        },
        true
    );
}

bindDomainRentalUi();

document.getElementById(
    "profileRentDomainCardButton"
)?.addEventListener(
    "click",
    () => {
        document.getElementById(
            "profileMenu"
        )?.classList.add("hidden");
        enterDomainRentalMode();
    }
);

setInterval(
    updateRentalCountdowns,
    30000
);


/*
 * Mobile browsers can restore this page from BFCache after
 * the user signs in through Bonus Fetcher. In that case the
 * old JavaScript loggedIn value can survive even though the
 * server session is now authenticated.
 */
window.addEventListener("pageshow", async event => {
    if (!event.persisted) {
        return;
    }

    try {
        await loadAccount({
            renderAfter:false
        });

        await loadPromoterSummary();

        updateProgress();
        updateWalletButton();
        updateNotVisitedButton();
        updateDomainRentalLauncher();

        render();
    } catch (error) {
        console.warn(
            "Account refresh after page restore failed:",
            error
        );
    }
});



async function loadPromoterSummary() {
    if (!loggedIn) {
        promoterSummary = null;
        promoterReferralLink = "";
        updatePromoterProfile();
        return;
    }

    try {
        promoterSummary =
            await promoterPost({
                action:"me"
            });

        updatePromoterProfile();

        console.log(
            "Promoter account:",
            promoterSummary
        );
    } catch (error) {
        console.error(
            "Could not load promoter account:",
            error
        );

        promoterSummary = null;
        updatePromoterProfile();
    }
}


async function copyPromoterReferralLink() {
    if (!promoterReferralLink) {
        return;
    }

    const button =
        document.getElementById(
            "copyPromoterLinkButton"
        );

    try {
        await navigator.clipboard.writeText(
            promoterReferralLink
        );

        if (button) {
            const oldText =
                button.textContent;

            button.textContent =
                "✓ Referral Link Copied";

            setTimeout(() => {
                button.textContent =
                    oldText;
            }, 1600);
        }
    } catch (error) {
        console.error(
            "Clipboard failed:",
            error
        );

        window.prompt(
            "Copy your referral link:",
            promoterReferralLink
        );
    }
}


document
    .getElementById(
        "copyPromoterLinkButton"
    )
    ?.addEventListener(
        "click",
        copyPromoterReferralLink
    );


async function referralApiPost(payload) {
    const response = await fetch(
        "api/referral.php",
        {
            method:"POST",
            headers:{
                "Content-Type":"application/json"
            },
            body:JSON.stringify(payload),
            cache:"no-store"
        }
    );

    const result =
        await response.json();

    if (!response.ok) {
        throw new Error(
            result.error ||
            `Referral API HTTP ${response.status}`
        );
    }

    return result;
}


async function initPromoterReferral() {
    try {
        const params =
            new URLSearchParams(
                location.search
            );

        const code =
            String(
                params.get("ref") ||
                ""
            )
            .trim()
            .toUpperCase();

        /*
         * A new ?ref=CODE starts the pending visit.
         * If there is no ?ref parameter, the server may
         * still have a previous pending referral cookie,
         * so verify below can still finish it.
         */
        if (code) {
            const start =
                await referralApiPost({
                    action:"start",
                    referralCode:code
                });

            console.log(
                "Referral start:",
                start
            );

            if (!start.validReferral) {
                return;
            }
        }

        /*
         * Wait longer than the VPS 15-second minimum.
         * Changing this timer in DevTools cannot bypass
         * the VPS-side minimum-age check.
         */
        setTimeout(
            async () => {
                try {
                    const result =
                        await referralApiPost({
                            action:"verify"
                        });

                    console.log(
                        "Referral verify:",
                        result
                    );

                    /*
                     * If the visitor is also logged in
                     * and happens to be looking at their
                     * own promoter profile, refresh it.
                     */
                    if (
                        result.credited &&
                        loggedIn
                    ) {
                        await loadPromoterSummary();
                    }
                } catch (error) {
                    console.warn(
                        "Referral verification failed:",
                        error
                    );
                }
            },
            17000
        );

    } catch (error) {
        console.warn(
            "Referral start failed:",
            error
        );
    }
}


trackPageVisit();
initPromoterReferral();


async function loadHomepageDomains() {
    let data;
    const controller = new AbortController();
    const deadline = setTimeout(() => controller.abort(), 4000);
    try {
        const response = await fetch(
            "https://intel.bestpokieslist.online/public/homepage-catalogue.json",
            {cache:"no-cache", credentials:"omit", signal:controller.signal}
        );
        if (!response.ok) throw new Error(`Catalogue cache HTTP ${response.status}`);
        const cached = await response.json();
        const age = Date.now() / 1000 - Number(cached.generatedAt);
        if (!Number.isFinite(age) || age > 900 || age < -60 || !Array.isArray(cached.domains) || !cached.domains.length) {
            throw new Error("Catalogue cache is stale or invalid");
        }
        data = cached.domains;
    } catch (error) {
        console.warn("Catalogue cache unavailable; using live catalogue", error);
        const response = await fetch("api/homepage-domains.php?build=v8&t=" + Date.now(), {cache:"no-store"});
        if (!response.ok) throw new Error("Could not load homepage domains");
        data = await response.json();
    } finally {
        clearTimeout(deadline);
    }

    allDomains =
        Array.isArray(data)
            ? data
            : [];

    console.info(
        "Loaded domains:",
        allDomains.length,
        "Unverified:",
        allDomains.filter(item =>
            isUnverifiedGroup(item.group)
        ).length
    );

    return allDomains;
}


/* ---------- Add a missing casino (passed domains go straight onto NEW) ---------- */
async function postCommunity(payload) {
    const key = "community:" + JSON.stringify(payload);
    if (!window.bplCommunityInflight) window.bplCommunityInflight = new Map();
    const existing = window.bplCommunityInflight.get(key);
    if (existing) return existing;
    const job = postCommunityNow(payload).finally(() => window.bplCommunityInflight.delete(key));
    window.bplCommunityInflight.set(key, job);
    return job;
}

async function postCommunityNow(payload) {
    const response = await fetch("api/community.php", {
        method: "POST",
        credentials: "same-origin",
        cache: "no-store",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(payload)
    });
    let data;
    try { data = await response.json(); } catch { data = {ok: false, error: "Unexpected server response."}; }
    if (!response.ok || data?.ok === false) {
        const error = new Error(data?.error || `Request failed (${response.status})`);
        error.status = response.status;
        throw error;
    }
    return data;
}

function openReportScam() {
    if (window.bplReportsTab) window.bplReportsTab.show("scam");
    if (typeof window.bplOpenCommunity === "function") window.bplOpenCommunity("reports");
    else location.href = "/?community=reports";
}

async function loadCommunityNewDomains() {
    try {
        const data = await postCommunity({action: "newDomains"});
        const promoted = Array.isArray(data.promoted) ? data.promoted : [];
        const sig = promoted.map(item => `${homepageDomainKey(item)}@${item.addedAt || ""}`).join("|");
        const changed = sig !== communityPromotedSig;
        communityPromoted = promoted;
        communityPromotedSig = sig;
        if (changed && viewMode === "default" && !sortFilterIsActive()) render();
        return data;
    } catch (error) {
        return null;
    }
}

const communityAddModal = document.getElementById("communityAddModal");
const communityAddForm = document.getElementById("cadForm");
const communityAddInput = document.getElementById("cadDomain");
const communityAddStatus = document.getElementById("cadStatus");
const communityAddMine = document.getElementById("cadMine");
const communityAddTitle = document.getElementById("cadTitle");
const communityAddHelp = communityAddModal?.querySelector(".cad-help");
const communityAddDefaults = {
    title: communityAddTitle?.textContent || "",
    help: communityAddHelp?.textContent || "",
    button: "Check & add",
};
let communityAddPoll = null;
let communityAddReplaces = "";

function setCommunityAddMode(replaces) {
    communityAddReplaces = replaces || "";
    const button = communityAddForm?.querySelector("button");
    if (communityAddReplaces) {
        if (communityAddTitle) communityAddTitle.textContent = "Update a dead listing";
        if (communityAddHelp) communityAddHelp.textContent = `${communityAddReplaces} is marked dead. Enter the ending that works. We check it is the same casino, then update the card. You earn 15 XP once for that listing. Up to 3 checks a day.`;
        if (button) button.textContent = "Check & update";
    } else {
        if (communityAddTitle) communityAddTitle.textContent = communityAddDefaults.title;
        if (communityAddHelp) communityAddHelp.textContent = communityAddDefaults.help;
        if (button) button.textContent = communityAddDefaults.button;
    }
}

function setCommunityAddStatus(kind, html) {
    communityAddStatus.className = `cad-status cad-${kind}`;
    communityAddStatus.innerHTML = html;
    communityAddStatus.hidden = !html;
}

function renderCommunityAddMine(mine) {
    const label = {checking: "⏳ Checking", passed: "✅ Added", rejected: "❌ Not added", failed: "⚠️ Failed"};
    communityAddMine.innerHTML = (mine || []).map(item => `
        <li><b>${escapeJumpLabel(item.domain)}</b><span class="cad-pill cad-${escapeJumpLabel(item.status)}">${label[item.status] || escapeJumpLabel(item.status)}</span>${item.reason && item.status !== "passed" ? `<small>${escapeJumpLabel(item.reason)}</small>` : ""}</li>`).join("");
    communityAddMine.hidden = !(mine || []).length;
}

function pollCommunityAdd(id, domain) {
    clearTimeout(communityAddPoll);
    setCommunityAddStatus("checking", `<span class="cad-spin" aria-hidden="true"></span> Running Domain Maintenance on <b>${escapeJumpLabel(domain)}</b>: reachability, redirects, merchant ID and duplicate checks. This can take a minute or two.`);
    const tick = async () => {
        try {
            const data = await postCommunity({action: "domainStatus", id});
            if (data.status === "checking") { communityAddPoll = setTimeout(tick, 4000); return; }
            if (data.status === "passed") {
                const earnedXp = Number(data.xp || 0);
                const xpNote = earnedXp > 0 ? ` You earned ${earnedXp} XP.` : "";
                const replaced = String(data.replaced || "");
                setCommunityAddStatus("passed", replaced
                    ? `✅ The dead card was updated to <b>${escapeJumpLabel(data.domain)}</b>.${xpNote}`
                    : data.listed
                    ? `✅ <b>${escapeJumpLabel(data.domain)}</b> passed and is now on the homepage and in the Bonus Fetcher.${xpNote}`
                    : `✅ <b>${escapeJumpLabel(data.domain)}</b> passed Domain Maintenance. ${escapeJumpLabel(data.reason || "The homepage list was not updated.")}`);
                await loadCommunityNewDomains();
                if (replaced && typeof render === "function") render();
            } else {
                setCommunityAddStatus("rejected", `❌ <b>${escapeJumpLabel(data.domain)}</b> wasn't added. ${escapeJumpLabel(data.reason || "")}`);
            }
            const mine = await postCommunity({action: "newDomains"});
            renderCommunityAddMine(mine.mine);
            communityAddForm.querySelector("button").disabled = false;
        } catch (error) {
            communityAddPoll = setTimeout(tick, 8000);
        }
    };
    communityAddPoll = setTimeout(tick, 3000);
}

function openCommunityAddCorrection(domain) {
    setCommunityAddMode(domain);
    return openCommunityAdd(domain);
}

async function openCommunityAdd(replaces) {
    if (!communityAddModal) return;
    if (replaces === undefined) setCommunityAddMode("");
    communityAddModal.classList.remove("hidden");
    document.documentElement.classList.add("mp-open");
    setTimeout(() => communityAddInput?.focus(), 60);
    const data = await loadCommunityNewDomains();
    renderCommunityAddMine(data?.mine || []);
    const running = (data?.mine || []).find(item => item.status === "checking");
    if (running) {
        communityAddForm.querySelector("button").disabled = true;
        pollCommunityAdd(running.id, running.domain);
    }
}

function closeCommunityAdd() {
    communityAddModal?.classList.add("hidden");
    document.documentElement.classList.remove("mp-open");
    clearTimeout(communityAddPoll);
    setCommunityAddMode("");
}

document.addEventListener("click", event => {
    if (event.target.closest?.("[data-community-add]")) {
        event.preventDefault();
        openCommunityAdd();
    } else if (event.target.closest?.("[data-cad-close]") || event.target === communityAddModal) {
        closeCommunityAdd();
    }
});
document.addEventListener("keydown", event => {
    if (event.key === "Escape" && communityAddModal && !communityAddModal.classList.contains("hidden")) closeCommunityAdd();
});

communityAddForm?.addEventListener("submit", async event => {
    event.preventDefault();
    const button = communityAddForm.querySelector("button");
    const domain = communityAddInput.value.trim();
    if (!domain) return;
    button.disabled = true;
    setCommunityAddStatus("checking", "Starting…");
    try {
        const payload = {action: communityAddReplaces ? "correctDomain" : "submitDomain", domain};
        if (communityAddReplaces) payload.replaces = communityAddReplaces;
        const data = await postCommunity(payload);
        communityAddInput.value = "";
        pollCommunityAdd(data.id, data.domain);
    } catch (error) {
        button.disabled = false;
        if (error.status === 401) {
            setCommunityAddStatus("rejected", 'Please log in first. <a href="bonus-fetch.php">Sign in with the Bonus Fetcher</a> (free, no fetch used).');
        } else {
            setCommunityAddStatus("rejected", `❌ ${escapeJumpLabel(error.message)}`);
        }
    }
});

loadCommunityNewDomains();
setInterval(() => { if (!document.hidden) loadCommunityNewDomains(); }, 120000);

/* ---------- Profile picture (menu > Profile) ---------- */
const profileAvatarPreview = document.getElementById("profileAvatarPreview");
const profileAvatarInput = document.getElementById("profileAvatarInput");
const profileAvatarRemove = document.getElementById("profileAvatarRemove");
const profileViewPublic = document.getElementById("profileViewPublic");
const profileAvatarMsg = document.getElementById("profileAvatarMsg");
let profileMe = null;

function paintProfileAvatar() {
    if (!profileAvatarPreview || !profileMe) return;
    profileAvatarPreview.replaceChildren();
    if (profileMe.avatar) {
        const img = document.createElement("img");
        img.src = profileMe.avatar;
        img.alt = "";
        profileAvatarPreview.append(img);
    } else {
        profileAvatarPreview.textContent = profileMe.initial || "?";
        profileAvatarPreview.style.setProperty("--h", Number(profileMe.hue) || 0);
    }
    profileAvatarRemove.hidden = !profileMe.avatar;
    profileViewPublic.hidden = !profileMe.hasProfile;
}

async function loadProfileAvatar() {
    try {
        profileMe = await postCommunity({action: "me"});
        document.getElementById("profileAvatarBox").hidden = !profileMe.loggedIn;
        paintProfileAvatar();
    } catch (error) { /* keep previous */ }
}

async function shrinkAvatarFile(file) {
    if (file.size <= 1500000 || typeof createImageBitmap !== "function") return file;
    try {
        const bitmap = await createImageBitmap(file);
        const scale = Math.min(1, 1024 / Math.min(bitmap.width, bitmap.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(bitmap.width * scale);
        canvas.height = Math.round(bitmap.height * scale);
        canvas.getContext("2d").drawImage(bitmap, 0, 0, canvas.width, canvas.height);
        const blob = await new Promise(resolve => canvas.toBlob(resolve, "image/jpeg", 0.9));
        return blob || file;
    } catch (error) {
        return file;
    }
}

async function sendProfileAvatar(form) {
    profileAvatarMsg.textContent = "Saving…";
    profileAvatarMsg.className = "pav-msg";
    try {
        const response = await fetch("api/profile-avatar.php", {method: "POST", credentials: "same-origin", headers: {"X-BPL-Upload": "1"}, body: form});
        const data = await response.json().catch(() => ({ok: false, error: "Unexpected server response."}));
        if (!response.ok || !data.ok) throw new Error(data.error || "Upload failed.");
        profileMe = {...profileMe, avatar: data.avatar};
        paintProfileAvatar();
        profileAvatarMsg.textContent = data.avatar ? "✅ Profile picture updated." : "Profile picture removed.";
        profileAvatarMsg.className = "pav-msg pav-ok";
        window.BPLCommunity?.refresh?.();
    } catch (error) {
        profileAvatarMsg.textContent = `⚠️ ${error.message}`;
        profileAvatarMsg.className = "pav-msg pav-err";
    }
}

profileAvatarInput?.addEventListener("change", async () => {
    const file = profileAvatarInput.files?.[0];
    profileAvatarInput.value = "";
    if (!file) return;
    const form = new FormData();
    form.append("action", "upload");
    form.append("avatar", await shrinkAvatarFile(file), "avatar.jpg");
    sendProfileAvatar(form);
});
profileAvatarRemove?.addEventListener("click", () => {
    const form = new FormData();
    form.append("action", "remove");
    sendProfileAvatar(form);
});
profileViewPublic?.addEventListener("click", () => {
    if (profileMe?.id) window.BPLCommunity?.openProfile?.(profileMe.id);
});
document.getElementById("profileButton")?.addEventListener("click", loadProfileAvatar);

/* ---------- Homepage extras: collapsible sections, jump bar, search highlight, summary ---------- */
const COLLAPSE_KEY = "bplCollapsedSections";
const JUMP_LABELS = [
    ["rent-block", "🎰 Rent"], ["best-section", "★ Best"], ["lizzy-section", "💜 Lizzy"],
    ["bonus-section", "🎁 Instant"], ["extra-rental-section", "🎰 More rentals"],
    ["favourites-section", "❤️ Favourites"], ["latest-section", "🆕 Latest"]
];
let collapsedSections = new Set();
try { collapsedSections = new Set(JSON.parse(localStorage.getItem(COLLAPSE_KEY) || "[]")); } catch (e) {}

function homepageSections() {
    return [...groupsElement.children].filter(el => el.querySelector(".section-title"));
}

function sectionKey(section) {
    const title = section.querySelector(".section-title");
    return (title?.textContent || "").replace(/\(\d+\)/g, "").replace(/[^\p{L}\p{N} ]/gu, "").trim().toLowerCase();
}

function isMainTopBlock(section) {
    return section.classList.contains("top-block")
        && !section.classList.contains("rent-block")
        && !section.classList.contains("community-new-block");
}

function saveCollapsed() {
    try { localStorage.setItem(COLLAPSE_KEY, JSON.stringify([...collapsedSections])); } catch (e) {}
}

function setSectionCollapsed(section, collapsed) {
    const title = section.querySelector(".section-title");
    section.classList.toggle("is-collapsed", collapsed);
    title?.setAttribute("aria-expanded", String(!collapsed));
}

function enhanceCollapsibleSections(searching) {
    for (const section of homepageSections()) {
        if (isMainTopBlock(section) || section.classList.contains("community-new-block")) continue;
        const title = section.querySelector(".section-title");
        const key = sectionKey(section);
        if (!title || !key) continue;
        if (!title.dataset.collapsible) {
            title.dataset.collapsible = "1";
            title.setAttribute("role", "button");
            title.tabIndex = 0;
            title.insertAdjacentHTML("beforeend", '<span class="section-chevron" aria-hidden="true">▾</span>');
            const toggle = () => {
                const collapsed = !section.classList.contains("is-collapsed");
                setSectionCollapsed(section, collapsed);
                if (collapsed) collapsedSections.add(key); else collapsedSections.delete(key);
                saveCollapsed();
            };
            title.addEventListener("click", toggle);
            title.addEventListener("keydown", event => {
                if (event.key === "Enter" || event.key === " ") { event.preventDefault(); toggle(); }
            });
        }
        setSectionCollapsed(section, !searching && collapsedSections.has(key));
    }
}

function jumpLabel(section) {
    if (isMainTopBlock(section)) return "🌿 New";
    if (section.classList.contains("community-new-block")) return "🆕 Community";
    for (const [cls, label] of JUMP_LABELS) if (section.classList.contains(cls)) return label;
    const text = (section.querySelector(".section-title")?.textContent || "").replace(/\(\d+\)/g, "").replace(/▾/g, "").trim();
    return text.length > 18 ? text.slice(0, 17) + "…" : text;
}

function updateJumpOffset() {
    const toolbar = document.querySelector(".toolbar");
    const offset = (toolbar ? toolbar.getBoundingClientRect().height : 0) + 14;
    document.documentElement.style.setProperty("--jump-offset", `${Math.round(offset)}px`);
}

function buildJumpBar(searching) {
    const bar = document.getElementById("sectionJump");
    if (!bar) return;
    const sections = homepageSections();
    bar.hidden = searching || sections.length < 3;
    if (bar.hidden) { bar.innerHTML = ""; return; }
    sections.forEach((section, index) => { section.dataset.jumpIndex = String(index); });
    bar.innerHTML = sections.map((section, index) =>
        `<button type="button" class="jump-chip" data-jump="${index}">${escapeJumpLabel(jumpLabel(section))}</button>`
    ).join("");
    updateJumpOffset();
    updateActiveJump();
}

function escapeJumpLabel(text) {
    return String(text).replace(/[&<>"']/g, c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]));
}

function updateActiveJump() {
    const bar = document.getElementById("sectionJump");
    if (!bar || bar.hidden) return;
    const limit = (parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--jump-offset")) || 0) + 20;
    let active = 0;
    for (const section of homepageSections()) {
        if (section.getBoundingClientRect().top <= limit) active = Number(section.dataset.jumpIndex || 0);
    }
    bar.querySelectorAll(".jump-chip").forEach(chip => {
        const on = Number(chip.dataset.jump) === active;
        if (on && !chip.classList.contains("is-active")) {
            chip.classList.add("is-active");
            chip.scrollIntoView({block: "nearest", inline: "nearest"});
        } else if (!on) chip.classList.remove("is-active");
    });
}

document.getElementById("sectionJump")?.addEventListener("click", event => {
    const chip = event.target.closest(".jump-chip");
    if (!chip) return;
    const section = groupsElement.querySelector(`[data-jump-index="${chip.dataset.jump}"]`);
    if (!section) return;
    if (section.classList.contains("is-collapsed")) section.querySelector(".section-title")?.click();
    updateJumpOffset();
    section.scrollIntoView({behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start"});
});

function highlightSearchMatches(query) {
    const wanted = normalizeDomainSearch(query);
    if (!wanted) return;
    // Highlight only the hostname (.domain-name), never the list index (.card-index).
    // Using the whole .domain textContent previously glued "24" + "oz9.net" into "24oz9.net".
    for (const el of groupsElement.querySelectorAll("a.card .domain .domain-name, a.card .domain")) {
        if (el.classList.contains("domain") && el.querySelector(".domain-name")) continue;
        if (el.querySelector("mark")) continue;
        const text = el.textContent;
        const positions = [];
        let normalized = "";
        for (let i = 0; i < text.length; i++) {
            const ch = text[i].toLowerCase();
            if (/[a-z0-9]/.test(ch)) { normalized += ch; positions.push(i); }
        }
        const at = normalized.indexOf(wanted);
        if (at < 0) continue;
        const start = positions[at];
        const end = positions[at + wanted.length - 1] + 1;
        el.replaceChildren(text.slice(0, start), Object.assign(document.createElement("mark"), {textContent: text.slice(start, end)}), text.slice(end));
    }
}

function updateEmptyState(query) {
    const title = emptyElement.querySelector("[data-empty-title]");
    const hint = emptyElement.querySelector("[data-empty-hint]");
    const clear = emptyElement.querySelector("[data-empty-clear]");
    if (!title) return;
    const searching = Boolean(query.trim());
    title.textContent = searching ? `No casinos match “${query.trim()}”` : "No matching domains found.";
    hint.hidden = !searching;
    clear.hidden = !searching;
}

emptyElement.querySelector("[data-empty-clear]")?.addEventListener("click", () => {
    document.getElementById("domainSearchClear")?.click();
});

function updateHeroSummary() {
    const box = document.getElementById("heroSummary");
    if (!box || !allDomains.length) return;
    const weekAgo = Date.now() - 7 * 86400000;
    const all = new Set();
    const recent = new Set();
    let newest = 0;
    for (const item of allDomains) {
        if (item.placeholder || item.rentalPlaceholder) continue;
        const key = normalizeDomain(item.domain);
        if (!key) continue;
        all.add(key);
        const added = new Date(String(item.addedAt || "")).getTime();
        if (added && added >= weekAgo) recent.add(key);
        if (added > newest) newest = added;
    }
    const parts = [`${all.size.toLocaleString("en-AU")} sites`];
    if (recent.size) parts.push(`${recent.size} added this week`);
    else if (newest) parts.push(`newest ${relativeAddedAt(new Date(newest).toISOString())}`);
    box.textContent = parts.join(" · ");
}

let homepageExtrasFrame = 0;
function scheduleHomepageExtras() {
    cancelAnimationFrame(homepageExtrasFrame);
    homepageExtrasFrame = requestAnimationFrame(() => {
        const query = domainSearchQuery || "";
        const searching = Boolean(query.trim());
        enhanceCollapsibleSections(searching);
        buildJumpBar(searching);
        if (searching) highlightSearchMatches(query);
        updateEmptyState(query);
        updateHeroSummary();
    });
}

new MutationObserver(scheduleHomepageExtras).observe(groupsElement, {childList: true});
window.addEventListener("scroll", () => requestAnimationFrame(updateActiveJump), {passive: true});
window.addEventListener("resize", updateJumpOffset);

function revealHomepage() {
    document.body.classList.remove(
        "app-loading"
    );

    const loader =
        document.getElementById(
            "appLoadingScreen"
        );

    if (loader) {
        loader.remove();
    }
}


async function waitForHomepagePaint() {
    /*
     * Two animation frames means render() has built the DOM
     * and the browser has completed layout before we reveal it.
     *
     * This is what prevents the cards / controls / statuses from
     * visibly popping into place one after another.
     */
    await new Promise(resolve => {
        requestAnimationFrame(() => {
            requestAnimationFrame(resolve);
        });
    });
}


async function bootstrapHomepage() {
    /*
     * Start every independent request immediately.
     *
     * Account loading also retrieves the server-side visited list.
     * Promoter data depends on knowing which account is logged in,
     * so that begins the instant account loading finishes.
     */

    const domainsPromise =
        loadHomepageDomains();

    const statusesPromise =
        loadDomainStatuses();

    const rentalsPromise =
        loadActiveRentals();

    const accountPromise =
        loadAccount({
            renderAfter:false
        });

    const promoterPromise =
        accountPromise.then(() =>
            loadPromoterSummary()
        );


    const results =
        await Promise.allSettled([
            domainsPromise,
            statusesPromise,
            rentalsPromise,
            accountPromise,
            promoterPromise
        ]);


    const [
        domainsResult,
        statusesResult,
        rentalsResult,
        accountResult,
        promoterResult
    ] = results;


    /*
     * The domain list itself is essential.
     * The other services are enhancements and should not make
     * the entire homepage unusable if one temporarily fails.
     */
    if (
        domainsResult.status ===
        "rejected"
    ) {
        throw domainsResult.reason;
    }


    if (
        statusesResult.status ===
        "rejected"
    ) {
        console.warn(
            "Initial domain status load failed:",
            statusesResult.reason
        );
    }


    if (
        rentalsResult.status ===
        "rejected"
    ) {
        console.warn(
            "Initial rental load failed:",
            rentalsResult.reason
        );
    }


    if (
        accountResult.status ===
        "rejected"
    ) {
        console.warn(
            "Initial account load failed:",
            accountResult.reason
        );
    }


    if (
        promoterResult.status ===
        "rejected"
    ) {
        console.warn(
            "Initial promoter load failed:",
            promoterResult.reason
        );
    }


    /*
     * Everything now has its startup state.
     * Build the page ONE time while it is still invisible.
     */
    render();

    updateNotVisitedButton();
    updateWalletButton();
    updateSortFilterButton();
    updatePromoterRentLauncher();
    updatePromoterProfile();
    updateProgress();


    /*
     * Allow the finished DOM to go through layout before revealing.
     * The user therefore sees one completed homepage instead of
     * separate sections appearing at different times.
     */
    await waitForHomepagePaint();

    revealHomepage();
    restoreScrollState();
}



/* ===== Public pending-domain submissions ===== */
const domainSubmitButton = document.getElementById("domainSubmitButton");
const domainSubmitModal = document.getElementById("domainSubmitModal");
const domainSubmitClose = document.getElementById("domainSubmitClose");
const domainSubmitForm = document.getElementById("domainSubmitForm");
const domainSubmitInput = document.getElementById("domainSubmitInput");
const domainSubmitSend = document.getElementById("domainSubmitSend");
const domainSubmitMessage = document.getElementById("domainSubmitMessage");
const pendingDomainList = document.getElementById("pendingDomainList");
const pendingDomainPill = document.getElementById("pendingDomainPill");
const domainSubmitCount = document.getElementById("domainSubmitCount");

function escapePendingHtml(value){
    return String(value ?? "").replace(/[&<>"']/g, ch => ({
        "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
    })[ch]);
}

function pendingRelativeTime(iso){
    const time = new Date(iso).getTime();
    if (!Number.isFinite(time)) return "Recently";
    const seconds = Math.max(0, Math.floor((Date.now() - time) / 1000));
    if (seconds < 60) return "Just now";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes} minute${minutes === 1 ? "" : "s"} ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} hour${hours === 1 ? "" : "s"} ago`;
    const days = Math.floor(hours / 24);
    if (days < 30) return `${days} day${days === 1 ? "" : "s"} ago`;
    return new Intl.DateTimeFormat("en-AU", {
        day:"numeric", month:"short", year:"numeric"
    }).format(new Date(iso));
}

function pendingMelbourneTime(iso){
    try{
        return new Intl.DateTimeFormat("en-AU", {
            timeZone:"Australia/Melbourne",
            day:"numeric", month:"short", year:"numeric",
            hour:"numeric", minute:"2-digit"
        }).format(new Date(iso));
    }catch(_){
        return "";
    }
}

function showDomainSubmitMessage(text, type){
    domainSubmitMessage.textContent = text;
    domainSubmitMessage.className = `domain-submit-message show ${type}`;
}

function renderPendingDomains(items){
    const pending = Array.isArray(items) ? items : [];
    pendingDomainPill.textContent = `${pending.length} pending`;
    domainSubmitCount.textContent = pending.length ? `· ${pending.length} Pending` : "";

    if (!pending.length){
        pendingDomainList.innerHTML =
            '<div class="pending-empty">No domains are waiting for review yet. Be the first to submit one.</div>';
        return;
    }

    pendingDomainList.innerHTML = pending.map(item => {
        const domain = escapePendingHtml(item.domain);
        const relative = escapePendingHtml(pendingRelativeTime(item.submittedAt));
        const exact = escapePendingHtml(pendingMelbourneTime(item.submittedAt));
        return `
            <div class="pending-domain-card">
                <div class="pending-domain-name">🎰 ${domain}</div>
                <div class="pending-domain-meta">
                    <span>${relative}</span>
                    ${exact ? `<span>• ${exact} Melbourne</span>` : ""}
                    <span class="pending-status">● Waiting for review</span>
                </div>
            </div>`;
    }).join("");
}

async function loadPendingDomains(){
    try{
        const response = await fetch("?domain_submissions=1&t=" + Date.now(), {
            cache:"no-store",
            credentials:"same-origin"
        });
        const data = await response.json();
        if (!response.ok || !data.ok) throw new Error(data.error || "Could not load pending domains.");
        renderPendingDomains(data.pending);
    }catch(error){
        pendingDomainPill.textContent = "Unavailable";
        pendingDomainList.innerHTML =
            `<div class="pending-empty">${escapePendingHtml(error.message || "Could not load pending domains.")}</div>`;
    }
}

function openDomainSubmitModal(){
    domainSubmitModal.classList.remove("hidden");
    document.body.style.overflow = "hidden";
    loadPendingDomains();
    setTimeout(() => domainSubmitInput.focus(), 80);
}

function closeDomainSubmitModal(){
    domainSubmitModal.classList.add("hidden");
    document.body.style.overflow = "";
}

domainSubmitButton?.addEventListener("click", () => openCommunityAdd());
document.getElementById("reportScamMenuButton")?.addEventListener("click", () => openReportScam());
domainSubmitClose?.addEventListener("click", closeDomainSubmitModal);
domainSubmitModal?.addEventListener("click", event => {
    if (event.target === domainSubmitModal) closeDomainSubmitModal();
});

domainSubmitForm?.addEventListener("submit", async event => {
    event.preventDefault();
    const domain = domainSubmitInput.value.trim();
    if (!domain) return;

    domainSubmitSend.disabled = true;
    domainSubmitSend.textContent = "Sending…";
    domainSubmitMessage.className = "domain-submit-message";

    try{
        const response = await fetch("?domain_submissions=1", {
            method:"POST",
            credentials:"same-origin",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify({domain})
        });
        const data = await response.json();
        if (!data.ok) throw new Error(data.error || "Could not submit that domain.");

        domainSubmitInput.value = "";
        showDomainSubmitMessage(data.message || "Submitted for review!", "ok");
        await loadPendingDomains();
    }catch(error){
        showDomainSubmitMessage(error.message || "Could not submit that domain.", "error");
    }finally{
        domainSubmitSend.disabled = false;
        domainSubmitSend.textContent = "Submit";
    }
});

/* The public review queue is closed. Add a casino runs Domain Maintenance. */



/* ==========================================================
   MAIN PAGE WEB PUSH
   ========================================================== */

const MAIN_PUSH_API =
    "/api/push-subscribe.php";

const MAIN_PUSH_TEST_API =
    "/api/push-test.php";


function mainPushIsIOS(){

    const ua =
        navigator.userAgent || "";

    return (
        /iPhone|iPad|iPod/i.test(ua)
        || (
            navigator.platform === "MacIntel"
            && navigator.maxTouchPoints > 1
        )
    );
}


function mainPushIsStandalone(){

    return (
        window.matchMedia(
            "(display-mode: standalone)"
        ).matches
        || navigator.standalone === true
    );
}


function mainPushBase64ToBytes(
    value
){
    const padding =
        "=".repeat(
            (4 - value.length % 4) % 4
        );

    const base64 =
        (value + padding)
            .replace(/-/g, "+")
            .replace(/_/g, "/");

    const raw =
        atob(base64);

    return Uint8Array.from(
        [...raw].map(
            ch => ch.charCodeAt(0)
        )
    );
}


async function mainPushApi(
    payload
){
    const response =
        await fetch(
            MAIN_PUSH_API,
            {
                method:"POST",

                credentials:
                    "same-origin",

                cache:
                    "no-store",

                headers:{
                    "Content-Type":
                        "application/json"
                },

                body:
                    JSON.stringify(payload)
            }
        );

    let result;

    try{
        result =
            await response.json();
    }catch(_){
        throw new Error(
            "Push API returned HTTP "
            + response.status
        );
    }

    if (
        !response.ok
        || !result.ok
    ){
        throw new Error(
            result.error
            || "Push request failed"
        );
    }

    return result;
}


function mainPushHelp(
    message
){
    const box =
        document.getElementById(
            "mainPushHelp"
        );

    if (!box) return;

    if (!message){
        box.textContent = "";
        box.classList.add("hidden");
        return;
    }

    box.textContent =
        message;

    box.classList.remove(
        "hidden"
    );
}


function mainPushSetMenuStatus(
    value
){
    const node =
        document.getElementById(
            "mainNotificationMenuStatus"
        );

    if (node){
        node.textContent =
            value;
    }
}


function mainNotifySetTypeButton(
    id,
    enabled,
    label
){
    const button =
        document.getElementById(
            id
        );

    if (!button) return;

    button.dataset.enabled =
        enabled
        ? "1"
        : "0";

    button.textContent =
        label
        + (
            enabled
            ? " ✓"
            : " ✕"
        );

    button.style.opacity =
        enabled
        ? "1"
        : ".48";
}


function mainNotifyReadType(
    id
){
    return (
        document
            .getElementById(
                id
            )
            ?.dataset.enabled
        === "1"
    );
}


function mainNotifyToggleType(
    id,
    label
){
    const current =
        mainNotifyReadType(
            id
        );

    mainNotifySetTypeButton(
        id,
        !current,
        label
    );
}


function mainNotifyApplyPreferences(
    preferences
){
    const pref =
        preferences
        || {};

    mainNotifySetTypeButton(
        "mainNotifyCommission",
        pref.commission !== false,
        "COM"
    );

    mainNotifySetTypeButton(
        "mainNotifyShare",
        pref.share !== false,
        "SHARE"
    );

    mainNotifySetTypeButton(
        "mainNotifyReferral",
        pref.referral !== false,
        "REF"
    );

    const liveChat =
        document.getElementById(
            "mainNotifyLiveChat"
        );

    if (liveChat){
        liveChat.checked =
            Boolean(
                pref.liveChat
            );
    }

    const linkClick =
        document.getElementById(
            "mainNotifyLinkClick"
        );

    if (linkClick){
        linkClick.checked =
            Boolean(
                pref.linkClick
            );
    }

    const newCasino =
        document.getElementById(
            "mainNotifyNewCasino"
        );

    if (newCasino){
        newCasino.checked =
            Boolean(
                pref.newCasino
            );
    }

    const silent =
        document.getElementById(
            "mainNotifySilent"
        );

    if (silent){
        silent.checked =
            Boolean(
                pref.silent
            );
    }

    const grouping =
        document.getElementById(
            "mainNotifyGrouping"
        );

    if (grouping){
        grouping.value =
            pref.grouping
            || "stack";
    }

}


async function mainNotifySaveSettings(){

    const button =
        document.getElementById(
            "mainNotifySaveSettings"
        );

    const status =
        document.getElementById(
            "mainNotifySettingsStatus"
        );

    if (
        !button
        || !status
    ){
        return;
    }

    button.disabled = true;

    status.textContent =
        "Saving…";

    try{

        const result =
            await mainPushApi({
                action:
                    "setPreferences",

                commission:
                    mainNotifyReadType(
                        "mainNotifyCommission"
                    ),

                share:
                    mainNotifyReadType(
                        "mainNotifyShare"
                    ),

                referral:
                    mainNotifyReadType(
                        "mainNotifyReferral"
                    ),

                liveChat:
                    Boolean(
                        document
                            .getElementById(
                                "mainNotifyLiveChat"
                            )
                            ?.checked
                    ),

                linkClick:
                    Boolean(
                        document
                            .getElementById(
                                "mainNotifyLinkClick"
                            )
                            ?.checked
                    ),

                newCasino:
                    Boolean(
                        document
                            .getElementById(
                                "mainNotifyNewCasino"
                            )
                            ?.checked
                    ),

                deliveryStyle:
                    "individual",

                detailLevel:
                    "compact",

                imageMode:
                    "default",

                silent:
                    Boolean(
                        document
                            .getElementById(
                                "mainNotifySilent"
                            )
                            ?.checked
                    ),

                grouping:
                    document
                        .getElementById(
                            "mainNotifyGrouping"
                        )
                        ?.value
                    || "stack"
            });

        mainNotifyApplyPreferences(
            result.preferences
        );

        status.textContent =
            "Settings saved ✓";

    }catch(error){

        console.error(
            "NOTIFICATION SETTINGS SAVE FAILED:",
            error
        );

        status.textContent =
            error?.message
            || "Could not save settings.";

    }finally{

        button.disabled =
            false;
    }
}


async function mainBonusAlertsRefresh(){

    const toggle =
        document.getElementById(
            "mainBonusAlertsToggle"
        );

    const status =
        document.getElementById(
            "mainBonusAlertsStatus"
        );

    if (
        !toggle
        || !status
    ){
        return;
    }

    toggle.disabled = true;
    toggle.textContent = "OFF";
    toggle.dataset.enabled = "0";
    status.textContent =
        "Background bonus alerts are temporarily unavailable.";

    try{

        const result =
            await mainPushApi({
                action:"status"
            });

        mainNotifyApplyPreferences(
            result.preferences
        );

    }catch(error){

        console.error(
            "BONUS ALERT STATUS FAILED:",
            error
        );

        toggle.disabled = true;

        status.textContent =
            "Background bonus alerts are temporarily unavailable.";
    }
}


async function mainBonusAlertsToggle(){

    const toggle =
        document.getElementById(
            "mainBonusAlertsToggle"
        );

    const status =
        document.getElementById(
            "mainBonusAlertsStatus"
        );

    if (
        !toggle
        || !status
    ){
        return;
    }

    toggle.disabled = true;
    toggle.textContent = "OFF";
    toggle.dataset.enabled = "0";
    status.textContent =
        "Background bonus alerts are temporarily unavailable.";
}


async function mainPushRefresh(){

    const status =
        document.getElementById(
            "mainPushStatus"
        );

    const enable =
        document.getElementById(
            "mainPushEnable"
        );

    const test =
        document.getElementById(
            "mainPushTest"
        );

    if (
        !status
        || !enable
        || !test
    ){
        return;
    }

    mainPushHelp("");

    if (
        mainPushIsIOS()
        && !mainPushIsStandalone()
    ){
        status.textContent =
            "Home Screen app required";

        mainPushSetMenuStatus(
            "Open from Home Screen"
        );

        enable.textContent =
            "ADD TO HOME SCREEN FIRST";

        enable.disabled = true;
        test.disabled = true;

        mainPushHelp(
            "On iPhone or iPad, add Best Pokies List to your Home Screen and open it from the Home Screen icon."
        );

        return;
    }

    if (
        !("serviceWorker" in navigator)
        || !("PushManager" in window)
        || !("Notification" in window)
    ){
        status.textContent =
            "Not supported";

        mainPushSetMenuStatus(
            "Not supported"
        );

        enable.disabled = true;
        test.disabled = true;

        return;
    }

    if (
        Notification.permission
        === "denied"
    ){
        status.textContent =
            "Blocked";

        mainPushSetMenuStatus(
            "Blocked"
        );

        enable.textContent =
            "NOTIFICATIONS BLOCKED";

        enable.disabled = true;
        test.disabled = true;

        return;
    }

    try{

        const registration =
            await navigator
                .serviceWorker
                .ready;

        const subscription =
            await registration
                .pushManager
                .getSubscription();

        if (!subscription){

            status.textContent =
                "Not enabled";

            mainPushSetMenuStatus(
                "Not enabled"
            );

            enable.textContent =
                "ENABLE NOTIFICATIONS";

            enable.disabled = false;
            test.disabled = true;

            return;
        }

        const json =
            subscription.toJSON();

        await mainPushApi({
            action:"subscribe",

            subscription:{
                endpoint:
                    subscription.endpoint,

                keys:
                    json.keys || {}
            }
        });

        status.textContent =
            "Enabled on this device";

        mainPushSetMenuStatus(
            "Enabled on this device"
        );

        enable.textContent =
            "NOTIFICATIONS ENABLED";

        enable.disabled = true;
        test.disabled = false;

        await mainBonusAlertsRefresh();

    }catch(error){

        console.error(
            "MAIN PUSH STATUS FAILED:",
            error
        );

        status.textContent =
            "Unable to check";

        mainPushSetMenuStatus(
            "Unable to check"
        );

        enable.disabled = false;
        test.disabled = true;
    }
}


async function mainPushEnable(){

    const enable =
        document.getElementById(
            "mainPushEnable"
        );

    const test =
        document.getElementById(
            "mainPushTest"
        );

    const status =
        document.getElementById(
            "mainPushStatus"
        );

    if (
        !enable
        || !test
        || !status
    ){
        return;
    }

    enable.disabled = true;

    enable.textContent =
        "SETTING UP…";

    try{

        const permission =
            await Notification
                .requestPermission();

        if (
            permission !== "granted"
        ){
            throw new Error(
                "Notification permission was not granted."
            );
        }

        const keys =
            await mainPushApi({
                action:"publicKey"
            });

        const registration =
            await navigator
                .serviceWorker
                .ready;

        let subscription =
            await registration
                .pushManager
                .getSubscription();

        if (!subscription){

            subscription =
                await registration
                    .pushManager
                    .subscribe({
                        userVisibleOnly:true,

                        applicationServerKey:
                            mainPushBase64ToBytes(
                                keys.publicKey
                            )
                    });
        }

        const json =
            subscription.toJSON();

        await mainPushApi({
            action:"subscribe",

            subscription:{
                endpoint:
                    subscription.endpoint,

                keys:
                    json.keys || {}
            }
        });

        status.textContent =
            "Enabled on this device";

        mainPushSetMenuStatus(
            "Enabled on this device"
        );

        enable.textContent =
            "NOTIFICATIONS ENABLED";

        enable.disabled = true;
        test.disabled = false;

        await mainBonusAlertsRefresh();

    }catch(error){

        console.error(
            "MAIN PUSH ENABLE FAILED:",
            error
        );

        status.textContent =
            "Setup failed";

        enable.textContent =
            "ENABLE NOTIFICATIONS";

        enable.disabled = false;

        mainPushHelp(
            error?.message
            || String(error)
        );
    }
}


async function mainPushTest(){

    const button =
        document.getElementById(
            "mainPushTest"
        );

    if (!button) return;

    button.disabled = true;

    button.textContent =
        "SENDING…";

    try{

        const response =
            await fetch(
                MAIN_PUSH_TEST_API,
                {
                    method:"POST",
                    credentials:"same-origin",
                    cache:"no-store"
                }
            );

        const result =
            await response.json();

        if (
            !response.ok
            || !result.ok
        ){
            throw new Error(
                result.error
                || "Push test failed"
            );
        }

        if (
            Number(
                result.result?.success
                || 0
            ) < 1
        ){
            throw new Error(
                "Server did not deliver the push."
            );
        }

        button.textContent =
            "SENT ✓";

    }catch(error){

        console.error(
            "MAIN PUSH TEST FAILED:",
            error
        );

        button.textContent =
            "SEND FAILED";

        mainPushHelp(
            error?.message
            || String(error)
        );

    }finally{

        setTimeout(
            () => {
                button.textContent =
                    "TEST BONUS NOTIFICATION";

                button.disabled =
                    false;
            },
            1500
        );
    }
}


async function mainPushCreditTest(
    type,
    buttonId,
    originalLabel
){

    const button =
        document.getElementById(
            buttonId
        );

    if (!button) return;

    button.disabled = true;

    button.textContent =
        "SENDING…";

    try{

        const response =
            await fetch(
                MAIN_PUSH_TEST_API,
                {
                    method:
                        "POST",

                    credentials:
                        "same-origin",

                    cache:
                        "no-store",

                    headers:{
                        "Content-Type":
                            "application/json"
                    },

                    body:
                        JSON.stringify({
                            type
                        })
                }
            );

        const result =
            await response.json();

        if (
            !response.ok
            || !result.ok
        ){
            throw new Error(
                result.error
                || "Push test failed"
            );
        }

        if (
            Number(
                result.result?.success
                || 0
            ) < 1
        ){
            throw new Error(
                "Server did not deliver the push."
            );
        }

        button.textContent =
            "SENT ✓";

    }catch(error){

        console.error(
            "REFERRAL PUSH TEST FAILED:",
            error
        );

        button.textContent =
            "SEND FAILED";

        mainPushHelp(
            error?.message
            || String(error)
        );

    }finally{

        setTimeout(
            () => {

                button.textContent =
                    originalLabel;

                button.disabled =
                    false;
            },
            1500
        );
    }
}


document
    .getElementById(
        "mainWebsiteReferralTest"
    )
    ?.addEventListener(
        "click",
        () => mainPushCreditTest(
            "website_referral",
            "mainWebsiteReferralTest",
            "TEST WEBSITE REFERRAL"
        )
    );


document
    .getElementById(
        "mainDiscordJoinTest"
    )
    ?.addEventListener(
        "click",
        () => mainPushCreditTest(
            "discord_join",
            "mainDiscordJoinTest",
            "TEST DISCORD JOIN"
        )
    );


document
    .getElementById(
        "mainDiscordLinkTest"
    )
    ?.addEventListener(
        "click",
        () => mainPushCreditTest(
            "discord_link",
            "mainDiscordLinkTest",
            "TEST DISCORD LINK"
        )
    );


document
    .getElementById(
        "mainNotifyCommission"
    )
    ?.addEventListener(
        "click",
        () => mainNotifyToggleType(
            "mainNotifyCommission",
            "COM"
        )
    );


document
    .getElementById(
        "mainNotifyShare"
    )
    ?.addEventListener(
        "click",
        () => mainNotifyToggleType(
            "mainNotifyShare",
            "SHARE"
        )
    );


document
    .getElementById(
        "mainNotifyReferral"
    )
    ?.addEventListener(
        "click",
        () => mainNotifyToggleType(
            "mainNotifyReferral",
            "REF"
        )
    );


document
    .getElementById(
        "mainNotifySaveSettings"
    )
    ?.addEventListener(
        "click",
        mainNotifySaveSettings
    );


document
    .getElementById(
        "mainBonusAlertsToggle"
    )
    ?.addEventListener(
        "click",
        mainBonusAlertsToggle
    );


function mainPushOpenModal(){

    document.documentElement
        .classList.add(
            "bpl-notification-modal-open"
        );

    document.body
        .classList.add(
            "bpl-notification-modal-open"
        );

    document
        .querySelector(
            ".side-drawer-overlay"
        )
        ?.classList.add(
            "hidden"
        );

    document
        .querySelector(
            ".drawer-menu-button"
        )
        ?.setAttribute(
            "aria-expanded",
            "false"
        );

    document
        .getElementById(
            "mainNotificationModal"
        )
        ?.classList.remove(
            "hidden"
        );

    mainPushRefresh();
}


function mainPushCloseModal(){

    document.documentElement
        .classList.remove(
            "bpl-notification-modal-open"
        );

    document.body
        .classList.remove(
            "bpl-notification-modal-open"
        );

    document
        .getElementById(
            "mainNotificationModal"
        )
        ?.classList.add(
            "hidden"
        );
}


document
    .getElementById(
        "mainNotificationsButton"
    )
    ?.addEventListener(
        "click",
        mainPushOpenModal
    );


document
    .getElementById(
        "mainNotificationClose"
    )
    ?.addEventListener(
        "click",
        mainPushCloseModal
    );


document
    .getElementById(
        "mainNotificationModal"
    )
    ?.addEventListener(
        "click",
        event => {

            if (
                event.target.id
                === "mainNotificationModal"
            ){
                mainPushCloseModal();
            }
        }
    );


document
    .getElementById(
        "mainPushEnable"
    )
    ?.addEventListener(
        "click",
        mainPushEnable
    );


document
    .getElementById(
        "mainPushTest"
    )
    ?.addEventListener(
        "click",
        mainPushTest
    );


if (
    "serviceWorker"
    in navigator
){
    navigator.serviceWorker
        .register(
            "/sw.js",
            {
                scope:"/"
            }
        )
        .then(
            () =>
                mainPushRefresh()
        )
        .catch(
            error =>
                console.error(
                    "MAIN SERVICE WORKER FAILED:",
                    error
                )
        );
}


bootstrapHomepage()
    .catch(error => {
        console.error(
            "Homepage bootstrap failed:",
            error
        );

        groupsElement.innerHTML =
            `<div class="empty">
                Could not load the domain list.
            </div>`;

        /*
         * Never leave somebody trapped behind the loading screen
         * if an unexpected startup problem occurs.
         */
        revealHomepage();
    });



/* ---- */


(() => {
    "use strict";

    const PAGE_NAME = "main";
    const ENDPOINT = "/api/presence.php";

    function randomId() {
        try {
            const bytes = new Uint8Array(16);
            crypto.getRandomValues(bytes);

            return Array.from(
                bytes,
                b => b.toString(16).padStart(2, "0")
            ).join("");
        } catch (_) {
            return (
                Date.now().toString(16) +
                Math.random().toString(16).slice(2)
            ).padEnd(32, "0").slice(0, 32);
        }
    }

    let visitorId = "";

    try {
        visitorId =
            localStorage.getItem("bpl_presence_id") || "";

        if (!/^[a-f0-9]{32}$/.test(visitorId)) {
            visitorId = randomId();
            localStorage.setItem(
                "bpl_presence_id",
                visitorId
            );
        }
    } catch (_) {
        visitorId = randomId();
    }

    let lastPresenceBeat = 0;
    async function heartbeat() {
        if (document.visibilityState === "hidden") {
            return;
        }
        const now = Date.now();
        if (now - lastPresenceBeat < 8000) return;
        lastPresenceBeat = now;

        try {
            const response = await fetch(
                ENDPOINT,
                {
                    method: "POST",
                    credentials: "same-origin",
                    cache: "no-store",
                    keepalive: true,
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        visitorId,
                        page: PAGE_NAME
                    })
                }
            );

            const data = await response.json();

            if (!data?.ok) {
                return;
            }

            window.dispatchEvent(
                new CustomEvent(
                    "bpl:presence",
                    {
                        detail: data
                    }
                )
            );
        } catch (_) {}
    }

    heartbeat();

    setInterval(
        heartbeat,
        20000
    );

    document.addEventListener(
        "visibilitychange",
        () => {
            if (
                document.visibilityState ===
                "visible"
            ) {
                heartbeat();
            }
        }
    );

    window.addEventListener(
        "pageshow",
        heartbeat
    );
})();
