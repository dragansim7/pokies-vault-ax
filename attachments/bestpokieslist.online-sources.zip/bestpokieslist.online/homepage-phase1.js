(function () {
    let member = null;
    let changes = [];
    let savedAt = 0;

    function domainKey(value) {
        return String(value || "").trim().toLowerCase().replace(/^www\./, "");
    }

    function ago(unix) {
        const ts = Number(unix || 0);
        if (!ts) return "";
        const seconds = Math.max(0, Math.floor(Date.now() / 1000) - ts);
        if (seconds < 3600) return Math.max(1, Math.floor(seconds / 60)) + "m ago";
        if (seconds < 86400) return Math.floor(seconds / 3600) + "h ago";
        return Math.floor(seconds / 86400) + "d ago";
    }

    function infoFor(domain) {
        const map = member && member.domains ? member.domains : {};
        return map[domainKey(domain)] || null;
    }

    /* Same flag that renders "Add your link". Merchant-level: an active or
       paused link on any alias covers the whole merchant. */
    window.bplNeedsReferralLink = function (domain) {
        if (!member || !member.loggedIn) return false;
        const info = infoFor(domain);
        return !(info && info.link);
    };

    function changeFor(domain, identity) {
        const key = domainKey(domain);
        const exact = String(identity || "").replace(/\D/g, "");
        return changes.find(row => domainKey(row.domain) === key && String(row.casinoIdentity || "") === exact) || null;
    }

    window.bplDecorateCard = function (card, item) {
        if (!card || !item || item.placeholder) return;
        const domain = domainKey(item.domain);
        const info = infoFor(domain);
        const identity = String(item.casinoIdentity || "");
        if (identity) card.dataset.casinoIdentity = identity;

        const bits = [];
        const change = identity ? changeFor(domain, identity) : null;
        if (change && change.text) bits.push(change.text);
        if (info && info.link === "active") {
            bits.push("Link · Active");
        } else if (info && info.link === "paused") {
            bits.push("Link · Paused");
        }
        if (info && Number(info.sameCasino) > 0) {
            const n = Number(info.sameCasino);
            bits.push(n === 1 ? "Same casino · 1 other domain" : `Same casino · ${n} other domains`);
        }
        const canAdd = window.bplNeedsReferralLink(domain);
        if (canAdd) bits.push("Add your link");

        const meta = document.createElement("span");
        meta.className = "bpl-meta";
        if (bits.length) {
            meta.textContent = bits.join(" · ");
            if (canAdd) {
                meta.classList.add("is-action");
                meta.addEventListener("click", event => {
                    event.preventDefault();
                    event.stopPropagation();
                    if (typeof window.bplOpenAddLink === "function") window.bplOpenAddLink(domain);
                });
            }
            const title = [];
            if (change) title.push(change.text);
            if (info && info.link && info.lastServedAt) {
                title.push("Last served " + ago(info.lastServedAt));
            }
            if (info && info.aliases && info.aliases.length) {
                title.push("Also at " + info.aliases.join(", "));
            }
            if (canAdd) title.push("Add one referral link for this casino. Alias domains share the same turn.");
            meta.title = [bits.join(" · ")].concat(title).join("\n");
            meta.setAttribute("aria-label", bits.join(" · "));
            // Compact chip for narrow cards (BEST): full text stays in title/aria.
            if (info && info.link === "active") { meta.dataset.chip = "🔗 ✓"; meta.dataset.chipKind = "active"; }
            else if (info && info.link === "paused") { meta.dataset.chip = "🔗 ⏸"; meta.dataset.chipKind = "paused"; }
            else if (canAdd) { meta.dataset.chip = "➕ link"; meta.dataset.chipKind = "add"; }
        } else {
            meta.hidden = true;
        }
        let host;
        if (card.classList.contains("wallet-card") && card.querySelector(".wc-facts")) {
            host = card.querySelector(".wc-facts");
        } else {
            host = card.querySelector(".domain-info") || card;
        }
        host.append(meta);
    };

    window.bplSyncEmptyCopy = function () {
        const title = document.querySelector("[data-empty-title]");
        const hint = document.querySelector("[data-empty-hint]");
        if (!title) return;
        title.textContent = "No matching domains found.";
        if (hint) {
            hint.hidden = true;
            hint.textContent = "Try a shorter name or just part of the domain.";
        }
    };

    function rerender() {
        if (typeof render === "function") render();
    }

    function paintFetcher(known) {
        const head = document.querySelector("#bplFetcher .bf-head");
        if (!head) return;
        let line = document.getElementById("bfReturnLine");
        if (!savedAt) {
            if (line) line.hidden = true;
            if (known && member && member.loggedIn && typeof setFetcherCollapsed === "function") setFetcherCollapsed(false);
            return;
        }
        if (!line) {
            line = document.createElement("div");
            line.id = "bfReturnLine";
            line.className = "bf-return";
            const statusRow = document.getElementById("bfStatusRow");
            if (statusRow) statusRow.prepend(line);
            else head.append(line);
        }
        line.hidden = false;
        line.replaceChildren();
        const text = document.createElement("span");
        text.textContent = `Last run ${ago(savedAt)}`;
        const again = document.createElement("button");
        again.type = "button";
        again.className = "bf-again";
        again.textContent = "Fetch again";
        again.addEventListener("click", () => {
            if (typeof setFetcherCollapsed === "function") setFetcherCollapsed(false);
            document.getElementById("runBtn")?.focus();
        });
        line.append(text, again);
    }

    function showFair(badge) {
        document.getElementById("bplFairPop")?.remove();
        const card = badge.closest(".card");
        const domain = card ? card.dataset.domain : "";
        const count = Number(String(badge.textContent || "").replace(/\D/g, "")) || 0;
        const pop = document.createElement("div");
        pop.id = "bplFairPop";
        pop.className = "bpl-fair-pop";
        const info = infoFor(domain);
        const lines = [`${count} member link${count === 1 ? "" : "s"} share this casino. Each eligible member gets one fair turn.`];
        lines.push("Boosted visits are extra. They do not replace these fair turns.");
        if (info && (info.link === "active" || info.link === "paused")) {
            lines.push("Your link is included.");
            if (info.lastServedAt) lines.push("Your link was last used " + ago(info.lastServedAt) + ".");
        }
        lines.forEach(text => {
            const p = document.createElement("p");
            p.textContent = text;
            pop.append(p);
        });
        document.body.append(pop);
        const rect = badge.getBoundingClientRect();
        pop.style.top = `${window.scrollY + rect.bottom + 6}px`;
        pop.style.left = `${Math.max(8, Math.min(window.scrollX + rect.left, window.innerWidth - pop.offsetWidth - 8))}px`;
    }

    window.bplOnAccountData = function (result) {
        changes = Array.isArray(result && result.changes) ? result.changes : [];
        savedAt = Number(result && result.savedAt || 0);
        paintFetcher(true);
        if (member) rerender();
    };

    document.addEventListener("click", event => {
        const badge = event.target.closest(".community-badge");
        if (badge) {
            event.preventDefault();
            event.stopPropagation();
            showFair(badge);
            return;
        }
        if (!event.target.closest("#bplFairPop")) document.getElementById("bplFairPop")?.remove();
    });

    window.bplRefreshMember = function () {
        paintFetcher();
    };

    async function load() {
        try {
            const response = await fetch("api/homepage-member.php", {cache: "no-store", credentials: "same-origin"});
            const result = await response.json();
            if (!response.ok || !result.ok) throw new Error(result.error || "Could not load");
            member = result;
            rerender();
        } catch (error) {
        }
        if (!member || !member.loggedIn) return;
        if (typeof window.bplLoadAccountData !== "function") return;
        try {
            await window.bplLoadAccountData();
        } catch (error) {
            paintFetcher(true);
        }
    }

    load();
})();

/* No automatic keyboard (2026-10-30): on iPhone home-screen apps a text box that
   got focus on load/restore popped the keyboard. Text fields keep focus only
   when it follows a real tap, click or key press (within 4s, so modals and
   chat that focus right after a tap still work). */
(function () {
    var lastUser = 0;
    ["pointerdown", "touchstart", "mousedown", "keydown"].forEach(function (type) {
        document.addEventListener(type, function () { lastUser = Date.now(); }, true);
    });
    var TEXT = 'input:not([type=button]):not([type=submit]):not([type=reset]):not([type=checkbox]):not([type=radio]):not([type=range]):not([type=color]):not([type=file]),textarea,select,[contenteditable=""],[contenteditable="true"]';
    document.addEventListener("focusin", function (event) {
        var el = event.target;
        if (!el || !el.matches || !el.matches(TEXT)) return;
        if (Date.now() - lastUser < 4000) return;
        el.blur();
    }, true);
})();


/* NEW section: number the cards 1-20 like the other lists (2026-10-30). */
(function () {
    function numberNew() {
        document.querySelectorAll(".new-latest-grid").forEach(function (grid) {
            var n = 0;
            grid.querySelectorAll(":scope > a.card").forEach(function (card) {
                n += 1;
                var domain = card.querySelector(".domain");
                if (!domain) return;
                var idx = domain.querySelector(".card-index");
                if (idx && idx.dataset.newIndex === undefined) return; // list already numbered it
                if (!idx) {
                    idx = document.createElement("span");
                    idx.className = "card-index";
                    idx.setAttribute("aria-hidden", "true");
                    idx.dataset.newIndex = "";
                    domain.insertBefore(idx, domain.firstChild);
                }
                if (idx.textContent !== String(n)) idx.textContent = String(n);
            });
        });
    }
    numberNew();
    var queued = false;
    new MutationObserver(function () {
        if (queued) return;
        queued = true;
        requestAnimationFrame(function () { queued = false; numberNew(); });
    }).observe(document.body, {childList: true, subtree: true});
})();
