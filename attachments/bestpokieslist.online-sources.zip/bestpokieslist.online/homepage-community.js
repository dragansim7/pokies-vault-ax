/* Best Pokies List — homepage Community drawer (ReferLinks, XP, Share & Earn, chat). */
(() => {
    "use strict";

    const COMMUNITY_API = "api/community.php";
    const LINKS_API = "api/referlink-live.php";
    const TABS = ["home", "wallet", "links", "share", "ranks", "top", "reports", "chat"];
    const TAB_LABELS = {home: "Home", wallet: "Wallet", links: "Links", share: "Share", ranks: "Ranks", top: "Top Rated", reports: "Reports", chat: "Chat"};
    const CHAT_POLL_MS = 5000;

    let state = null;
    let stateLoading = null;
    let weeklyClaiming = false;
    let drawer = null;
    let activeTab = "home";
    let chatTimer = null;
    let chatLastId = 0;
    let chatView = "chat";
    let replyDraft = null;
    let lastMarkedRead = 0;
    const chatDockQuery = window.matchMedia("(min-width: 1200px)");
    let myLinks = null;
    let linksFilter = "";
    let ranksLoadedAt = 0;
    let feedLoadedAt = 0;
    let discordShare = null;
    let walletView = null;
    let walletFilter = "all";
    let walletLoadedAt = 0;
    const BULK_POLL_MS = 2500;
    const BULK_STORAGE_KEY = "bpl:referlinks:bulk:active";
    const BULK_ACTIVE_STATES = new Set(["queued", "pending", "starting", "running", "verifying", "processing", "applying", "in_progress"]);
    const BULK_TERMINAL_STATES = new Set(["complete", "completed", "success", "succeeded", "done", "failed", "error", "cancelled", "canceled"]);
    let bulkImport = {
        owner: "",
        id: "",
        snapshot: null,
        startPending: false,
        polling: false,
        timer: null,
        networkError: "",
        refreshedId: "",
    };

    const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]));
    const num = value => Number(value || 0).toLocaleString("en-AU");
    function levelPay(level, rules = state?.rules) {
        const bands = rules?.levelCreditBands || [];
        let credits = 0;
        for (const band of bands) {
            if (level >= Number(band.from)) credits = Number(band.credits);
        }
        if (!credits && level >= 2) credits = Number(rules?.levelCredits ?? 5);
        for (const milestone of rules?.levelMilestones || []) {
            if (Number(milestone.level) === level) credits += Number(milestone.credits);
        }
        return credits;
    }
    function levelBandSentence(rules = state?.rules) {
        const bands = rules?.levelCreditBands || [];
        if (!bands.length) return `every level up pays ${rules?.levelCredits ?? 5} promoter credits`;
        const parts = bands.map((row, i) => {
            const next = bands[i + 1];
            const span = next ? `${row.from}–${next.from - 1}` : `${row.from}+`;
            return `${span} pays ${row.credits}`;
        });
        const extras = (rules?.levelMilestones || []).map(row => `level ${row.level} also pays ${row.credits} extra`);
        return `Level rewards step up: ${parts.join(", ")}.${extras.length ? ` ${extras.join(", ")}.` : ""}`;
    }
    const $ = (sel, root = drawer) => root ? root.querySelector(sel) : null;

    async function post(url, payload) {
        const key = url + ":" + JSON.stringify(payload);
        if (!window.bplCommunityInflight) window.bplCommunityInflight = new Map();
        const existing = window.bplCommunityInflight.get(key);
        if (existing) return existing;
        const job = postNow(url, payload).finally(() => window.bplCommunityInflight.delete(key));
        window.bplCommunityInflight.set(key, job);
        return job;
    }

    async function postNow(url, payload) {
        const response = await fetch(url, {
            method: "POST",
            credentials: "same-origin",
            cache: "no-store",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(payload)
        });
        let data;
        try { data = await response.json(); } catch { data = {ok: false, error: "Unexpected server response."}; }
        if (!response.ok || data?.ok === false) {
            const error = new Error(data?.error || `Request failed (${response.status})`);
            error.status = response.status;
            throw error;
        }
        return data;
    }

    function timeAgo(ts) {
        if (!ts) return "";
        const diff = Math.max(0, Date.now() / 1000 - ts);
        if (diff < 60) return "just now";
        if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
        if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
        if (diff < 86400 * 7) return `${Math.floor(diff / 86400)}d ago`;
        return new Date(ts * 1000).toLocaleDateString("en-AU", {day: "numeric", month: "short"});
    }

    function clockTime(ts) {
        if (!ts) return "";
        return new Date(ts * 1000).toLocaleTimeString("en-AU", {hour: "numeric", minute: "2-digit"});
    }

    /* Chat bodies arrive pre-sanitised: raw URLs never reach the browser. */
    function messageBodyHtml(m) {
        if (!Array.isArray(m.parts)) return esc(m.message);
        if (m.linkOnly) {
            const mentions = m.parts.filter(p => p.t !== "text");
            const shown = mentions.slice(0, 4).map(p => partHtml(p)).join(" ");
            const more = mentions.length - 4;
            return `<span class="bc-link-dump">${shown}${more > 0 ? ` <span class="bc-host-tag">+${more} more</span>` : ""}</span>`;
        }
        return m.parts.map(partHtml).join("");
    }

    function casinoNote(part) {
        if (part.available === false) return "Not in the turn";
        if (part.mine) return part.inTurn ? "Your link is in this turn" : "Not in the turn yet";
        const seats = Number(part.seats) || 0;
        return seats > 0 ? `Fair turn · ${seats} ${seats === 1 ? "member" : "members"}` : "Fair turn";
    }

    function partHtml(p) {
        if (p.t === "casino") {
            const note = casinoNote(p);
            const icon = p.favicon ? `<img src="${esc(p.favicon)}" alt="" width="22" height="22" loading="lazy" decoding="async">` : "";
            if (p.available === false) {
                return `<span class="bc-casino-card bc-casino-off">${icon}<span><b>${esc(p.domain)}</b><small>${esc(note)}</small></span></span>`;
            }
            return `<button type="button" class="bc-casino-card" data-bc-action="playCasino" data-domain="${esc(p.domain)}" title="Opens ${esc(p.domain)}. Community links take fair turns.">${icon}<span><b>${esc(p.domain)}</b><small>${esc(note)}</small></span></button>`;
        }
        if (p.t === "link") return `<a href="${esc(p.v)}" target="_blank" rel="noopener">${esc(p.v)}</a>`;
        if (p.t === "host") return `<span class="bc-host-tag">🔗 ${esc(p.v)}</span>`;
        return esc(p.v);
    }

    /* Same signed card link (and fair allocator) as pressing the casino's card. */
    async function playCasino(domain) {
        const card = [...document.querySelectorAll("a.card[data-domain]")].find(a => a.dataset.domain === domain && /\/go\.php\?t=/.test(a.href));
        if (card) { window.open(card.href, "_blank", "noopener"); return; }
        const win = window.open("about:blank", "_blank");
        try {
            const res = await fetch(`api/homepage-domains.php?domain=${encodeURIComponent(domain)}`, {credentials: "same-origin", cache: "no-store"});
            const data = await res.json();
            if (!data.ok || !data.url) throw new Error("unavailable");
            if (win) { win.opener = null; win.location.href = data.url; } else location.href = data.url;
        } catch (error) {
            win?.close();
            toast(`${domain} isn't available right now`, "error");
        }
    }

    function toast(message, type = "info") {
        let host = document.getElementById("bcToastHost");
        if (!host) {
            host = document.createElement("div");
            host.id = "bcToastHost";
            host.className = "bc-toast-host";
            host.setAttribute("aria-live", "polite");
            document.body.append(host);
        }
        const node = document.createElement("div");
        node.className = `bc-toast bc-toast-${type}`;
        node.textContent = message;
        host.append(node);
        setTimeout(() => node.classList.add("bc-toast-out"), 3200);
        setTimeout(() => node.remove(), 3700);
    }

    /* ---------- header button + level chip ---------- */

    function updateHeaderChip() {
        window.bplCommunityState = state || null;
        const status = document.getElementById("memberStatus");
        if (status) status.hidden = true;
        if (typeof window.bplRefreshMember === "function") window.bplRefreshMember();
        const chip = document.getElementById("communityLevelChip");
        const button = document.getElementById("communityButton");
        if (!chip || !button) return;
        if (!state?.loggedIn) {
            chip.textContent = "";
            chip.hidden = true;
            button.style.removeProperty("--bc-progress");
            return;
        }
        const p = state.progress;
        chip.hidden = false;
        chip.textContent = `Lv ${p.level}`;
        chip.title = `${p.title} • ${num(p.xp)} XP • ${p.progressXp}/${p.progressNeeded} to level ${p.level + 1}`;
        button.style.setProperty("--bc-progress", `${p.progressPercent}%`);
    }

    /* ---------- homepage community hub ---------- */

    const PULSE_MS = 60000;

    const nameHue = name => [...String(name || "")].reduce((h, c) => (h * 31 + c.codePointAt(0)) % 360, 7);
    const avatar = (m, cls = "ch-av") => {
        const initial = m.initial || String(m.name || "?").trim().charAt(0).toUpperCase() || "?";
        const hue = m.hue ?? nameHue(m.name);
        return m.avatar
            ? `<span class="${cls} has-img" aria-hidden="true"><img src="${esc(m.avatar)}" alt="" loading="lazy" decoding="async"></span>`
            : `<span class="${cls}" style="--h:${Number(hue) || 0}" aria-hidden="true">${esc(initial)}</span>`;
    };
    const memberLink = (id, name, cls = "") => id
        ? `<button type="button" class="member-link ${cls}" data-member-id="${esc(id)}" title="View ${esc(name)}'s profile">${esc(name)}</button>`
        : `<b class="${cls}">${esc(name)}</b>`;

    function renderHubMe() {
        const box = document.querySelector("[data-ch-me]");
        if (!box) return;
        if (!state?.loggedIn) { box.hidden = true; return; }
        const p = state.progress;
        const prof = state.profile || {};
        const links = state.links || {};
        const name = prof.displayName ? prof.publicName : "Set your community name";
        box.hidden = false;
        box.innerHTML = `
            <button type="button" class="ch-me-main" data-open-community="home">
                <span class="ch-me-name"><b>${esc(name)}</b> <span class="ch-lv">LV ${p.level}</span> <small>${esc(p.title)}</small></span>
                <span class="ch-bar" role="progressbar" aria-valuemin="0" aria-valuemax="${p.progressNeeded}" aria-valuenow="${p.progressXp}" aria-label="XP to next level"><i style="width:${p.progressPercent}%"></i></span>
                <small class="ch-me-sub">${num(p.progressXp)}/${num(p.progressNeeded)} XP to LV ${p.level + 1} · ${state.linksManaged ? `${num(links.enabled)} link${links.enabled === 1 ? "" : "s"} taking turns` : "Owner account"}${state.todayXp ? ` · +${num(state.todayXp)} XP today` : ""}</small>
            </button>`;
        box.querySelector("[data-open-community]").addEventListener("click", () => openDrawer("home"));
    }

    let lastPulseKey = "";

    function renderPulse(data) {
        const hub = document.getElementById("communityHub");
        if (!hub || !data) return;
        const key = JSON.stringify([data.online, data.stats, data.activity, data.week]);
        if (key === lastPulseKey) return;
        lastPulseKey = key;
        const online = data.online || {};
        const s = data.stats || {};
        hub.querySelector("[data-ch-online]").textContent = num(online.visitors);
        const people = online.members || [];
        hub.querySelector("[data-ch-people]").innerHTML = people.length
            ? people.slice(0, 4).map(m => `<button type="button" class="ch-person" ${m.id ? `data-member-id="${esc(m.id)}"` : ""} title="${esc(m.name)} · LV ${m.level}${m.did ? ` · ${m.did}` : ""}">${avatar(m)}<span class="ch-person-name">${esc(m.name)}</span><span class="ch-lv">LV ${m.level}</span></button>`).join("")
              + (online.memberCount > 4 ? `<span class="ch-more">+${online.memberCount - 4}</span>` : "")
            : "";
        const doing = hub.querySelector("[data-ch-doing]");
        if (doing) {
            const lines = people.filter(m => m.did).slice(0, 3).map(m => `${memberLink(m.id, m.name)} ${esc(m.did)}`);
            doing.hidden = lines.length === 0;
            doing.innerHTML = lines.join('<span class="ch-dot">·</span>');
        }
        hub.querySelector("[data-ch-stats]").innerHTML = [
            [s.links, "link", "links"], [s.contributors, "contributor", "contributors"], [s.casinos, "casino covered", "casinos covered"], [s.playsToday, "community play today", "community plays today"]
        ].map(([n, one, many]) => `<span><b>${num(n)}</b> ${Number(n) === 1 ? one : many}</span>`).join("");
        const items = data.activity || [];
        const list = hub.querySelector("[data-ch-activity]");
        list.hidden = items.length === 0;
        list.innerHTML = items.map(a => {
            const who = memberLink(a.memberId, a.who);
            let body;
            if (a.type === "chat") body = `${who} <span class="ch-lv">LV ${a.level}</span> <q>${esc(a.text)}</q>`;
            else if (a.type === "link") body = `${who} added a link for <button type="button" class="ch-domain" data-ch-find="${esc(a.domain)}">${esc(a.domain)}</button>`;
            else if (a.type === "domain") body = `${who} added <button type="button" class="ch-domain" data-ch-find="${esc(a.domain)}">${esc(a.domain)}</button>`;
            else body = `${who} reached <span class="ch-lv">LV ${a.level}</span> 🏆`;
            return `<li>${avatar(a)}<span class="ch-act-text">${body}</span><time>${esc(timeAgo(a.ts))}</time></li>`;
        }).join("");
        renderChatPreview(data.chatPreview, items);
        const week = hub.querySelector("[data-ch-week]");
        if (week) {
            const w = data.week || {};
            const bits = [];
            const linkCount = Number(w.links) || 0;
            const memberCount = Number(w.members) || 0;
            if (linkCount) bits.push(`<b>${num(linkCount)}</b> new link${linkCount === 1 ? "" : "s"}`);
            if (memberCount) bits.push(`<b>${num(memberCount)}</b> new member${memberCount === 1 ? "" : "s"}`);
            if (w.climb && w.climb.name) bits.push(`${memberLink(w.climb.memberId, w.climb.name)} reached <span class="ch-lv">LV ${num(w.climb.level)}</span>`);
            week.hidden = bits.length === 0;
            week.innerHTML = bits.length ? `This week <span class="ch-dot">·</span> ${bits.join(' <span class="ch-dot">·</span> ')}` : "";
        }
    }

    function activityLine(item) {
        const who = esc(item.who || "Someone");
        if (item.type === "chat") return `${who} in chat`;
        if (item.type === "link") return `${who} added a link for ${esc(item.domain || "")}`;
        if (item.type === "domain") return `${who} added ${esc(item.domain || "a casino")}`;
        if (item.type === "level") return `${who} reached LV ${Number(item.level) || 1}`;
        return who;
    }

    function previewBody(message) {
        const casino = (message.parts || []).find(part => part.t === "casino");
        if (casino) return `shared ${esc(casino.domain)} · ${esc(casinoNote(casino))}`;
        const text = (message.parts || []).filter(part => part.t === "text").map(part => part.v).join(" ").replace(/\s+/g, " ").trim();
        return esc(text || message.text || "");
    }

    function bindStripOpens(root) {
        root.querySelectorAll("[data-open-community]").forEach(button => {
            if (button.dataset.bound === "1") return;
            button.dataset.bound = "1";
            button.addEventListener("click", event => {
                event.preventDefault();
                if (typeof window.closeSideDrawerBeforeAction === "function") window.closeSideDrawerBeforeAction();
                openDrawer(button.dataset.openCommunity || "chat");
            });
        });
    }

    function renderChatPreview(preview, activity) {
        const host = document.querySelector("[data-ch-preview]");
        if (!host) return;
        const rows = Array.isArray(preview) ? preview : [];
        if (!rows.length) {
            const items = (activity || []).slice(0, 2);
            host.innerHTML = items.length
                ? items.map(item => `<button type="button" class="ch-preview-row" data-open-community="chat">${avatar(item)}<span class="ch-preview-text">${activityLine(item)}</span></button>`).join("")
                : `<button type="button" class="ch-preview-empty" data-open-community="chat">Live chat is quiet. Open it to say hello.</button>`;
        } else {
            host.innerHTML = rows.slice(0, 3).map(message => `<button type="button" class="ch-preview-row" data-open-community="chat">${avatar(message, "ch-av")}<span class="ch-preview-text"><b>${esc(message.name)}</b> ${previewBody(message)}</span></button>`).join("");
        }
        bindStripOpens(host);
    }

    function setUnreadDot(on) {
        document.getElementById("communityButton")?.classList.toggle("bc-has-unread", !!on);
    }

    async function refreshUnread() {
        if (!state?.loggedIn || activeTab === "chat" && drawer?.classList.contains("bc-open")) {
            if (!state?.loggedIn) setUnreadDot(false);
            return;
        }
        try {
            const data = await post(LINKS_API, {action: "chatUnread"});
            setUnreadDot(Number(data.unread) > 0);
        } catch (error) { /* keep the current dot */ }
    }

    async function loadPulse() {
        if (document.hidden) return;
        try { renderPulse(await post(COMMUNITY_API, {action: "pulse"})); } catch (error) { /* keep last pulse */ }
        refreshUnread();
    }

    /* ---------- 👥 card badge explainer ---------- */

    let badgePop = null;
    let badgeSource = null;

    function closeBadgePop() {
        badgePop?.remove();
        badgePop = null;
        badgeSource = null;
    }

    function openBadgePop(badge) {
        closeBadgePop();
        badgeSource = badge;
        const count = Number(badge.dataset.communityCount) || 0;
        const casino = badge.closest(".card")?.dataset.domain || "this casino";
        const pop = document.createElement("div");
        pop.className = "cb-pop";
        pop.setAttribute("role", "dialog");
        pop.setAttribute("aria-label", "Community links on this card");
        pop.innerHTML = `
            <strong>👥 ${count} member${count === 1 ? "'s link" : "s' links"} on ${esc(casino)}</strong>
            <ul class="cb-pop-members" data-cb-members><li class="cb-pop-loading">Loading members…</li></ul>
            <p>Members' links on this card take turns in order, so every member gets a fair turn. Tap a name to see their profile.</p>
            <div class="cb-pop-actions"><button type="button" class="ch-btn ch-btn-primary" data-cb-add>➕ Add yours</button><button type="button" class="ch-btn" data-cb-close>Got it</button></div>`;
        document.body.append(pop);
        const place = () => {
            const r = badge.getBoundingClientRect();
            const w = pop.offsetWidth, h = pop.offsetHeight;
            const left = Math.min(Math.max(8, r.left + r.width / 2 - w / 2), window.innerWidth - w - 8);
            const below = r.bottom + 8 + h <= window.innerHeight - 8;
            pop.style.left = `${left}px`;
            pop.style.top = `${below ? r.bottom + 8 : Math.max(8, r.top - h - 8)}px`;
        };
        place();
        pop.addEventListener("click", event => {
            if (event.target.closest("[data-cb-add]")) { closeBadgePop(); openDrawer("links"); }
            else if (event.target.closest("[data-cb-close]")) closeBadgePop();
        });
        badgePop = pop;
        pop.querySelector("[data-cb-close]").focus({preventScroll: true});
        loadDomainMembers(casino).then(data => {
            if (badgePop !== pop) return;
            const list = pop.querySelector("[data-cb-members]");
            const members = data.members || [];
            list.innerHTML = members.map(m => `<li><button type="button" class="cb-member" data-member-id="${esc(m.id)}">${avatar(m, "cb-av")}<span class="cb-member-name">${esc(m.name)}</span><span class="ch-lv">LV ${m.level}</span></button></li>`).join("")
                + (data.others ? `<li class="cb-pop-loading">+${data.others} Discord member${data.others === 1 ? "" : "s"}</li>` : "")
                || `<li class="cb-pop-loading">No member links right now.</li>`;
            place();
        }).catch(() => {
            if (badgePop === pop) pop.querySelector("[data-cb-members]").innerHTML = `<li class="cb-pop-loading">Members unavailable.</li>`;
        });
    }

    const domainMembersCache = new Map();
    async function loadDomainMembers(domain) {
        const hit = domainMembersCache.get(domain);
        if (hit && Date.now() - hit.at < 60000) return hit.data;
        const data = await post(COMMUNITY_API, {action: "domainMembers", domain});
        domainMembersCache.set(domain, {at: Date.now(), data});
        return data;
    }

    /* ---------- public member profile ---------- */

    let profileModal = null;

    function closeProfile() {
        profileModal?.remove();
        profileModal = null;
        document.documentElement.classList.remove("mp-open");
    }

    function profileStat(value, label) {
        return `<div class="mp-stat"><b>${num(value)}</b><span>${esc(label)}</span></div>`;
    }

    async function openProfile(id, options = {}) {
        if (!/^[a-f0-9]{16}$/.test(String(id || ""))) return;
        closeBadgePop();
        closeProfile();
        const customize = options.customize === true;
        const modal = document.createElement("div");
        modal.className = "mp-modal";
        modal.setAttribute("role", "dialog");
        modal.setAttribute("aria-modal", "true");
        modal.setAttribute("aria-label", customize ? "Customize profile" : "Member profile");
        modal.dataset.memberId = id;
        if (customize) modal.dataset.customize = "1";
        modal.innerHTML = `<div class="mp-card"><button type="button" class="mp-close" data-mp-close aria-label="Close profile">×</button><div class="mp-body"><div class="bc-loading">Loading profile…</div></div></div>`;
        document.body.append(modal);
        document.documentElement.classList.add("mp-open");
        profileModal = modal;
        modal.addEventListener("click", event => {
            if (event.target === modal || event.target.closest("[data-mp-close]")) { closeProfile(); return; }
            const buy = event.target.closest("[data-mp-buy]");
            const equip = event.target.closest("[data-mp-equip]");
            const savePins = event.target.closest("[data-mp-save-pins]");
            if (buy || equip || savePins) {
                event.preventDefault();
                const run = async () => {
                    if (buy) {
                        if (!window.confirm(`Buy ${buy.dataset.name} for ${buy.dataset.credits} credits?`)) return;
                        await post(COMMUNITY_API, {action: "profileBuy", item: buy.dataset.item});
                    } else if (equip) {
                        await post(COMMUNITY_API, {action: "profileEquip", kind: equip.dataset.kind, item: equip.dataset.item});
                    } else {
                        const urls = [...modal.querySelectorAll("[data-mp-pin-url]")].map(input => input.value.trim());
                        await post(COMMUNITY_API, {action: "profilePins", urls});
                    }
                    await reloadProfile(modal);
                };
                run().catch(error => {
                    const status = modal.querySelector("[data-mp-status]");
                    if (status) status.textContent = error.message;
                });
                return;
            }
            const find = event.target.closest("[data-mp-find]");
            if (find) {
                closeProfile();
                closeDrawer();
                const input = document.getElementById("domainSearchInput");
                if (input) {
                    input.value = find.dataset.mpFind;
                    if (typeof window.applyDomainSearch === "function") window.applyDomainSearch(input.value);
                    else input.dispatchEvent(new Event("input", {bubbles: true}));
                    input.scrollIntoView({behavior: "smooth", block: "center"});
                }
            }
        });
        modal.querySelector("[data-mp-close]").focus({preventScroll: true});
        try {
            const data = await post(COMMUNITY_API, {action: "profile", id});
            if (profileModal !== modal) return;
            paintProfile(modal, data);
        } catch (error) {
            if (profileModal === modal) modal.querySelector(".mp-body").innerHTML = `<div class="bc-empty">⚠️ ${esc(error.message)}</div>`;
        }
    }

    async function reloadProfile(modal) {
        const data = await post(COMMUNITY_API, {action: "profile", id: modal.dataset.memberId});
        if (profileModal !== modal) return;
        if (data.studio && typeof data.studio.credits === "number" && state) {
            state.credits = data.studio.credits;
            const strong = document.querySelector(".bc-credits strong");
            if (strong) strong.textContent = num(state.credits);
        }
        paintProfile(modal, data);
    }

    function paintProfile(modal, data) {
            const m = data.member, st = data.stats, p = m.progress;
            const since = m.memberSince ? new Date(m.memberSince * 1000).toLocaleDateString("en-AU", {month: "short", year: "numeric"}) : "";
            const chips = list => list.map(d => `<button type="button" class="mp-chip" data-mp-find="${esc(d.domain)}">${esc(d.domain)}</button>`).join("");
            const metaBits = [];
            if (since) metaBits.push(`Member since ${since}`);
            if (m.streakDays) metaBits.push(`🔥 ${m.streakDays}-day streak`);
            const recentHtml = (data.recent || []).map(item => {
                let text = "";
                if (item.type === "link") text = `Added a link for <button type="button" class="mp-chip" data-mp-find="${esc(item.domain)}">${esc(item.domain)}</button>`;
                else if (item.type === "level") text = `Reached level ${num(item.level)}`;
                else if (item.type === "chat") text = `In chat: “${esc(item.text)}”`;
                if (!text) return "";
                return `<li><span>${text}</span><time>${esc(timeAgo(item.ts))}</time></li>`;
            }).join("");
            const pins = (data.style && data.style.pins) || [];
            const pinHtml = pins.map(pin => {
                const url = String(pin.url || "");
                const open = /^https?:\/\//i.test(url);
                const label = esc(open ? url : pin.domain);
                const name = open
                    ? `<a class="mp-casino-name" href="${esc(url)}" target="_blank" rel="noopener noreferrer">${label}</a>`
                    : `<span class="mp-casino-name">${label}</span>`;
                return `<li class="mp-casino">
                    <img src="api/favicon.php?domain=${encodeURIComponent(pin.domain || "")}" alt="" loading="lazy" referrerpolicy="no-referrer">
                    ${name}
                </li>`;
            }).join("");
            const studio = modal.dataset.customize === "1" ? data.studio : null;
            const studioHtml = studio ? profileStudioHtml(studio) : "";
            const card = modal.querySelector(".mp-card");
            const style = data.style || {};
            card.dataset.border = style.border || "";
            card.dataset.bg = style.background || "";
            card.dataset.accent = style.accent || "";
            modal.querySelector(".mp-body").innerHTML = `
                <div class="mp-head">
                    ${avatar(m, "mp-av")}
                    <div class="mp-id">
                        <h3>${esc(m.name)}</h3>
                        <div class="mp-sub"><span class="ch-lv">LV ${p.level}</span> ${esc(p.title)}${m.rank ? ` · #${num(m.rank)}` : ""}</div>
                        ${metaBits.length ? `<div class="mp-sub mp-muted">${esc(metaBits.join(" · "))}</div>` : ""}
                        <div class="mp-xp"><span class="ch-bar"><i style="width:${p.progressPercent}%"></i></span><small>${num(p.xp)} XP · ${num(p.progressXp)}/${num(p.progressNeeded)} to LV ${p.level + 1}</small></div>
                    </div>
                </div>
                <div class="mp-stats mp-lead">
                    ${profileStat(st.uniquePeople, "People reached")}
                    ${profileStat(st.linksActive, "Links in the turn")}
                    ${profileStat(st.newMembers, "Members referred")}
                </div>
                <div class="mp-stats mp-more">
                    ${profileStat(st.chatMessages, "Chat messages")}
                    ${profileStat(st.domainsAdded, "Domains added")}
                    ${profileStat(st.verifiedVisits, "Referral visits")}
                </div>
                ${recentHtml ? `<div class="mp-section"><h4>Recent</h4><ul class="mp-recent">${recentHtml}</ul></div>` : ""}
                ${data.badges?.length ? `<div class="mp-section"><h4>Badges</h4><div class="mp-badges">${data.badges.map(b => `<span class="mp-badge">${b.icon} ${esc(b.name)}</span>`).join("")}</div></div>` : ""}
                ${pinHtml ? `<div class="mp-section"><h4>Pinned links</h4><ul class="mp-casinos">${pinHtml}</ul></div>` : ""}
                ${data.domainsAdded?.length ? `<div class="mp-section"><h4>New domains</h4><div class="mp-chips">${chips(data.domainsAdded)}</div></div>` : ""}
                ${studioHtml}`;
    }

    function profileStudioHtml(studio) {
        const groups = [["border", "Borders"], ["background", "Backgrounds"], ["accent", "Name colours"]];
        const shop = groups.map(([kind, title]) => {
            const items = (studio.catalog || []).filter(item => item.kind === kind);
            const noneOn = !items.some(item => item.equipped);
            const swatches = [`<button type="button" class="mp-swatch${noneOn ? " mp-on" : ""}" data-mp-equip data-kind="${kind}" data-item="none">None</button>`]
                .concat(items.map(item => {
                    const action = item.owned ? "data-mp-equip" : "data-mp-buy";
                    const price = item.owned ? (item.equipped ? "On" : "Equip") : `${num(item.credits)} cr`;
                    return `<button type="button" class="mp-swatch mp-swatch-${esc(item.id)}${item.equipped ? " mp-on" : ""}" ${action} data-kind="${esc(item.kind)}" data-item="${esc(item.id)}" data-name="${esc(item.name)}" data-credits="${num(item.credits)}"><b>${esc(item.name)}</b><small>${price}</small></button>`;
                })).join("");
            return `<div class="mp-shop-group"><h5>${title}</h5><div class="mp-swatches">${swatches}</div></div>`;
        }).join("");
        const current = [...(studio.pinUrls || [])].slice(0, 3);
        while (current.length < 3) current.push("");
        const fields = current.map((url, index) => `<label class="mp-pin-field"><span>Referlink ${index + 1}</span><input type="url" inputmode="url" autocomplete="off" spellcheck="false" data-mp-pin-url value="${esc(url)}" placeholder="Paste a referlink"></label>`).join("");
        const credits = typeof studio.credits === "number" ? `${num(studio.credits)} credits` : "Credits unavailable";
        return `<div class="mp-section mp-studio">
            <h4>Your profile <small>${credits}</small></h4>
            <p class="bc-small bc-muted">Paste up to 3 referlinks. They show on your profile and open when someone taps them.</p>
            <div class="mp-pin-fields">${fields}</div>
            <button type="button" class="bc-btn bc-btn-primary" data-mp-save-pins>Save referlinks</button>
            ${shop}
            <p class="mp-shop-status" data-mp-status></p>
        </div>`;
    }

    function bootProfiles() {
        document.addEventListener("click", event => {
            const link = event.target.closest?.("[data-member-id]");
            if (!link || link.closest(".mp-modal")) return;
            event.preventDefault();
            event.stopPropagation();
            openProfile(link.dataset.memberId);
        }, true);
        document.addEventListener("keydown", event => {
            if (event.key === "Escape" && profileModal) closeProfile();
        });
    }

    function bootBadges() {
        const intercept = event => {
            const badge = event.target.closest?.(".community-badge[data-community-count]");
            if (!badge) return false;
            event.preventDefault();
            event.stopPropagation();
            return badge;
        };
        document.addEventListener("click", event => {
            const badge = intercept(event);
            if (badge) {
                if (badgeSource === badge && badgePop) closeBadgePop();
                else openBadgePop(badge);
                return;
            }
            if (badgePop && !badgePop.contains(event.target)) closeBadgePop();
        }, true);
        document.addEventListener("keydown", event => {
            if (event.key === "Escape") { closeBadgePop(); return; }
            if ((event.key === "Enter" || event.key === " ") && event.target.matches?.(".community-badge[data-community-count]")) {
                intercept(event);
                openBadgePop(event.target);
            }
        }, true);
        window.addEventListener("scroll", closeBadgePop, {passive: true});
        window.addEventListener("resize", closeBadgePop);
    }

    function setHubOpen(hub, open) {
        const toggle = hub.querySelector("[data-ch-toggle]");
        hub.querySelector("#chDetails").hidden = !open;
        hub.classList.toggle("ch-open", open);
        toggle.setAttribute("aria-expanded", String(open));
        toggle.setAttribute("aria-label", open ? "Hide community details" : "Show community details");
    }

    function bootHub() {
        const hub = document.getElementById("communityHub");
        if (!hub) return;
        let open = false;
        try { open = sessionStorage.getItem("bplHubOpen") === "1"; } catch (e) {}
        setHubOpen(hub, open);
        hub.querySelector("[data-ch-toggle]").addEventListener("click", () => {
            open = !open;
            setHubOpen(hub, open);
            try { sessionStorage.setItem("bplHubOpen", open ? "1" : "0"); } catch (e) {}
        });
        hub.addEventListener("click", event => {
            const find = event.target.closest("[data-ch-find]");
            if (!find) return;
            const input = document.getElementById("domainSearchInput");
            if (!input) return;
            input.value = find.dataset.chFind;
            if (typeof window.applyDomainSearch === "function") window.applyDomainSearch(find.dataset.chFind);
            else input.dispatchEvent(new Event("input", {bubbles: true}));
            input.scrollIntoView({behavior: "smooth", block: "center"});
        });
        loadPulse();
        setInterval(loadPulse, PULSE_MS);
        document.addEventListener("visibilitychange", () => { if (!document.hidden) loadPulse(); });
    }

    async function loadState(force = false) {
        if (state && !force) return state;
        if (stateLoading && !force) return stateLoading;
        stateLoading = post(COMMUNITY_API, {action: "state"})
            .then(data => {
                const previous = state;
                state = data;
                syncBulkImportOwner();
                updateHeaderChip();
                renderHubMe();
                if (previous?.loggedIn && data.loggedIn) {
                    const gained = data.progress.xp - previous.progress.xp;
                    if (gained > 0) toast(`+${gained} XP`, "xp");
                    if (data.progress.level > previous.progress.level) {
                        let bonus = 0;
                        for (let level = previous.progress.level + 1; level <= data.progress.level; level++) bonus += levelPay(level, data.rules);
                        toast(`🎉 Level ${data.progress.level}! +${bonus} credits`, "xp");
                    }
                }
                if (data.loggedIn && data.share?.claimedNow > 0) toast(`🎉 ${data.share.claimedNow} verified referral${data.share.claimedNow > 1 ? "s" : ""} rewarded`, "xp");
                return data;
            })
            .finally(() => { stateLoading = null; });
        return stateLoading;
    }

    /* ---------- drawer shell ---------- */

    function buildDrawer() {
        drawer = document.createElement("div");
        drawer.id = "communityDrawer";
        drawer.className = "bc-overlay";
        drawer.hidden = true;
        drawer.innerHTML = `
            <aside class="bc-drawer" role="dialog" aria-modal="true" aria-labelledby="bcTitle">
                <header class="bc-head">
                    <div class="bc-head-main">
                        <div class="bc-avatar" aria-hidden="true"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><circle cx="17" cy="9" r="2.8"/><path d="M16.5 14.2c3 .2 5 2.3 5 5.3"/></svg></div>
                        <div class="bc-head-text">
                            <strong id="bcTitle">Community</strong>
                            <span id="bcSubtitle">Wallet, links, ranks and chat</span>
                        </div>
                    </div>
                    <button type="button" class="bc-close" data-bc-close aria-label="Close community">✕</button>
                </header>
                <div id="bcLevelBar" class="bc-levelbar" hidden></div>
                <nav class="bc-tabs" role="tablist">
                    ${TABS.map(tab => `<button type="button" role="tab" class="bc-tab" data-bc-tab="${tab}" aria-selected="false">${TAB_LABELS[tab]}</button>`).join("")}
                </nav>
                <div class="bc-body">
                    ${TABS.map(tab => `<section class="bc-panel" data-bc-panel="${tab}" role="tabpanel" hidden></section>`).join("")}
                </div>
            </aside>`;
        document.body.append(drawer);

        drawer.addEventListener("click", event => {
            if (event.target === drawer || event.target.closest("[data-bc-close]")) { closeDrawer(); return; }
            const tab = event.target.closest("[data-bc-tab]");
            if (tab) { selectTab(tab.dataset.bcTab); return; }
            const go = event.target.closest("[data-bc-go]");
            if (go) { selectTab(go.dataset.bcGo); return; }
            const action = event.target.closest("[data-bc-action]");
            if (action) handleAction(action, event);
        });
        drawer.addEventListener("submit", event => {
            event.preventDefault();
            const form = event.target;
            if (form.matches("[data-bc-form=profile]")) saveProfile(form);
            else if (form.matches("[data-bc-form=addlink]")) addLinks(form);
            else if (form.matches("[data-bc-form=chat]")) sendChat(form);
            else if (form.matches("[data-bc-form=wallet]")) submitWallet(form);
        });
        drawer.addEventListener("input", event => {
            if (event.target.matches("[data-bc-links-filter]")) {
                linksFilter = event.target.value.trim().toLowerCase();
                renderLinkList();
            } else if (event.target.matches("[data-bc-form=chat] input, [data-bc-form=chat] input[name=message]")) {
                updateMentionSuggest(event.target);
            }
        });
        document.addEventListener("keydown", event => {
            if (event.key === "Escape" && drawer && !drawer.hidden) closeDrawer();
        });
        wireTopRated();
    }

    function setUrlTab(tab) {
        try {
            const url = new URL(location.href);
            if (tab) url.searchParams.set("community", tab);
            else url.searchParams.delete("community");
            history.replaceState(history.state, "", url.pathname + url.search + url.hash);
        } catch {}
    }

    window.bplOpenAddLink = function (domain) {
        window.bplPendingLinkDomain = String(domain || "");
        openDrawer("links");
    };

    function syncChatDock() {
        if (!drawer) return;
        const open = drawer.classList.contains("bc-open");
        const dock = open && activeTab === "chat" && chatDockQuery.matches;
        drawer.classList.toggle("bc-dock", dock);
        document.documentElement.classList.toggle("bc-lock", open && !dock);
        if (typeof window.bplScrollLock === "function") window.bplScrollLock("community", open && !dock, drawer); /* BPL_SCROLL_LOCK */
    }

    function openDrawer(tab = "home") {
        if (!drawer) buildDrawer();
        drawer.hidden = false;
        drawer.classList.add("bc-open");
        selectTab(TABS.includes(tab) ? tab : "home");
        syncChatDock();
        loadState(true).then(renderAll).catch(error => renderError(error));
    }

    function closeDrawer() {
        if (!drawer) return;
        drawer.classList.remove("bc-open", "bc-dock");
        document.documentElement.classList.remove("bc-lock");
        if (typeof window.bplScrollLock === "function") window.bplScrollLock("community", false);
        stopChat();
        setUrlTab(null);
        setTimeout(() => { if (!drawer.classList.contains("bc-open")) drawer.hidden = true; }, 220);
    }

    function selectTab(tab) {
        activeTab = tab;
        drawer.querySelectorAll("[data-bc-tab]").forEach(btn => {
            const on = btn.dataset.bcTab === tab;
            btn.classList.toggle("bc-tab-active", on);
            btn.setAttribute("aria-selected", on ? "true" : "false");
            if (on) {
                const bar = btn.parentElement;
                if (bar && (btn.offsetLeft < bar.scrollLeft || btn.offsetLeft + btn.offsetWidth > bar.scrollLeft + bar.clientWidth)) {
                    bar.scrollLeft = Math.max(0, btn.offsetLeft - (bar.clientWidth - btn.offsetWidth) / 2);
                }
            }
        });
        drawer.querySelectorAll("[data-bc-panel]").forEach(panel => { panel.hidden = panel.dataset.bcPanel !== tab; });
        drawer.classList.toggle("bc-tab-chat", tab === "chat"); /* BPL_CHAT_COMPACT: hides the level card on Chat */
        setUrlTab(tab);
        if (tab === "chat") startChat(); else stopChat();
        syncChatDock();
        if (state) renderTab(tab);
        else $(`[data-bc-panel="${tab}"]`).innerHTML = `<div class="bc-loading">Loading…</div>`;
    }

    function renderError(error) {
        const panel = $(`[data-bc-panel="${activeTab}"]`);
        if (panel) panel.innerHTML = `<div class="bc-empty">⚠️ ${esc(error.message || "Community is unavailable right now.")}<br><button type="button" class="bc-btn" data-bc-action="retry">Try again</button></div>`;
    }

    function renderAll() {
        renderLevelBar();
        renderTab(activeTab);
    }

    function renderTab(tab) {
        if (tab === "home") renderHome();
        else if (tab === "wallet") renderWallet();
        else if (tab === "links") renderLinks();
        else if (tab === "share") renderShare();
        else if (tab === "ranks") renderRanks();
        else if (tab === "top") renderTopRated();
        else if (tab === "reports") renderReports();
        else if (tab === "chat") renderChatShell();
    }

    /* Reports tab (payout + scam reports) lives in community-reports.js. */
    function renderReports() {
        const panel = $('[data-bc-panel="reports"]');
        if (!panel) return;
        if (window.bplReportsTab) window.bplReportsTab.render(panel, {loggedIn: Boolean(state?.loggedIn)});
        else panel.innerHTML = `<div class="bc-empty">Reports are loading… please refresh the page if this stays.</div>`;
    }

    function renderLevelBar() {
        const bar = $("#bcLevelBar");
        const subtitle = $("#bcSubtitle");
        if (!state?.loggedIn) {
            bar.hidden = true;
            subtitle.textContent = "Wallet, links, ranks and chat";
            return;
        }
        const p = state.progress;
        subtitle.textContent = `${state.profile.publicName}${state.profile.rank ? ` · #${state.profile.rank}` : ""}`;
        bar.hidden = false;
        bar.innerHTML = `
            <div class="bc-level-badge"><span>LV</span><strong>${p.level}</strong></div>
            <div class="bc-level-main">
                <div class="bc-level-row"><strong>${esc(p.title)}</strong><span>${num(p.xp)} XP</span></div>
                <div class="bc-meter" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${p.progressPercent}"><i style="width:${p.progressPercent}%"></i></div>
                <div class="bc-level-row bc-small"><span>${p.progressXp}/${p.progressNeeded} XP to level ${p.level + 1}</span><span>🔥 ${state.streakDays}d · ⚡ +${state.todayXp} today</span></div>
            </div>
            <div class="bc-credits" title="Promoter credits">🪙 <strong>${state.credits === null ? "–" : num(state.credits)}</strong><span>credits</span></div>`;
    }

    function loggedOutCard(context) {
        return `
            <div class="bc-card bc-signin">
                <div class="bc-signin-icon">👥</div>
                <h3>Join the community</h3>
                <p>${esc(context)}</p>
                <ul class="bc-bullets">
                    <li>🔗 Share your casino referral links — they rotate fairly on homepage PLAY clicks</li>
                    <li>⭐ Earn XP for new verified merchants, chat and verified new members you invite</li>
                    <li>🪙 ${esc(levelBandSentence())}</li>
                </ul>
                <a class="bc-btn bc-btn-primary bc-btn-block" href="bonus-fetch.php">Sign in with Bonus Fetcher</a>
                <small>Use your existing Bonus Fetcher phone number and password.</small>
            </div>`;
    }

    function profileSetupCard() {
        return `
            <form class="bc-card bc-profile-setup" data-bc-form="profile">
                <h3>👋 Pick your chat username</h3>
                <p>Shown on the leaderboard and in chat. You need one to earn XP.</p>
                <div class="bc-inline">
                    <input name="displayName" maxlength="24" minlength="2" required placeholder="Username" autocomplete="nickname" value="${esc(state.profile.displayName)}">
                    <button class="bc-btn bc-btn-primary" type="submit">Save</button>
                </div>
            </form>`;
    }

    function statGrid(items) {
        return `<div class="bc-stats">${items.map(([value, label]) => `<div class="bc-stat"><strong>${value}</strong><span>${esc(label)}</span></div>`).join("")}</div>`;
    }

    function communityStats() {
        const c = state.community || {};
        return `
            <div class="bc-card">
                <h3 class="bc-card-title">🌏 Community today</h3>
                ${statGrid([
                    [num(c.members), "members"],
                    [num(c.sharers), "sharing links"],
                    [num(c.casinosCovered), "domains shared"],
                    [num(c.communityPlaysToday), "community plays today"],
                    [num(c.chatToday), "chat messages today"],
                    [num(c.xpToday), "XP earned today"],
                ])}
            </div>`;
    }

    /* ---------- HOME ---------- */

    function renderHome() {
        const panel = $('[data-bc-panel="home"]');
        if (!state.loggedIn) {
            panel.innerHTML = loggedOutCard("Sign in to add your links, earn XP and unlock level rewards.") + xpRulesCard() + communityStats() + feedCard();
            loadFeed();
            return;
        }
        const r = state.rewards;
        const p = state.progress;
        const weekly = state.weeklyCreditClaim || {credits: 20, claimed: false, eligible: true};
        const weeklyCredits = num(weekly.credits || 20);
        const weeklyLocked = !weekly.claimed && weekly.eligible === false;
        const weeklyMinDays = weekly.minAccountAgeDays || 7;
        const weeklyDaysToGo = Math.max(1, Number(weekly.daysToGo) || weeklyMinDays);
        const weeklyUnlockText = weekly.eligibleAt
            ? new Date(weekly.eligibleAt * 1000).toLocaleString("en-AU", {weekday: "long", day: "numeric", month: "short", hour: "numeric", minute: "2-digit"})
            : "";
        const weeklyResetText = weekly.nextResetAt
            ? new Date(weekly.nextResetAt * 1000).toLocaleString("en-AU", {weekday: "long", day: "numeric", month: "short", hour: "numeric", minute: "2-digit"})
            : "Monday";
        const earned = r.earned.filter(item => item.status === "credited");
        const pending = r.earned.filter(item => item.status !== "credited");
        panel.innerHTML = `
            <div class="bc-card">
                <h3 class="bc-card-title">🎁 Weekly free credits</h3>
                <p class="bc-small bc-muted">Claim ${weeklyCredits} free credits once each week. Claims reset every Monday. New accounts can claim ${weeklyMinDays} days after joining.</p>
                <button type="button" class="bc-btn bc-btn-block" data-bc-action="claimWeeklyCredits" ${weekly.claimed || weeklyClaiming || weeklyLocked ? "disabled" : ""}>
                    ${weeklyClaiming ? "Adding credits…" : weekly.claimed ? "✓ Claimed this week" : weeklyLocked ? `🔒 Unlocks in ${weeklyDaysToGo} day${weeklyDaysToGo === 1 ? "" : "s"}` : `Claim ${weeklyCredits} weekly credits`}
                </button>
                ${weekly.claimed ? `<p class="bc-small bc-muted">Your next claim is available ${esc(weeklyResetText)}.</p>` : ""}
                ${weeklyLocked ? `<p class="bc-small bc-muted">Weekly credits unlock ${weeklyMinDays} days after you join — ${weeklyDaysToGo} day${weeklyDaysToGo === 1 ? "" : "s"} to go${weeklyUnlockText ? ` (${esc(weeklyUnlockText)})` : ""}.</p>` : ""}
            </div>
            ${!state.profile.exists || !state.profile.displayName ? profileSetupCard() : (state.profile.memberId ? `<button type="button" class="bc-btn bc-btn-block" data-bc-action="myProfile">Customize profile</button>` : "")}
            <button type="button" class="bc-wallet-jump" data-bc-go="wallet">
                <span><small>Credits</small><strong>${state.credits === null ? "–" : num(state.credits)}</strong></span>
                <span><small>XP</small><strong>${num(p.xp)}</strong></span>
                <span><small>Level ${p.level}</small><strong>${esc(p.title)}</strong></span>
                <em>Wallet</em>
            </button>
            <div class="bc-card">
                <h3 class="bc-card-title">🎯 Daily missions <small>resets midnight Melbourne</small></h3>
                <div class="bc-missions">
                    ${state.missions.map(m => {
                        const pct = m.goal ? Math.min(100, Math.round(m.done * 100 / m.goal)) : (m.done ? 100 : 0);
                        const done = m.goal ? m.done >= m.goal : false;
                        return `<div class="bc-mission${done ? " bc-done" : ""}">
                            <span class="bc-mission-icon">${m.icon}</span>
                            <div class="bc-mission-main">
                                <div class="bc-level-row"><span>${esc(m.label)}</span><strong>${m.goal ? `${m.done}/${m.goal}` : m.done}</strong></div>
                                <div class="bc-meter bc-meter-thin"><i style="width:${pct}%"></i></div>
                            </div>
                            <span class="bc-xp-pill">+${m.xpEach} XP${m.goal ? " each" : ""}</span>
                        </div>`;
                    }).join("")}
                </div>
            </div>
            <div class="bc-card">
                <h3 class="bc-card-title">🏅 Levels &amp; rewards</h3>
                <div class="bc-reward-next">
                    <div><span class="bc-muted">Next reward</span><strong>Level ${r.next.level} → +${r.next.credits} credits</strong></div>
                    <div class="bc-xp-pill">${r.next.xpToGo} XP to go</div>
                </div>
                ${p.nextTitle ? `<p class="bc-muted bc-small">Next title: <strong>${esc(p.nextTitle.title)}</strong> at level ${p.nextTitle.level}</p>` : ""}
                <div class="bc-reward-track">
                    ${Array.from({length: 6}, (_, i) => p.level - 1 + i).filter(l => l >= 2).slice(0, 5).map(level => {
                        const got = r.earned.find(item => item.level === level);
                        const cls = got?.status === "credited" ? "bc-got" : (got ? "bc-pending" : (level <= p.level ? "bc-got" : ""));
                        const shown = got?.status === "credited" ? got.credits : levelPay(level);
                        return `<div class="bc-milestone ${cls}"><strong>Lv ${level}</strong><span>${got?.status === "credited" ? "✓ " : ""}+${shown}</span></div>`;
                    }).join("")}
                </div>
                <p class="bc-small bc-muted">Earned so far: <strong>${num(r.creditedTotal)} credits</strong> from ${earned.length} level reward${earned.length === 1 ? "" : "s"}${pending.length ? ` · ${pending.length} being credited` : ""}.</p>
            </div>
            <div class="bc-card">
                <h3 class="bc-card-title">🏆 Achievements</h3>
                <div class="bc-achievements">
                    ${state.achievements.map(a => `<div class="bc-ach${a.done ? " bc-done" : ""}" title="${esc(a.desc)}">
                        <span class="bc-ach-icon">${a.icon}</span><strong>${esc(a.name)}</strong>
                        <span>${a.done ? "Unlocked" : `${num(a.have)}/${num(a.need)}`}</span></div>`).join("")}
                </div>
            </div>
            <div class="bc-card">
                <h3 class="bc-card-title">⚡ Recent XP</h3>
                ${state.recent.length ? `<ul class="bc-list">${state.recent.map(e => `<li><span>${e.icon} ${esc(e.label)}${e.clickUrl ? ` <a href="${esc(e.clickUrl)}" target="_blank" rel="noopener noreferrer" style="overflow-wrap:anywhere">${esc(e.clickUrl)}</a>` : ""}</span><span class="bc-muted bc-small">${timeAgo(e.ts)}</span><strong class="bc-plus">+${e.xp}</strong></li>`).join("")}</ul>` : `<div class="bc-empty">No XP yet — add a link or say hi in chat.</div>`}
            </div>
            ${xpRulesCard()}
            ${communityStats()}
            ${feedCard()}`;
        loadFeed();
    }

    function xpRulesCard() {
        const r = state.rules;
        return `
            <details class="bc-card bc-rules">
                <summary><h3 class="bc-card-title">❔ How XP works</h3></summary>
                <ul class="bc-list bc-rules-list">
                    <li><span>🔗 Link for a <b>new verified merchant</b></span><strong>+${r.merchantXp}</strong></li>
                    <li><span>💬 Chat message over ${r.chatMinChars ?? 15} characters with ${r.chatMinWords ?? 3}+ words (max ${r.chatDaily}/day)</span><strong>+${r.chatXp}</strong></li>
                    ${r.replyXp ? `<li><span>↩️ Someone replies to your message (max ${r.replyDaily}/day)</span><strong>+${r.replyXp}</strong></li>` : ""}
                    <li><span>🎉 Verified new member from your share link (max ${r.shareDaily}/day)</span><strong>+${r.referralXp}</strong></li>
                    <li><span>👆 Visitor sent to your link (max ${r.serveDaily}/day)</span><strong>+${r.serveXp}</strong></li>
                    <li><span>🏅 Share milestones: ${r.shareMilestones.map(m => `${m.referrals} referrals +${m.xp}`).join(" · ")}</span><strong></strong></li>
                </ul>
                <p class="bc-small bc-muted">Max ${r.merchantDaily} merchant rewards per day. Alias domains of a merchant you already have, unverified links and plain page visits don't earn XP. Every ${r.levelXp} XP is a new level. ${esc(levelBandSentence(r))}</p>
            </details>`;
    }

    function feedCard() {
        return `<div class="bc-card"><h3 class="bc-card-title">📰 Community feed</h3><div data-bc-feed><div class="bc-loading">Loading…</div></div></div>`;
    }

    async function loadFeed(force = false) {
        const hosts = drawer.querySelectorAll("[data-bc-feed]");
        if (!hosts.length) return;
        try {
            if (force || !loadFeed.cache || Date.now() - feedLoadedAt > 30000) {
                loadFeed.cache = await post(COMMUNITY_API, {action: "feed"});
                feedLoadedAt = Date.now();
            }
            const items = loadFeed.cache.items || [];
            const html = items.length ? `<ul class="bc-list bc-feed">${items.map(item => item.type === "share"
                ? `<li><span>🔗 ${memberLink(item.memberId, item.who)} shared <button type="button" class="bc-linkish" data-bc-action="findCasino" data-domain="${esc(item.domain)}">${esc(item.domain)}</button></span><span class="bc-muted bc-small">${timeAgo(item.ts)}</span></li>`
                : `<li><span>🏆 ${memberLink(item.memberId, item.who)} reached level ${item.level}</span><span class="bc-muted bc-small">${timeAgo(item.ts)}</span></li>`).join("")}</ul>` : `<div class="bc-empty">Nothing yet.</div>`;
            hosts.forEach(host => { host.innerHTML = html; });
        } catch (error) {
            hosts.forEach(host => { host.innerHTML = `<div class="bc-empty">Feed unavailable.</div>`; });
        }
    }

    /* ---------- WALLET & PROGRESS ---------- */

    async function renderWallet(force = false) {
        const panel = $('[data-bc-panel="wallet"]');
        if (!state?.loggedIn) {
            panel.innerHTML = loggedOutCard("Sign in to see your credits, level progress, promotions and purchase history.");
            return;
        }
        if (!force && walletView && Date.now() - walletLoadedAt < 15000) {
            paintWallet(panel);
            return;
        }
        panel.innerHTML = `<div class="bc-loading">Loading wallet…</div>`;
        try {
            walletView = await loadWalletView();
            walletLoadedAt = Date.now();
            if (activeTab === "wallet") paintWallet(panel);
        } catch (error) {
            panel.innerHTML = `<div class="bc-empty">⚠️ ${esc(error.message || "Wallet is unavailable right now.")}<br><button type="button" class="bc-btn" data-bc-action="retry">Try again</button></div>`;
        }
    }

    async function loadWalletView(body) {
        const response = await fetch("wallet.php?format=json", {
            method: body ? "POST" : "GET",
            credentials: "same-origin",
            cache: "no-store",
            body: body || null
        });
        const text = await response.text();
        let data;
        try { data = JSON.parse(text); } catch { data = null; }
        if (!data || data.ok === false) {
            throw new Error(data?.error || "Sign in again to open your wallet.");
        }
        return data;
    }

    function walletSelect(name, options, placeholder) {
        if (!options.length) return `<p class="bc-small bc-muted">Add a verified community link before buying.</p>`;
        return `<label class="bc-field">${esc(placeholder)}<select name="${esc(name)}">${options.map(opt => `<option value="${esc(opt.id ?? opt)}">${esc(opt.label ?? opt)}</option>`).join("")}</select></label>`;
    }

    function paintWallet(panel) {
        const data = walletView;
        if (!data || !panel) return;
        const progress = data.progress || {};
        const economy = data.economy || {};
        const into = Math.max(0, Math.min(100, Number(economy.intoLevel) || 0));
        const rows = (data.transactions || []).filter(row => walletFilter === "all" || row.kind === walletFilter);
        const domains = data.domains || [];
        const domainOptions = domains.map(domain => ({id: domain, label: domain}));
        const boosts = data.boosts || [];
        const promos = data.promos || [];
        const review = data.review;
        const packageName = id => {
            const found = [...(data.boostPackages || []), ...(data.promoPackages || [])].find(item => item.id === id);
            return found ? found.label : id;
        };
        const promoLeft = seconds => {
            const s = Math.max(0, Number(seconds) || 0);
            if (s < 3600) return `${Math.max(1, Math.floor(s / 60))}m left`;
            if (s < 86400) return `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m left`;
            return `${Math.floor(s / 86400)}d ${Math.floor((s % 86400) / 3600)}h left`;
        };
        const promoChoices = data.promoChoices || [];
        const promoManage = row => {
            const mins = Math.max(1, Math.ceil((Number(row.refundSecondsLeft) || 0) / 60));
            const cancelMsg = row.refundable
                ? `Cancel the promotion for ${row.domain}?\n\nYou bought it less than 2 hours ago, so you get a full refund: ${row.refundAmount} credits back to your wallet. (Refund window closes in about ${mins} min.)`
                : `Cancel the promotion for ${row.domain}?\n\nIt was bought more than 2 hours ago, so there is NO refund: the ${row.credits} credits are not returned. The card leaves Promoted now.`;
            const left = Number(row.changesLeft) || 0;
            const choices = promoChoices.filter(d => d !== row.domain);
            return `<div style="flex-basis:100%;display:grid;gap:6px;margin-top:6px">
                <form data-bc-form="wallet" data-bc-confirm="${esc(cancelMsg)}">
                    <input type="hidden" name="token" value="${esc(data.token)}">
                    <input type="hidden" name="format" value="json">
                    <input type="hidden" name="action" value="promo_cancel">
                    <input type="hidden" name="promotionId" value="${esc(row.id)}">
                    <input type="hidden" name="expectRefund" value="${row.refundable ? "1" : "0"}">
                    <button class="bc-btn bc-btn-block" type="submit" style="margin-top:0;border-color:#fb718566;color:#fecdd3">${row.refundable ? `Cancel · refund ${num(row.refundAmount)} credits` : "Cancel promotion (no refund)"}</button>
                </form>
                ${left > 0 ? (choices.length ? `<form data-bc-form="wallet" data-bc-confirm="Move this promotion from ${esc(row.domain)} to {newDomain}?\n\nFree. It keeps the same end time. ${left - 1} change${left - 1 === 1 ? "" : "s"} left after this.">
                    <input type="hidden" name="token" value="${esc(data.token)}">
                    <input type="hidden" name="format" value="json">
                    <input type="hidden" name="action" value="promo_change">
                    <input type="hidden" name="promotionId" value="${esc(row.id)}">
                    <div class="bc-inline"><select name="newDomain" aria-label="New card" style="flex:1;min-width:0;padding:9px 11px;border-radius:10px;border:1px solid #ffffff1f;background:#0a0c12;color:var(--bc-text,#e8eaf2);font-size:16px">${choices.map(d => `<option value="${esc(d)}">${esc(d)}</option>`).join("")}</select><button class="bc-btn" type="submit">Change card</button></div>
                    <small class="bc-muted">Free · keeps the end time · ${num(left)} of ${num(data.promoRules?.maxChanges || 3)} changes left</small>
                </form>` : `<small class="bc-muted">Change card: none of your other casinos are free to promote right now.</small>`) : `<small class="bc-muted">All card changes used for this promotion.</small>`}
            </div>`;
        };
        const boostChoices = data.boostChoices || [];
        const boostManage = row => {
            const left = Math.max(0, Number(row.remaining) || 0);
            const refund = Number(row.refundAmount) || 0;
            const cancelMsg = `Cancel the Link Boost for ${row.domain}?\n\n${num(row.delivered)} of ${num(row.purchased)} deliveries are done. The ${num(left)} undelivered ${left === 1 ? "delivery is" : "deliveries are"} refunded: ${num(refund)} of ${num(row.credits)} credits back to your wallet.\n\nThis frees the slot so you can boost another casino.`;
            const choices = boostChoices.filter(d => d !== row.domain);
            return `<div style="flex-basis:100%;display:grid;gap:6px;margin-top:6px">
                <form data-bc-form="wallet" data-bc-confirm="${esc(cancelMsg)}">
                    <input type="hidden" name="token" value="${esc(data.token)}">
                    <input type="hidden" name="format" value="json">
                    <input type="hidden" name="action" value="boost_cancel">
                    <input type="hidden" name="boostId" value="${esc(row.id)}">
                    <input type="hidden" name="expectRefund" value="${esc(refund)}">
                    <button class="bc-btn bc-btn-block" type="submit" style="margin-top:0;border-color:#fb718566;color:#fecdd3">Cancel · refund ${num(refund)} credits</button>
                </form>
                ${choices.length ? `<form data-bc-form="wallet" data-bc-confirm="Move the ${num(left)} undelivered boosted ${left === 1 ? "delivery" : "deliveries"} from ${esc(row.domain)} to {newDomain}?\n\nFree. Deliveries already made stay counted.">
                    <input type="hidden" name="token" value="${esc(data.token)}">
                    <input type="hidden" name="format" value="json">
                    <input type="hidden" name="action" value="boost_change">
                    <input type="hidden" name="boostId" value="${esc(row.id)}">
                    <div class="bc-inline"><select name="newDomain" aria-label="New casino" style="flex:1;min-width:0;padding:9px 11px;border-radius:10px;border:1px solid #ffffff1f;background:#0a0c12;color:var(--bc-text,#e8eaf2);font-size:16px">${choices.map(d => `<option value="${esc(d)}">${esc(d)}</option>`).join("")}</select><button class="bc-btn" type="submit">Change site</button></div>
                    <small class="bc-muted">Free · moves the ${num(left)} undelivered ${left === 1 ? "delivery" : "deliveries"} to another of your casinos</small>
                </form>` : `<small class="bc-muted">Change site: none of your other casinos can take this boost right now.</small>`}
            </div>`;
        };
        const boostRow = row => `<li style="flex-wrap:wrap"><span><b>${esc(row.domain)}</b><small class="bc-muted">${esc(packageName(row.package))} · ${num(row.credits)} credits · ${num(row.delivered)}/${num(row.purchased)} delivered · ${esc(row.status)}${row.refunded ? ` · ${num(row.refunded)} credits refunded` : ""}</small></span>${row.manageable ? boostManage(row) : ""}</li>`;
        const livePromos = promos.filter(row => row.manageable);
        const promoRow = row => `<li style="flex-wrap:wrap"><span><b>${esc(row.domain)}</b><small class="bc-muted">${num(row.credits)} credits · ${num(row.durationHours)} hours · ${esc(row.statusLabel || row.status)}${row.queuePosition ? ` · queue ${num(row.queuePosition)}` : ""}${row.status === "active" && row.remainingSeconds ? ` · ${esc(promoLeft(row.remainingSeconds))}` : ""}${row.refunded ? ` · ${num(row.refunded)} credits refunded` : ""}</small></span>${row.manageable ? promoManage(row) : ""}</li>`;
        panel.innerHTML = `
            ${data.notice ? `<div class="bc-result bc-ok">${esc(data.notice)}</div>` : ""}
            ${data.error ? `<div class="bc-result bc-bad">${esc(data.error)}${livePromos.length && /promotion (running|in progress)/i.test(data.error) ? `<br><button type="button" class="bc-btn" style="margin-top:8px" data-bc-action="managePromos">Manage my promotion ↓</button>` : ""}${/two casinos at a time/i.test(data.error) ? `<br><button type="button" class="bc-btn" style="margin-top:8px" data-bc-action="manageBoosts">Manage my link boosts ↓</button>` : ""}</div>` : ""}
            ${livePromos.length ? `<div class="bc-card" id="bc-my-promos" style="border-color:#8b6bff66">
                <h3 class="bc-card-title">My promotions</h3>
                <p class="bc-small bc-muted">Cancel within 2 hours of buying for a full refund; after that, Cancel ends it with no refund. Change card is free and keeps the end time.</p>
                <ul class="bc-list">${livePromos.map(promoRow).join("")}</ul>
            </div>` : ""}
            <div class="bc-wallet-hero">
                <div class="bc-wallet-stat"><span>Credits</span><strong>${num(data.balance)}</strong></div>
                <div class="bc-wallet-stat"><span>XP</span><strong>${num(data.xp)}</strong></div>
                <div class="bc-wallet-stat"><span>Level ${num(progress.level)}</span><strong>${esc(progress.title || "Member")}</strong></div>
                <div class="bc-wallet-stat"><span>Until level ${num((Number(progress.level) || 1) + 1)}</span><strong>${num(economy.xpToNext)} XP</strong></div>
                <div class="bc-meter bc-wallet-meter" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${into}"><i style="width:${into}%"></i></div>
            </div>
            ${review ? `<div class="bc-card bc-review">
                <h3 class="bc-card-title">Confirm purchase</h3>
                <p>${esc(review.domain)} · ${esc(review.label)}</p>
                <div class="bc-line"><span>Cost</span><strong>${num(review.cost)} credits</strong></div>
                <div class="bc-line"><span>Balance</span><strong>${num(review.balance)}</strong></div>
                <div class="bc-line"><span>After purchase</span><strong>${num(review.remaining)}</strong></div>
                ${review.willQueue ? `<p class="bc-small">All promoted places are full. This joins the queue at position ${num(review.queuePosition)}. The timer starts only when the card is visible.</p>` : ""}
                ${Number(review.short) > 0
                    ? `<p class="bc-result bc-bad">Need ${num(review.short)} more credits.</p>`
                    : `<form data-bc-form="wallet">
                        <input type="hidden" name="token" value="${esc(data.token)}">
                        <input type="hidden" name="format" value="json">
                        <input type="hidden" name="action" value="confirm">
                        <input type="hidden" name="product" value="${esc(review.product)}">
                        <input type="hidden" name="package" value="${esc(review.package)}">
                        <input type="hidden" name="domain" value="${esc(review.domain)}">
                        <input type="hidden" name="purchaseId" value="${esc(review.purchaseId)}">
                        ${review.willQueue ? `<input type="hidden" name="acknowledgeQueue" value="1">` : ""}
                        <button class="bc-btn bc-btn-primary bc-btn-block" type="submit">Confirm purchase</button>
                    </form>`}
            </div>` : ""}
            <form class="bc-card" data-bc-form="wallet">
                <h3 class="bc-card-title">Buy a link boost</h3>
                <p class="bc-explain">A Link Boost buys extra times your referral link is the one a visitor gets on that casino. It does not skip the fair queue, and it does not take other members' turns. You can boost two casinos at once. A second package on the same casino will not stack. To free a slot, use Cancel (undelivered deliveries are refunded) or Change site on a boost in My promotions.</p>
                <input type="hidden" name="token" value="${esc(data.token)}">
                <input type="hidden" name="format" value="json">
                <input type="hidden" name="action" value="review">
                <input type="hidden" name="product" value="boost">
                ${walletSelect("domain", domainOptions, "Casino")}
                ${domains.length ? walletSelect("package", (data.boostPackages || []).map(item => ({id: item.id, label: `${item.credits} credits · ${item.label}`})), "Package") : ""}
                ${domains.length ? `<button class="bc-btn bc-btn-primary bc-btn-block" type="submit">Review link boost</button>` : ""}
            </form>
            ${livePromos.length ? `<div class="bc-card">
                <h3 class="bc-card-title">Promote a card</h3>
                <p class="bc-explain">You already have a promotion running (one promoted card at a time). Manage it in <b>My promotions</b> at the top: cancel it, or change which card it promotes.</p>
                <button type="button" class="bc-btn bc-btn-block" data-bc-action="managePromos">Manage my promotion ↑</button>
            </div>` : `<form class="bc-card" data-bc-form="wallet">
                <h3 class="bc-card-title">Promote a card</h3>
                <p class="bc-explain">Promoting a card puts that casino in the Promoted row for the time you buy, with a label so people can see it is promoted. Clicks on your promoted card go to your own referral link for that casino (the casino's normal card still shares clicks fairly). If your link is off or broken, those clicks fall back to the normal fair rotation. One promoted card at a time. If all 9 places are full, you join a queue and the timer starts only when the card is on screen.</p>
                <input type="hidden" name="token" value="${esc(data.token)}">
                <input type="hidden" name="format" value="json">
                <input type="hidden" name="action" value="review">
                <input type="hidden" name="product" value="promo">
                ${walletSelect("domain", domainOptions, "Casino")}
                ${domains.length ? walletSelect("package", (data.promoPackages || []).map(item => ({id: item.id, label: `${item.credits} credits · ${item.label}`})), "Package") : ""}
                ${domains.length ? `<button class="bc-btn bc-btn-primary bc-btn-block" type="submit">Review promotion</button>` : ""}
            </form>`}
            <div class="bc-card">
                <h3 class="bc-card-title">Progress</h3>
                <p class="bc-small">Level ${num(economy.level)} · ${num(economy.xp)} XP · ${esc(progress.title || "")}</p>
                <h4 class="bc-subhead">Earned achievements</h4>
                ${(economy.earned || []).length ? `<ul class="bc-list">${economy.earned.map(item => `<li><span>${esc(item.name)}</span><strong class="bc-plus">+${num(item.xp)} XP${item.credits ? ` · +${num(item.credits)}` : ""}</strong></li>`).join("")}</ul>` : `<p class="bc-small bc-muted">None yet. New achievements count from today onward.</p>`}
                <h4 class="bc-subhead">Next achievements</h4>
                <ul class="bc-list">${(economy.next || []).map(item => `<li><span>${esc(item.name)}</span><strong>+${num(item.xp)} XP${item.credits ? ` · +${num(item.credits)}` : ""}</strong></li>`).join("")}</ul>
                <h4 class="bc-subhead">Level perks</h4>
                <ul class="bc-perks">${(economy.perks || []).map(perk => `<li class="${perk.have ? "bc-perk-on" : ""}"><b>${perk.have ? "Unlocked" : `Level ${num(perk.level)}`}</b><span>${esc(perk.name)}${perk.note ? ` · ${esc(perk.note)}` : ""}</span></li>`).join("")}</ul>
            </div>
            <div class="bc-card">
                <h3 class="bc-card-title">My promotions</h3>
                <h4 class="bc-subhead" id="bc-my-boosts">Link boosts</h4>
                ${boosts.length ? `<ul class="bc-list">${boosts.map(boostRow).join("")}</ul>` : `<p class="bc-small bc-muted">No Link Boosts yet. A boost adds extra referral turns. It does not skip the fair queue.</p>`}
                <h4 class="bc-subhead">Card promotions</h4>
                ${promos.length ? `<ul class="bc-list">${promos.map(row => row.manageable ? `<li><span><b>${esc(row.domain)}</b><small class="bc-muted">${esc(row.statusLabel || row.status)} · manage it at the top</small></span><button type="button" class="bc-btn" data-bc-action="managePromos">Manage ↑</button></li>` : promoRow(row)).join("")}</ul>` : `<p class="bc-small bc-muted">No promoted cards yet. A promoted card is labelled, and clicks on it go to your own referral link for that casino.</p>`}
            </div>
            <div class="bc-card">
                <div class="bc-card-title-row"><h3 class="bc-card-title">Credit history</h3></div>
                <div class="bc-seg bc-wallet-filters" role="tablist">
                    ${["all", "earned", "spent", "refunded"].map(kind => `<button type="button" class="bc-seg-btn${walletFilter === kind ? " bc-seg-on" : ""}" data-bc-action="walletFilter" data-kind="${kind}">${kind[0].toUpperCase()}${kind.slice(1)}</button>`).join("")}
                </div>
                ${rows.length ? `<ul class="bc-tx">${rows.map(row => `<li class="bc-tx-${esc(row.kind || "earned")}"><strong>${esc(row.label)}</strong><time>${esc(row.when)}</time></li>`).join("")}</ul>` : `<div class="bc-empty">No ${walletFilter === "all" ? "" : walletFilter + " "}credit transactions yet.</div>`}
            </div>`;
    }

    async function submitWallet(form) {
        if (form.dataset.bcConfirm) {
            const select = form.querySelector("select[name=newDomain]");
            const message = form.dataset.bcConfirm.replace("{newDomain}", select ? select.value : "");
            if (!window.confirm(message)) return;
        }
        const button = form.querySelector("button[type=submit]");
        if (button) button.disabled = true;
        try {
            walletView = await loadWalletView(new FormData(form));
            walletLoadedAt = Date.now();
            const panel = $('[data-bc-panel="wallet"]');
            if (panel) paintWallet(panel);
            if (walletView.notice) toast(walletView.notice, "ok");
            else if (walletView.error) toast(walletView.error, "bad");
            loadState(true).then(renderLevelBar).catch(() => {});
        } catch (error) {
            toast(error.message, "bad");
            if (button) button.disabled = false;
        }
    }

    /* ---------- LINKS ---------- */

    function bulkOwnerId() {
        return state?.loggedIn ? "authenticated" : "";
    }

    function validBulkImportId(value) {
        return /^[a-f0-9]{32}$/.test(String(value || ""));
    }

    function bulkStorageKey() {
        return BULK_STORAGE_KEY;
    }

    function readStoredBulkImport(owner) {
        if (!owner) return "";
        try {
            const saved = JSON.parse(localStorage.getItem(bulkStorageKey(owner)) || "null");
            return saved?.owner === owner && validBulkImportId(saved?.importId) ? saved.importId : "";
        } catch {
            return "";
        }
    }

    function storeBulkImport() {
        const key = bulkStorageKey();
        if (!key || !validBulkImportId(bulkImport.id)) return;
        try {
            localStorage.setItem(key, JSON.stringify({owner: bulkImport.owner, importId: bulkImport.id}));
        } catch { /* Polling still works for this page if storage is unavailable. */ }
    }

    function clearStoredBulkImport() {
        try {
            localStorage.removeItem(bulkStorageKey());
        } catch { /* A stale key is harmless because the server enforces ownership. */ }
    }

    function stopBulkPolling() {
        if (bulkImport.timer) clearTimeout(bulkImport.timer);
        bulkImport.timer = null;
        bulkImport.polling = false;
    }

    function syncBulkImportOwner() {
        const owner = bulkOwnerId();
        if (owner === bulkImport.owner) {
            if (owner && bulkImport.id) scheduleBulkPoll(0);
            return;
        }
        stopBulkPolling();
        bulkImport = {
            owner,
            id: readStoredBulkImport(owner),
            snapshot: null,
            startPending: false,
            polling: false,
            timer: null,
            networkError: "",
            refreshedId: "",
        };
        if (bulkImport.id) scheduleBulkPoll(0);
    }

    function bulkStatusValue(data) {
        const source = data?.import || data?.job || data || {};
        if (source.done === true && !source.status && !source.state) return source.ok === false ? "failed" : "complete";
        return String(source.status || source.state || data?.status || data?.state || "running").toLowerCase().replace(/[\s-]+/g, "_");
    }

    function normaliseBulkSnapshot(data, previousItems = []) {
        const source = data?.import || data?.job || data || {};
        const incomingItems = source.items || source.results || data?.items || data?.results || [];
        const items = Array.isArray(incomingItems) && incomingItems.length ? incomingItems : previousItems;
        const status = bulkStatusValue(data);
        const derivedProcessed = Array.isArray(items)
            ? items.filter(item => !["", "pending", "queued", "starting", "running", "verifying", "processing", "applying", "in_progress"].includes(bulkItemState(item))).length
            : 0;
        const processedValue = source.processed ?? source.completedCount ?? data?.processed ?? derivedProcessed;
        const totalValue = source.total ?? source.itemCount ?? data?.total;
        return {
            status,
            items: Array.isArray(items) ? items : [],
            processed: Number(processedValue ?? 0),
            total: Number(totalValue ?? (Array.isArray(items) ? items.length : 0)),
            counts: source.counts || data?.counts || {},
            reason: String(source.reason || source.error || source.message || data?.error || data?.message || ""),
        };
    }

    function bulkIsTerminal(snapshot = bulkImport.snapshot) {
        return !!snapshot && BULK_TERMINAL_STATES.has(snapshot.status);
    }

    function bulkIsActive() {
        if (bulkImport.startPending) return true;
        if (!bulkImport.id) return false;
        if (!bulkImport.snapshot) return true;
        return BULK_ACTIVE_STATES.has(bulkImport.snapshot.status) || !bulkIsTerminal(bulkImport.snapshot);
    }

    function bulkItemState(item) {
        let status = String(item?.status || item?.state || "").toLowerCase().replace(/[\s-]+/g, "_");
        if (!status && item?.ok === true) status = "success";
        if (!status && item?.ok === false) status = "failed";
        return status || "pending";
    }

    function bulkItemLabel(item, index) {
        return String(item?.referlink || item?.url || item?.input || item?.value || item?.domain || `Item ${index + 1}`);
    }

    function bulkItemReason(item) {
        const code = String(item?.reason || "");
        const detail = String(item?.error || item?.message || item?.detail || "");
        return code && detail && code !== detail
            ? `${code.replace(/_/g, " ")} — ${detail}`
            : (detail || code.replace(/_/g, " "));
    }

    function bulkCountsHtml(counts) {
        if (!counts || typeof counts !== "object") return "";
        const labels = {added: "added", updated: "updated", enabled: "re-enabled", duplicate: "duplicates", failed: "failed", pending: "pending"};
        const parts = Object.entries(counts)
            .filter(([, value]) => Number.isFinite(Number(value)))
            .map(([key, value]) => `${esc(labels[key] || key)} ${num(value)}`);
        return parts.length ? `<p class="bc-bulk-counts">${parts.join(" · ")}</p>` : "";
    }

    function renderBulkImport() {
        const form = $("[data-bc-form=addlink]");
        if (!form) return;
        const button = form.querySelector("button[type=submit]");
        const textarea = form.elements.links;
        const result = form.querySelector("[data-bc-add-result]");
        const active = bulkIsActive();
        button.disabled = active;
        textarea.disabled = active;
        button.textContent = bulkImport.startPending ? "Starting import…" : (active ? "Import in progress…" : "Add link");

        if (!bulkImport.id && !bulkImport.startPending) return;
        if (bulkImport.startPending) {
            result.innerHTML = `<div class="bc-bulk"><p class="bc-bulk-summary" role="status" aria-live="polite">Starting bulk import…</p></div>`;
            return;
        }

        const snapshot = bulkImport.snapshot;
        const status = snapshot?.status || "running";
        const total = snapshot?.total || snapshot?.items?.length || 0;
        const processed = Math.min(total || Number.MAX_SAFE_INTEGER, snapshot?.processed || 0);
        const percent = total ? Math.max(0, Math.min(100, Math.round(processed * 100 / total))) : 0;
        const failed = ["failed", "error", "cancelled", "canceled"].includes(status);
        const complete = bulkIsTerminal(snapshot) && !failed;
        const summary = failed
            ? `Import ${status}.`
            : (complete ? `Import complete · ${processed || total}/${total || processed} processed.` : `Importing links · ${processed}/${total || "…"} processed.`);
        const items = snapshot?.items || [];
        const rows = items.map((item, index) => {
            const itemStatus = bulkItemState(item);
            const itemFailed = ["failed", "error", "invalid", "rejected"].includes(itemStatus) || item?.ok === false;
            const itemDone = item?.ok === true || ["added", "updated", "enabled", "duplicate", "review", "success", "succeeded", "complete", "completed", "done"].includes(itemStatus);
            const reason = bulkItemReason(item);
            return `<li class="${itemFailed ? "bc-bulk-failed" : (itemDone ? "bc-bulk-done" : "bc-bulk-pending")}">
                <div class="bc-bulk-item-head"><span>${esc(bulkItemLabel(item, index))}</span><strong>${esc(itemStatus.replace(/_/g, " "))}</strong></div>
                ${reason ? `<p>${esc(reason)}</p>` : ""}
            </li>`;
        }).join("");
        const retry = bulkImport.networkError
            ? `<div class="bc-result bc-warn">Status check failed: ${esc(bulkImport.networkError)} Retrying automatically.<button type="button" class="bc-btn" data-bc-action="retryBulk">Retry now</button></div>`
            : "";
        result.innerHTML = `<div class="bc-bulk ${failed ? "bc-bulk-terminal-failed" : ""}">
            <p class="bc-bulk-summary" role="status" aria-live="polite">${esc(summary)}</p>
            ${!bulkIsTerminal(snapshot) ? `<div class="bc-meter" role="progressbar" aria-label="Bulk link import progress" aria-valuemin="0" aria-valuemax="${total || 100}" aria-valuenow="${processed}"><i style="width:${percent}%"></i></div>` : ""}
            ${bulkCountsHtml(snapshot?.counts)}
            ${snapshot?.reason ? `<div class="bc-result ${failed ? "bc-bad" : "bc-warn"}">${esc(snapshot.reason)}</div>` : ""}
            ${retry}
            ${items.length ? `<ol class="bc-bulk-items" aria-label="Bulk import items">${rows}</ol>` : `<p class="bc-small bc-muted">Waiting for item details…</p>`}
        </div>`;
    }

    function scheduleBulkPoll(delay = BULK_POLL_MS) {
        if (!bulkImport.id || bulkIsTerminal()) return;
        if (bulkImport.timer) clearTimeout(bulkImport.timer);
        bulkImport.timer = setTimeout(pollBulkStatus, delay);
    }

    async function refreshAfterBulkTerminal() {
        if (!bulkIsTerminal() || bulkImport.refreshedId === bulkImport.id) return;
        bulkImport.refreshedId = bulkImport.id;
        clearStoredBulkImport();
        myLinks = null;
        try {
            await Promise.all([loadState(true), loadMyLinks(true)]);
            renderLevelBar();
        } catch { /* The completed import remains visible even if summary refresh fails. */ }
        renderBulkImport();
    }

    async function pollBulkStatus() {
        if (!bulkImport.id || bulkImport.polling || bulkIsTerminal()) return;
        bulkImport.polling = true;
        if (bulkImport.timer) clearTimeout(bulkImport.timer);
        bulkImport.timer = null;
        try {
            const data = await post(LINKS_API, {action: "bulkStatus", importId: bulkImport.id});
            bulkImport.snapshot = normaliseBulkSnapshot(data, bulkImport.snapshot?.items || []);
            bulkImport.networkError = "";
            renderBulkImport();
            if (bulkIsTerminal()) await refreshAfterBulkTerminal();
            else scheduleBulkPoll();
        } catch (error) {
            const retryable = !error.status || error.status >= 500 || error.status === 408 || error.status === 429;
            if (retryable) {
                bulkImport.networkError = error.message || "Network unavailable.";
                renderBulkImport();
                scheduleBulkPoll();
            } else {
                bulkImport.networkError = "";
                clearStoredBulkImport();
                bulkImport.snapshot = {
                    ...(bulkImport.snapshot || {}),
                    status: "failed",
                    reason: error.message || "The import status is unavailable.",
                };
                renderBulkImport();
                await refreshAfterBulkTerminal();
            }
        } finally {
            bulkImport.polling = false;
        }
    }

    function resumeBulkImport() {
        syncBulkImportOwner();
        renderBulkImport();
        if (bulkImport.id && !bulkIsTerminal()) scheduleBulkPoll(0);
    }

    function linksStatsCards() {
        const l = state.links;
        const c = state.community || {};
        return `
            <div class="bc-card" data-bc-links-stats>
                <h3 class="bc-card-title">Your links</h3>
                <p class="bc-unique-total"><strong>${num(l.uniquePlays)}</strong> unique people clicked your links</p>
                <p class="bc-small">Last 7 days: <strong>${num(l.uniquePlays7d)}</strong> unique</p>
                ${statGrid([
                    [num(l.enabled), "active links"],
                    [num(l.casinos), "casinos"],
                    [num(l.total - l.enabled), "disabled"],
                ])}
                <p class="bc-small bc-muted">Your own visits aren't counted.</p>
            </div>
            <div class="bc-card" data-bc-community-stats>
                <h3 class="bc-card-title">Community</h3>
                ${statGrid([
                    [num(c.communityLinks), "links"],
                    [num(c.sharers), "contributors"],
                    [num(c.casinosCovered), "casinos covered"],
                    [num(c.communityPlaysToday), "plays today"],
                ])}
                <p class="bc-small bc-muted">Community numbers are site-wide. They are not your personal click count.</p>
            </div>`;
    }

    function renderLinks() {
        const panel = $('[data-bc-panel="links"]');
        if (!state.loggedIn) { panel.innerHTML = loggedOutCard("Sign in to add your casino referral links."); return; }
        // Keep the add-link textarea mounted. Opening the Links tab always
        // refreshes community state and used to rebuild this whole panel,
        // which on iOS Safari closes the keyboard after the first tap
        // (the field had to be tapped twice). Same idea as renderChatShell().
        // Stats cards still refresh in place so numbers stay current.
        const existingForm = panel.querySelector("[data-bc-form=addlink]");
        if (existingForm) {
            const setup = panel.querySelector(".bc-profile-setup");
            if (state.profile.exists && state.profile.displayName) setup?.remove();
            else if (!setup && (!state.profile.exists || !state.profile.displayName)) {
                panel.insertAdjacentHTML("afterbegin", profileSetupCard());
            }
            const html = linksStatsCards();
            const wrap = document.createElement("div");
            wrap.innerHTML = html;
            const newLinks = wrap.firstElementChild;
            const newComm = newLinks.nextElementSibling;
            const oldLinks = panel.querySelector("[data-bc-links-stats]");
            const oldComm = panel.querySelector("[data-bc-community-stats]");
            if (oldLinks && oldComm) {
                oldLinks.replaceWith(newLinks);
                oldComm.replaceWith(newComm);
            } else {
                existingForm.insertAdjacentHTML("afterend", html);
                oldLinks?.remove();
                oldComm?.remove();
            }
            loadMyLinks();
            resumeBulkImport();
            return;
        }
        panel.innerHTML = `
            ${!state.profile.exists || !state.profile.displayName ? profileSetupCard() : ""}
            <form class="bc-card" data-bc-form="addlink">
                <h3 class="bc-card-title">➕ Add referral links</h3>
                <p class="bc-small bc-muted">Paste one link, or several (one per line). Each link is merchant-verified before it can enter the homepage rotation. New verified merchants earn +${state.rules.merchantXp} XP (max ${state.rules.merchantDaily}/day). These are your referral links for casinos already on the list. A missing casino is suggested separately with Add a Domain.</p>
                ${window.bplPendingLinkDomain ? `<p class="bc-small">Adding a link for <strong>${esc(window.bplPendingLinkDomain)}</strong>. Paste your referral URL. One link covers every domain of that casino.</p>` : ""}
                <textarea name="links" rows="3" required placeholder="https://casino.com/register?ref=YOURCODE" spellcheck="false" autocapitalize="none"></textarea>
                <button class="bc-btn bc-btn-primary bc-btn-block" type="submit">Add link</button>
                <div data-bc-add-result></div>
            </form>
            ${linksStatsCards()}
            <div class="bc-card">
                <div class="bc-card-title-row"><h3 class="bc-card-title">🗂️ My links</h3>
                    <input type="search" class="bc-filter" data-bc-links-filter placeholder="Filter…" value="${esc(linksFilter)}"></div>
                <div data-bc-links><div class="bc-loading">Loading your links…</div></div>
            </div>`;
        loadMyLinks();
        resumeBulkImport();
    }

    async function loadMyLinks(force = false) {
        if (myLinks && !force) { renderLinkList(); return; }
        try {
            const data = await post(LINKS_API, {action: "myLinks"});
            myLinks = data.links || [];
            renderLinkList();
        } catch (error) {
            const host = $("[data-bc-links]");
            if (host) host.innerHTML = `<div class="bc-empty">⚠️ ${esc(error.message)}</div>`;
        }
    }

    function renderLinkList() {
        const host = $("[data-bc-links]");
        if (!host || !myLinks) return;
        const rows = myLinks.filter(link => !linksFilter || link.domain.includes(linksFilter) || link.referlink.toLowerCase().includes(linksFilter));
        if (!myLinks.length) { host.innerHTML = `<div class="bc-empty">No links yet. Add your first one above.</div>`; return; }
        rows.sort((a, b) => String(b.lastServedAt || "").localeCompare(String(a.lastServedAt || "")));
        const shown = rows.slice(0, 200);
        host.innerHTML = `<ul class="bc-links">${shown.map(link => `
            <li class="${link.enabled ? "" : "bc-off"}">
                <img src="api/favicon.php?domain=${encodeURIComponent(link.domain)}" alt="" loading="lazy" referrerpolicy="no-referrer">
                <div class="bc-link-main">
                    <strong>${esc(link.domain)}</strong>
                    <span class="bc-small bc-muted bc-ellipsis" title="${esc(link.referlink)}">${esc(link.referlink)}</span>
                    <span class="bc-small"><strong>${num(link.uniquePlays)} unique ${link.uniquePlays === 1 ? "person" : "people"}</strong></span>
                    <span class="bc-small bc-muted">All time: ${num(link.uniquePlays)} unique · Last 7 days: ${num(link.uniquePlays7d)} unique</span>
                </div>
                <button type="button" class="bc-switch${link.enabled ? " bc-on" : ""}" role="switch" aria-checked="${link.enabled}" aria-label="${link.enabled ? "Disable" : "Enable"} ${esc(link.domain)}" data-bc-action="toggleLink" data-id="${link.id}"><i></i></button>
            </li>`).join("")}</ul>
            ${rows.length > shown.length ? `<p class="bc-small bc-muted">Showing ${shown.length} of ${rows.length}. Use the filter to find more.</p>` : ""}
            ${!rows.length ? `<div class="bc-empty">No links match “${esc(linksFilter)}”.</div>` : ""}`;
    }

    async function addLinks(form) {
        const button = form.querySelector("button[type=submit]");
        const result = form.querySelector("[data-bc-add-result]");
        // Undo URL-encoded line breaks (iOS can paste a copied list as one URL
        // joined by %0A) and links glued together; only where a new link starts.
        const text = form.links.value.trim()
            .replace(/(?:%0D%0A|%0A|%0D)+(?=\s*(?:https?:\/\/|https?%3A%2F%2F|www\.))/gi, "\n")
            .replace(/(?:%0D|%0A)+(?=\s|$)/gi, "\n")
            .replace(/([a-z0-9_~,;-])(?=https?:\/\/)/gi, "$1\n");
        if (!text || bulkIsActive()) return;
        const lines = text.split(/[\s,]+/).filter(Boolean);
        result.innerHTML = "";
        {
            bulkImport.startPending = true;
            bulkImport.networkError = "";
            bulkImport.snapshot = {
                status: "starting",
                items: lines.map(referlink => ({referlink, status: "pending"})),
                processed: 0,
                total: lines.length,
                counts: {},
                reason: "",
            };
            renderBulkImport();
            try {
                const data = await postNow(LINKS_API, {action: "bulkStart", text});
                const importId = data?.importId || data?.import?.id || data?.job?.id;
                if (!validBulkImportId(importId)) throw new Error("The server did not return a valid import ID.");
                bulkImport.id = String(importId);
                bulkImport.snapshot = normaliseBulkSnapshot(data, bulkImport.snapshot.items);
                if (!bulkImport.snapshot.items.length) {
                    bulkImport.snapshot.items = lines.map(referlink => ({referlink, status: "pending"}));
                    bulkImport.snapshot.total = lines.length;
                }
                bulkImport.startPending = false;
                storeBulkImport();
                form.links.value = "";
                renderBulkImport();
                if (bulkIsTerminal()) await refreshAfterBulkTerminal();
                else scheduleBulkPoll(0);
            } catch (error) {
                bulkImport.startPending = false;
                bulkImport.id = "";
                bulkImport.snapshot = null;
                result.innerHTML = `<div class="bc-result bc-bad" role="alert">⚠️ ${esc(error.message)} The start request was not repeated automatically.</div>`;
                button.disabled = false;
                form.links.disabled = false;
                button.textContent = "Add link";
            }
            return;
        }
    }

    async function toggleLink(button) {
        const id = Number(button.dataset.id);
        const link = myLinks?.find(item => item.id === id);
        if (!link) return;
        button.disabled = true;
        try {
            await post(LINKS_API, {action: link.enabled ? "remove" : "enable", id});
            link.enabled = !link.enabled;
            renderLinkList();
            loadState(true).then(() => { renderLevelBar(); }).catch(() => {});
        } catch (error) {
            toast(error.message, "bad");
            button.disabled = false;
        }
    }

    async function saveProfile(form) {
        const button = form.querySelector("button[type=submit]");
        button.disabled = true;
        try {
            await post(LINKS_API, {action: "saveProfile", displayName: form.displayName.value});
            toast("Username saved", "ok");
            await loadState(true);
            renderAll();
        } catch (error) {
            toast(error.message, "bad");
        } finally {
            button.disabled = false;
        }
    }

    /* ---------- SHARE & EARN ---------- */

    function renderShare() {
        const panel = $('[data-bc-panel="share"]');
        if (!state.loggedIn) { panel.innerHTML = loggedOutCard("Sign in to get your personal share link and earn XP when the people you invite become verified members."); return; }
        const s = state.share;
        const r = state.rules;
        const next = s.nextMilestone;
        const pay = s.payout || null;
        const prevAt = next ? ([0, ...r.shareMilestones.map(m => m.referrals)].filter(v => v < next.referrals).pop() || 0) : 0;
        const pct = next ? Math.min(100, Math.round((s.rewarded - prevAt) * 100 / (next.referrals - prevAt))) : 100;
        panel.innerHTML = `
            ${!state.profile.exists || !state.profile.displayName ? profileSetupCard() : ""}
            <div class="bc-card bc-share-hero">
                <h3 class="bc-card-title">Share Best Pokies</h3>
                <p class="bc-small">Your website referral link</p>
                ${s.url ? `<div class="bc-copy"><input readonly value="${esc(s.url)}" aria-label="Your website referral link"><button type="button" class="bc-btn bc-btn-primary" data-bc-action="copyShare">Copy</button>${navigator.share ? `<button type="button" class="bc-btn" data-bc-action="nativeShare">Share</button>` : ""}</div>` : `<div class="bc-empty">Your website referral link is unavailable right now.</div>`}
                <p class="bc-small">Earn <strong>${num(pay?.rules?.websiteCredits ?? 15)} credits</strong> for each friend who joins with your link.</p>
                <p class="bc-small bc-muted">You get your reward once your friend does their first fetch with working casinos.</p>
            </div>
            ${payoutCard(pay)}
            <div class="bc-card" data-bc-discord>
                <h3 class="bc-card-title">Discord referral</h3>
                <p class="bc-small bc-muted">Loading your Discord referral…</p>
            </div>
            <div class="bc-card">
                <h3 class="bc-card-title">📈 Your share stats</h3>
                ${statGrid([
                    [num(s.visits), "link visits"],
                    [num(s.engaged), "stayed 15s+"],
                    [num(s.rewarded), "XP-rewarded referrals"],
                    [`${s.rewardedToday}/${r.shareDaily}`, "rewarded today"],
                    [num(s.xpEarned), "XP from sharing"],
                    [num(s.queued), "queued for tomorrow"],
                ])}
                ${next ? `<div class="bc-level-row bc-small"><span>Next milestone: <b>${next.referrals} verified referrals</b></span><span class="bc-xp-pill">+${next.xp} XP</span></div>
                <div class="bc-meter"><i style="width:${pct}%"></i></div>` : `<p class="bc-small">🏅 All share milestones unlocked!</p>`}
            </div>
            <div class="bc-card">
                <h3 class="bc-card-title">✅ What counts</h3>
                <ul class="bc-list bc-rules-list">
                    <li><span>👀 Page visits (shown as stats only)</span><strong>0</strong></li>
                    <li><span>🎉 Invited person signs in and does their first fetch with working casinos</span><strong>+${r.referralXp}</strong></li>
                    ${r.shareMilestones.map(m => `<li><span>🏅 ${m.referrals} verified referrals</span><strong>+${m.xp}</strong></li>`).join("")}
                </ul>
                <p class="bc-small bc-muted">These are XP, separate from the referral credits above. Checked on our server with the promoter referral rules: each person counts once ever, max ${r.shareDaily} rewards per day (extras wait for the next day). Your own account, devices or networks, linked accounts, VPN/proxy traffic and repeat networks don't count.</p>
            </div>`;
        loadDiscordShare(false);
    }

    function payoutCard(pay) {
        if (!pay || !pay.website) return "";
        const w = pay.website;
        const e = pay.earned || {};
        const tiers = Array.isArray(pay.tiers) ? pay.tiers : [];
        const nextTier = tiers.find(t => !t.reached);
        const icons = {bronze: "🥉", silver: "🥈", gold: "🥇", diamond: "💎"};
        return `
            <div class="bc-card">
                <h3 class="bc-card-title">🎁 Your referrals</h3>
                ${statGrid([
                    [num(w.joined), "joined"],
                    [num(w.pendingFirstFetch), "pending first fetch"],
                    [num(w.qualified), "qualified"],
                    [num(e.total || 0), "credits earned"],
                ])}
                <p class="bc-small bc-muted">A referral qualifies when your friend's first Bonus Fetcher fetch logs in to at least ${num(pay.rules?.minOwnLogins ?? 3)} casinos with their own number. Pending referrals expire after ${num(pay.rules?.pendingDays ?? 30)} days. Website ${num(e.website || 0)} · Discord ${num(e.discord || 0)} · Tier bonuses ${num(e.tiers || 0)} credits.</p>
                ${tiers.length ? `<ul class="bc-list bc-rules-list">${tiers.map(t => `<li><span>${icons[t.id] || "🏅"} ${esc(t.name)}: ${num(t.at)} qualified referrals${t.reached ? " ✓" : ""}</span><strong>+${num(t.credits)} credits</strong></li>`).join("")}</ul>` : ""}
                ${nextTier ? `<p class="bc-small">Next tier: <b>${esc(nextTier.name)}</b> at ${num(nextTier.at)} qualified referrals (you have ${num(pay.qualifiedTotal || 0)}).</p>` : (tiers.length ? `<p class="bc-small">💎 Top referral tier reached!</p>` : "")}
            </div>`;
    }

    function discordShareCard(data) {
        const host = $("[data-bc-discord]");
        if (!host) return;
        const credits = state?.share?.payout?.rules?.discordCredits ?? 20;
        const rewards = `
            <p class="bc-small">Earn <strong>${num(credits)} credits</strong> for each friend who joins the Discord with your invite and links their Best Pokies account.</p>
            <p class="bc-small bc-muted">You get your reward once your friend does their first fetch with working casinos.</p>`;
        const counts = data && data.linked !== false && Number.isFinite(Number(data.joined)) ? `
            ${statGrid([
                [num(data.joined || 0), "joined"],
                [num(data.awaitingLink || 0), "need to link account"],
                [num(data.awaitingFetch || 0), "pending first fetch"],
                [num(data.successful || 0), "qualified"],
                [num(data.creditsEarned || 0), "credits earned"],
            ])}` : "";
        if (!data || data.linked === false) {
            host.innerHTML = `<h3 class="bc-card-title">Discord referral</h3><p class="bc-small">Share your Discord invite once your Discord account is linked from your profile.</p>${rewards}`;
            return;
        }
        const url = String(data.inviteUrl || "").trim();
        host.innerHTML = `
            <h3 class="bc-card-title">Discord referral</h3>
            <p class="bc-small">Your Discord referral invite</p>
            ${url
                ? `<div class="bc-copy"><input readonly value="${esc(url)}" aria-label="Your Discord referral link"><button type="button" class="bc-btn bc-btn-primary" data-bc-action="copyDiscord">Copy</button>${navigator.share ? `<button type="button" class="bc-btn" data-bc-action="shareDiscord">Share</button>` : ""}</div>`
                : `<button type="button" class="bc-btn bc-btn-primary" data-bc-action="getDiscord">Get my Discord referral link</button>`}
            ${rewards}${counts}`;
    }

    async function loadDiscordShare(createIfMissing) {
        const host = $("[data-bc-discord]");
        if (!host) return;
        if (createIfMissing) {
            const button = host.querySelector("[data-bc-action=getDiscord]");
            if (button) { button.disabled = true; button.textContent = "Getting link…"; }
        }
        try {
            discordShare = await post("api/discord-referral-self.php", {action: createIfMissing ? "getOrCreate" : "get"});
            discordShareCard(discordShare);
        } catch (error) {
            host.innerHTML = `<h3 class="bc-card-title">Discord referral</h3><p class="bc-small">Discord referral is unavailable right now.</p>`;
        }
    }

    async function copyShareUrl(url, okMessage) {
        if (!url) return;
        try { await navigator.clipboard.writeText(url); toast(okMessage, "ok"); }
        catch {
            const input = document.querySelector(".bc-copy input");
            if (input) { input.focus(); input.select(); document.execCommand?.("copy"); }
            toast(okMessage, "ok");
        }
    }

    function copyShare() {
        copyShareUrl(state?.share?.url, "Website referral copied");
    }

    /* ---------- RANKS ---------- */

    const BOARDS_API = "api/community-leaderboards.php";
    const RANK_BOARD_KEY = "bpl:ranks:board";
    const RANK_BOARDS = [
        {id: "xp", label: "🏆 XP"},
        {id: "signed", label: "🎰 Signed up", title: "🎰 Most casinos signed up", unit: "casino", note: "Homepage casinos you've logged in to with your own number in Bonus Fetcher. Sister sites of the same casino count once."},
        {id: "added", label: "🆕 New casinos", title: "🆕 New casinos added", unit: "new casino", note: "Casinos you submitted that weren't on the homepage, passed the Domain Maintenance check and got a card. Each casino counts once, for the first person who added it."},
        {id: "live", label: "🔗 Live links", title: "🔗 Most live referral links", unit: "live link", note: "Your saved referral links that are in the homepage fair-turn rotation right now: enabled, on a casino with a homepage card, and not blocked. One per casino."},
    ];
    let rankBoard = (() => { try { const v = sessionStorage.getItem(RANK_BOARD_KEY); return RANK_BOARDS.some(b => b.id === v) ? v : "xp"; } catch { return "xp"; } })();
    const boardCache = {};
    const boardLoadedAt = {};

    /* Gold / silver / bronze rows for places 1-3 on every board. */
    const rankTier = pos => pos === 1 ? "bc-rank-gold" : pos === 2 ? "bc-rank-silver" : pos === 3 ? "bc-rank-bronze" : "";

    function rankSwitch() {
        return `<div class="bc-seg bc-rank-switch" role="tablist">${RANK_BOARDS.map(b =>
            `<button type="button" role="tab" class="bc-seg-btn${rankBoard === b.id ? " bc-seg-on" : ""}" aria-selected="${rankBoard === b.id}" data-bc-board="${b.id}">${b.label}</button>`).join("")}</div>`;
    }

    function wireRanks(panel) {
        if (panel.dataset.bcRanksWired) return;
        panel.dataset.bcRanksWired = "1";
        panel.addEventListener("click", event => {
            const btn = event.target.closest("[data-bc-board]");
            if (!btn || btn.dataset.bcBoard === rankBoard) return;
            rankBoard = btn.dataset.bcBoard;
            try { sessionStorage.setItem(RANK_BOARD_KEY, rankBoard); } catch {}
            renderRanks();
        });
    }

    async function renderRanks(force = false) {
        const panel = $('[data-bc-panel="ranks"]');
        if (!panel) return;
        wireRanks(panel);
        if (rankBoard !== "xp") { renderBoard(panel, rankBoard, force); return; }
        if (!force && renderRanks.cache && Date.now() - ranksLoadedAt < 60000) { paintRanks(panel, renderRanks.cache); return; }
        panel.innerHTML = `${rankSwitch()}<div class="bc-loading">Loading leaderboard…</div>`;
        try {
            renderRanks.cache = await post(LINKS_API, {action: "ranks"});
            ranksLoadedAt = Date.now();
            if (rankBoard === "xp") paintRanks(panel, renderRanks.cache);
        } catch (error) {
            if (rankBoard === "xp") panel.innerHTML = `${rankSwitch()}<div class="bc-empty">⚠️ ${esc(error.message)}</div>`;
        }
    }

    function paintRanks(panel, data) {
        const viewer = data.viewer;
        const medal = pos => pos === 1 ? "🥇" : pos === 2 ? "🥈" : pos === 3 ? "🥉" : `#${pos}`;
        panel.innerHTML = `
            ${rankSwitch()}
            ${viewer ? `<div class="bc-card bc-you"><span>Your rank</span><strong>${viewer.position ? `#${viewer.position}` : "Unranked"}</strong><span>${num(viewer.xp)} XP · Lv ${viewer.level}</span></div>` : (!state.loggedIn ? loggedOutCard("Sign in to appear on the leaderboard.") : "")}
            <div class="bc-card">
                <h3 class="bc-card-title">🏆 Leaderboard <small>${num(data.totalPlayers)} players</small></h3>
                <ol class="bc-ranks">${(data.leaders || []).map(row => `
                    <li class="${rankTier(row.position)}${viewer && viewer.position === row.position ? " bc-me" : ""}">
                        <span class="bc-rank-pos">${medal(row.position)}</span>
                        <span class="bc-rank-name">${avatar(row, "bc-rank-av")}${memberLink(row.memberId, row.name)}</span>
                        <span class="bc-rank-lv">Lv ${row.level}</span>
                        <strong>${num(row.xp)}</strong>
                    </li>`).join("")}</ol>
            </div>`;
    }

    async function renderBoard(panel, id, force = false) {
        if (!force && boardCache[id] && Date.now() - (boardLoadedAt[id] || 0) < 60000) { paintBoard(panel, id, boardCache[id]); return; }
        panel.innerHTML = `${rankSwitch()}<div class="bc-loading">Loading leaderboard…</div>`;
        try {
            boardCache[id] = await post(BOARDS_API, {board: id});
            boardLoadedAt[id] = Date.now();
            if (rankBoard === id) paintBoard(panel, id, boardCache[id]);
        } catch (error) {
            if (rankBoard === id) panel.innerHTML = `${rankSwitch()}<div class="bc-empty">⚠️ ${esc(error.message)}</div>`;
        }
    }

    function paintBoard(panel, id, data) {
        const board = RANK_BOARDS.find(b => b.id === id) || RANK_BOARDS[1];
        const viewer = data.viewer;
        const medal = pos => pos === 1 ? "🥇" : pos === 2 ? "🥈" : pos === 3 ? "🥉" : `#${pos}`;
        const count = n => `${num(n)} ${board.unit}${Number(n) === 1 ? "" : "s"}`;
        const leaders = data.leaders || [];
        const extra = viewer && viewer.position && !leaders.some(r => r.position === viewer.position) ? viewer : null;
        const row = r => `
                    <li class="${rankTier(r.position)}${viewer && viewer.position === r.position ? " bc-me" : ""}">
                        <span class="bc-rank-pos">${medal(r.position)}</span>
                        <span class="bc-rank-name">${avatar(r, "bc-rank-av")}${memberLink(r.memberId, r.name)}</span>
                        <strong class="bc-rank-count">${count(r.count)}</strong>
                    </li>`;
        panel.innerHTML = `
            ${rankSwitch()}
            ${viewer ? `<div class="bc-card bc-you"><span>Your rank</span><strong>${viewer.position ? `#${viewer.position}` : "Unranked"}</strong><span>${count(viewer.count)}</span></div>` : (!state.loggedIn ? loggedOutCard("Sign in to appear on the leaderboard.") : "")}
            <div class="bc-card">
                <h3 class="bc-card-title">${esc(board.title)} <small>${num(data.total)} players</small></h3>
                <p class="bc-small bc-muted">${esc(board.note)}</p>
                ${leaders.length ? `<ol class="bc-ranks">${leaders.map(row).join("")}${extra ? `<li class="bc-rank-gap" aria-hidden="true">…</li>${row(extra)}` : ""}</ol>` : `<div class="bc-empty">No one on this board yet.</div>`}
            </div>`;
    }

    /* ---------- TOP RATED (domain votes) ---------- */

    const VOTES_API = "api/domain-votes.php";
    const TOP_VIEW_KEY = "bpl:topRated:view";
    let topView = (() => { try { return sessionStorage.getItem(TOP_VIEW_KEY) || "top"; } catch { return "top"; } })();
    let topCache = {top: null, list: null, mine: null};
    let topLoadedAt = {top: 0, list: 0, mine: 0};
    let topSearch = "";
    let topBusy = new Set();

    /* Same favicon chain and cache as the homepage cards, so icons load once and stay. */
    function voteFavicon(domain) {
        const cached = window.bplFaviconOk ? window.bplFaviconOk.get(domain) : null;
        const src = cached || `api/favicon.php?domain=${encodeURIComponent(domain)}`;
        return `<img class="tv-fav" src="${esc(src)}" alt="" width="26" height="26" loading="${cached ? "eager" : "lazy"}" decoding="async" referrerpolicy="no-referrer" data-tv-fav="${esc(domain)}">`;
    }

    function wireFavicons(root) {
        root.querySelectorAll("img[data-tv-fav]").forEach(img => {
            if (img.dataset.tvWired) return;
            img.dataset.tvWired = "1";
            const domain = img.dataset.tvFav;
            img.addEventListener("load", () => {
                if (img.naturalWidth > 0) {
                    if (!window.bplFaviconOk) window.bplFaviconOk = new Map();
                    window.bplFaviconOk.set(domain, img.getAttribute("src"));
                }
            });
            img.addEventListener("error", () => {
                const intel = typeof INTEL_API === "string" ? `${INTEL_API}/favicon/${encodeURIComponent(domain)}` : "";
                if (intel && img.getAttribute("src") !== intel && !img.dataset.tvTriedIntel) {
                    img.dataset.tvTriedIntel = "1";
                    img.src = intel;
                } else if (typeof letterIcon === "function") {
                    img.src = letterIcon(domain);
                } else {
                    img.style.visibility = "hidden";
                }
            }, {once: false});
        });
    }

    async function loadTop(view, force = false) {
        if (!force && topCache[view] && Date.now() - topLoadedAt[view] < 60000) return topCache[view];
        const action = view === "top" ? "top" : view === "vote" ? "list" : "mine";
        topCache[view] = await postNow(VOTES_API, {action});
        topLoadedAt[view] = Date.now();
        return topCache[view];
    }

    function topSwitch() {
        const opts = [["top", "Top rated"], ["vote", "Vote"], ["mine", "My votes"]];
        return `<div class="tv-switch" role="tablist" aria-label="Top rated views">${opts.map(([id, label]) =>
            `<button type="button" role="tab" class="tv-switch-btn${topView === id ? " tv-on" : ""}" aria-selected="${topView === id}" data-tv-view="${id}">${label}</button>`).join("")}</div>`;
    }

    function topLimitLine(data) {
        if (!data || data.dailyLimit === undefined) return "";
        const m = data.mission || {};
        return `<p class="tv-limit">${num(data.leftToday)} of ${num(data.dailyLimit)} votes or changes left today (removing is free) · 🎯 Mission ${num(m.done)}/${num(m.goal)} (+${num(m.xpEach)} XP each)</p>`;
    }

    function promoTag(item) {
        return item.promoted ? `<span class="tv-promo" title="Promoted card. Promotion never changes the score.">Promoted</span>` : "";
    }

    function voteButtons(item) {
        if (!item.canVote) {
            return `<span class="tv-locked" title="Unlocks once Bonus Fetcher logs in to this site with your own Best Pokies number. Extra numbers don't count.">🔒 Log in to this site with your own number to vote</span>`;
        }
        const busy = topBusy.has(item.domain) ? " disabled" : "";
        return `<span class="tv-btns">
            <button type="button" class="tv-vote tv-up${item.my === 1 ? " tv-picked" : ""}" data-tv-vote="1" data-tv-domain="${esc(item.domain)}" aria-pressed="${item.my === 1}" aria-label="Thumbs up ${esc(item.domain)}"${busy}>👍</button>
            <button type="button" class="tv-vote tv-down${item.my === -1 ? " tv-picked" : ""}" data-tv-vote="-1" data-tv-domain="${esc(item.domain)}" aria-pressed="${item.my === -1}" aria-label="Thumbs down ${esc(item.domain)}"${busy}>👎</button>
        </span>`;
    }

    function topRow(item) {
        return `<li class="tv-row" data-tv-row="${esc(item.domain)}">
            <span class="tv-rank">${item.rank}</span>${voteFavicon(item.domain)}
            <span class="tv-name"><b>${esc(item.domain)}</b>${promoTag(item)}</span>
            <span class="tv-score"><strong>👍 ${num(item.pct)}%</strong><small>${num(item.votes)} votes</small></span>
        </li>`;
    }

    function voteRow(item) {
        return `<li class="tv-row" data-tv-row="${esc(item.domain)}">
            ${voteFavicon(item.domain)}
            <span class="tv-name"><b>${esc(item.domain)}</b>${promoTag(item)}</span>
            ${voteButtons(item)}
        </li>`;
    }

    function mineRow(item) {
        return `<li class="tv-row" data-tv-row="${esc(item.domain)}">
            ${voteFavicon(item.domain)}
            <span class="tv-name"><b>${esc(item.domain)}</b>${promoTag(item)}<small>${item.votes >= 5 ? `👍 ${num(item.pct)}% of ${num(item.votes)}` : `${num(item.votes)} vote${item.votes === 1 ? "" : "s"} so far`}</small></span>
            ${item.canVote ? voteButtons(item) : `<span class="tv-btns"><span class="tv-mine-vote">${item.my === 1 ? "👍" : "👎"}</span></span>`}
            <button type="button" class="tv-remove" data-tv-vote="0" data-tv-domain="${esc(item.domain)}" aria-label="Remove vote on ${esc(item.domain)}">Remove</button>
        </li>`;
    }

    async function renderTopRated(force = false) {
        const panel = $('[data-bc-panel="top"]');
        if (!panel) return;
        const head = `${topSwitch()}`;
        if (!panel.querySelector(".tv-switch")) panel.innerHTML = `${head}<div class="tv-body"><div class="bc-loading">Loading…</div></div>`;
        else panel.querySelector(".tv-switch").outerHTML = head;
        const body = panel.querySelector(".tv-body");
        if (!state?.loggedIn && topView !== "top") {
            body.innerHTML = loggedOutCard("Sign in to vote on casinos you have played.");
            return;
        }
        try {
            const data = await loadTop(topView, force);
            paintTop(body, data);
        } catch (error) {
            body.innerHTML = error.status === 401
                ? loggedOutCard("Sign in to vote on casinos you have played.")
                : `<div class="bc-empty">⚠️ ${esc(error.message)}</div>`;
        }
    }

    function paintTop(body, data) {
        const items = Array.isArray(data.items) ? data.items : [];
        if (topView === "top") {
            body.innerHTML = `<div class="bc-card">
                <h3 class="bc-card-title">⭐ Top rated casinos <small>${num(data.minVotes || 5)}+ votes</small></h3>
                <p class="bc-small bc-muted">Votes come from members who logged in to that casino with Bonus Fetcher. Ranked by a confidence score, so a few votes can't outrank many. Promoted cards never change the score. The top-voted sites get considered for the Best section.</p>
                ${items.length ? `<ol class="tv-list">${items.map(topRow).join("")}</ol>` : `<div class="bc-empty">No casino has ${num(data.minVotes || 5)} votes yet. Be one of the first — open Vote.</div>`}
            </div>`;
        } else if (topView === "vote") {
            body.innerHTML = `<div class="bc-card">
                <h3 class="bc-card-title">👍 Rate casinos <small>${num(data.eligibleCount)} you can rate</small></h3>
                <p class="bc-small bc-muted">One vote per person per casino. Change or remove it any time and your new vote replaces the old one. The top-voted sites get considered for the Best section.</p>
                ${topLimitLine(data)}
                <input class="tv-search" type="search" inputmode="search" autocomplete="off" spellcheck="false" placeholder="Search casinos" value="${esc(topSearch)}" data-tv-search>
                <ul class="tv-list">${items.map(voteRow).join("")}</ul>
                <div class="bc-empty tv-none" hidden>No casino matches.</div>
            </div>`;
            applyTopSearch(body);
        } else {
            body.innerHTML = `<div class="bc-card">
                <h3 class="bc-card-title">🗳️ My votes <small>${num(items.length)}</small></h3>
                ${topLimitLine(data)}
                ${items.length ? `<ul class="tv-list">${items.map(mineRow).join("")}</ul>` : `<div class="bc-empty">You haven't voted yet. Open Vote to rate casinos you've fetched.</div>`}
                <p class="bc-small bc-muted">Only totals are shown to others. Nobody can see who voted.</p>
            </div>`;
        }
        wireFavicons(body);
    }

    function applyTopSearch(body) {
        const q = topSearch.trim().toLowerCase();
        let shown = 0;
        body.querySelectorAll("[data-tv-row]").forEach(row => {
            const on = !q || row.dataset.tvRow.includes(q);
            row.hidden = !on;
            if (on) shown++;
        });
        const none = body.querySelector(".tv-none");
        if (none) none.hidden = shown > 0;
    }

    async function castVote(domain, vote) {
        if (topBusy.has(domain)) return;
        topBusy.add(domain);
        const panel = $('[data-bc-panel="top"]');
        panel?.querySelectorAll(`[data-tv-domain="${CSS.escape(domain)}"]`).forEach(b => { b.disabled = true; });
        try {
            const res = await postNow(VOTES_API, {action: "vote", domain, vote});
            for (const view of ["list", "mine"]) {
                const cache = topCache[view];
                if (!cache) continue;
                ["leftToday", "usedToday", "dailyLimit", "mission"].forEach(k => { if (res[k] !== undefined) cache[k] = res[k]; });
                const item = (cache.items || []).find(i => i.domain === res.domain);
                if (item) {
                    item.my = res.my;
                    if (res.totals) { item.pct = res.totals.pct; item.votes = res.totals.total; }
                }
                if (view === "mine" && item && res.my === 0) cache.items = cache.items.filter(i => i.domain !== res.domain);
            }
            if (!topCache.mine || (res.my !== 0 && !(topCache.mine.items || []).some(i => i.domain === res.domain))) topLoadedAt.mine = 0;
            topLoadedAt.top = 0;
            if (res.xp && state?.progress) { lastPulseKey = ""; }
            updateTopRow(domain);
            if (res.xp) toastVote(`+${res.xp} XP · Vote mission ${res.mission?.done ?? ""}/${res.mission?.goal ?? ""}`);
        } catch (error) {
            toastVote(error.message || "Vote failed");
        } finally {
            topBusy.delete(domain);
            panel?.querySelectorAll(`[data-tv-domain="${CSS.escape(domain)}"]`).forEach(b => { b.disabled = false; });
        }
    }

    /* Update only the clicked row (and the limit line), so favicons and scroll stay put. */
    function updateTopRow(domain) {
        const panel = $('[data-bc-panel="top"]');
        const body = panel?.querySelector(".tv-body");
        if (!body) return;
        const cache = topCache[topView === "vote" ? "list" : topView];
        if (!cache) return;
        const limit = body.querySelector(".tv-limit");
        if (limit) limit.outerHTML = topLimitLine(cache);
        const row = body.querySelector(`[data-tv-row="${CSS.escape(domain)}"]`);
        if (!row) return;
        const item = (cache.items || []).find(i => i.domain === domain);
        if (!item) { row.remove(); return; }
        const btns = row.querySelector(".tv-btns");
        if (btns) btns.outerHTML = item.canVote ? voteButtons(item) : btns.outerHTML;
        const small = row.querySelector(".tv-name small");
        if (small && topView === "mine") small.textContent = item.votes >= 5 ? `👍 ${num(item.pct)}% of ${num(item.votes)}` : `${num(item.votes)} vote${item.votes === 1 ? "" : "s"} so far`;
    }

    function toastVote(text) {
        const panel = $('[data-bc-panel="top"]');
        if (!panel) return;
        let t = panel.querySelector(".tv-toast");
        if (!t) { t = document.createElement("div"); t.className = "tv-toast"; t.setAttribute("role", "status"); panel.append(t); }
        t.textContent = text;
        t.classList.add("tv-show");
        clearTimeout(toastVote.timer);
        toastVote.timer = setTimeout(() => t.classList.remove("tv-show"), 2600);
    }

    function wireTopRated() {
        drawer.addEventListener("click", event => {
            const view = event.target.closest("[data-tv-view]");
            if (view) {
                topView = view.dataset.tvView;
                try { sessionStorage.setItem(TOP_VIEW_KEY, topView); } catch {}
                renderTopRated();
                return;
            }
            const vote = event.target.closest("[data-tv-vote]");
            if (vote && !vote.disabled) {
                const domain = vote.dataset.tvDomain;
                let value = Number(vote.dataset.tvVote);
                const item = (topCache[topView === "vote" ? "list" : topView]?.items || []).find(i => i.domain === domain);
                if (value !== 0 && item && item.my === value) value = 0; // tap again to clear
                castVote(domain, value);
            }
        });
        drawer.addEventListener("input", event => {
            if (!event.target.matches("[data-tv-search]")) return;
            topSearch = event.target.value;
            applyTopSearch(event.target.closest(".tv-body"));
        });
    }

    /* ---------- CHAT & FEED ---------- */

    function renderChatShell() {
        const panel = $('[data-bc-panel="chat"]');
        if (panel.querySelector("[data-bc-chatlog]") && panel.dataset.loggedIn === String(!!state?.loggedIn)) { applyChatView(); pollChat(); return; }
        panel.dataset.loggedIn = String(!!state?.loggedIn);
        chatLastId = 0;
        panel.innerHTML = `
            <div class="bc-seg" role="tablist">
                <button type="button" data-bc-action="chatView" data-view="chat" class="bc-seg-btn">💬 Live chat</button>
                <button type="button" data-bc-action="chatView" data-view="feed" class="bc-seg-btn">📰 Feed</button>
            </div>
            <div data-bc-chatwrap class="bc-chatwrap">
                <div class="bc-chatlog" data-bc-chatlog aria-live="polite"><div class="bc-loading">Loading chat…</div></div>
                ${state?.loggedIn
                    ? (!state.profile.exists || !state.profile.displayName ? profileSetupCard()
                        : `<div class="bc-replying" data-bc-replying hidden></div>
                           <div class="bc-suggest" data-bc-suggest hidden></div>
                           <form class="bc-chatform" data-bc-form="chat"><input name="message" maxlength="500" autocomplete="off" enterkeyhint="send" autocapitalize="sentences" placeholder="Message the community…" required><button class="bc-btn bc-btn-primary" type="submit">Send</button></form>`)
                    : `<div class="bc-chat-locked"><a class="bc-btn bc-btn-primary" href="bonus-fetch.php">Sign in to chat</a></div>`}
            </div>
            <div data-bc-feedwrap hidden>${feedCard()}</div>`;
        applyChatView();
        pollChat();
    }

    function applyChatView() {
        const panel = $('[data-bc-panel="chat"]');
        panel.querySelectorAll("[data-view]").forEach(btn => btn.classList.toggle("bc-seg-on", btn.dataset.view === chatView));
        panel.querySelector("[data-bc-chatwrap]").hidden = chatView !== "chat";
        panel.querySelector("[data-bc-feedwrap]").hidden = chatView !== "feed";
        if (chatView === "feed") loadFeed();
    }

    function chatMessageHtml(m) {
        const hasCard = (m.parts || []).some(part => part.t === "casino");
        const tools = state?.loggedIn
            ? `<span class="bc-msg-tools"><button type="button" data-bc-action="reply" data-id="${m.id}" data-name="${esc(m.displayName || m.name)}">Reply</button><button type="button" data-bc-action="report" data-id="${m.id}">Report</button></span>`
            : "";
        const quote = m.reply ? `<div class="bc-quote">↩ ${esc(m.reply.name)}: ${esc(m.reply.text)}</div>` : "";
        return `<div class="bc-msg" data-id="${m.id}" data-name="${esc(m.displayName || "")}">
            <div class="bc-msg-head">${avatar(m, "bc-msg-av")}<strong>${memberLink(m.memberId, m.name)}</strong><span class="bc-lv">Lv ${Number(m.level) || 1}</span>${m.online ? `<span class="bc-online" title="Online"></span>` : ""}<time>${esc(clockTime(m.ts))}</time>${tools}</div>
            <div class="bc-msg-body">${quote}${messageBodyHtml(m)}</div>
            ${!hasCard && m.referlinkDomain ? `<div class="bc-msg-link">🔗 ${esc(m.referlinkDomain)} · ${esc(m.referlinkStatus || "shared")}</div>` : ""}
        </div>`;
    }

    async function markChatRead(id) {
        if (!state?.loggedIn || !id || id <= lastMarkedRead) return;
        lastMarkedRead = id;
        try {
            await post(LINKS_API, {action: "chatRead", id});
            setUnreadDot(false);
        } catch (error) {
            lastMarkedRead = 0;
        }
    }

    function setReplyDraft(draft) {
        replyDraft = draft;
        const bar = $("[data-bc-replying]");
        if (!bar) return;
        if (!draft) {
            bar.hidden = true;
            bar.innerHTML = "";
            return;
        }
        bar.hidden = false;
        bar.innerHTML = `<span>Replying to <b>${esc(draft.name)}</b></span><button type="button" data-bc-action="cancelReply" aria-label="Cancel reply">×</button>`;
        $("[data-bc-form=chat] input")?.focus();
    }

    function mentionNames() {
        const names = new Set();
        document.querySelectorAll("[data-bc-chatlog] [data-name]").forEach(node => {
            const name = node.dataset.name.trim();
            if (name) names.add(name);
        });
        return [...names];
    }

    function updateMentionSuggest(input) {
        const box = $("[data-bc-suggest]");
        if (!box) return;
        const pos = input.selectionStart || 0;
        const match = input.value.slice(0, pos).match(/(^|\s)@([^\n@]*)$/);
        if (!match) { box.hidden = true; box.innerHTML = ""; return; }
        const query = match[2].trim().toLowerCase();
        const names = mentionNames().filter(name => name.toLowerCase().includes(query)).slice(0, 5);
        if (!names.length) { box.hidden = true; box.innerHTML = ""; return; }
        box.hidden = false;
        box.innerHTML = names.map(name => `<button type="button" data-bc-action="mention" data-name="${esc(name)}">@${esc(name)}</button>`).join("");
    }

    async function pollChat() {
        const log = $("[data-bc-chatlog]");
        if (!log || document.hidden) return;
        try {
            const data = await post(LINKS_API, {action: "chat", afterId: chatLastId});
            const messages = data.messages || [];
            if (!chatLastId) log.innerHTML = messages.length ? "" : `<div class="bc-empty">No messages yet. Say hi 👋</div>`;
            const nearBottom = log.scrollHeight - log.scrollTop - log.clientHeight < 80;
            if (messages.length) {
                log.querySelector(".bc-empty")?.remove();
                log.insertAdjacentHTML("beforeend", messages.filter(m => m.id > chatLastId).map(chatMessageHtml).join(""));
                chatLastId = Math.max(chatLastId, ...messages.map(m => m.id));
                const extra = log.children.length - 150;
                for (let i = 0; i < extra; i++) log.firstElementChild?.remove();
                if (nearBottom || messages.length > 20) log.scrollTop = log.scrollHeight;
            }
            if (state?.loggedIn && chatLastId && (nearBottom || !messages.length)) markChatRead(chatLastId);
        } catch (error) {
            if (!chatLastId) log.innerHTML = `<div class="bc-empty">Chat unavailable right now.</div>`;
        }
    }

    function startChat() {
        stopChat();
        chatTimer = setInterval(pollChat, CHAT_POLL_MS);
    }

    function stopChat() {
        if (chatTimer) clearInterval(chatTimer);
        chatTimer = null;
    }

    function insertMention(name) {
        const input = $("[data-bc-form=chat] input");
        if (!input || !name) return;
        const pos = input.selectionStart || 0;
        const before = input.value.slice(0, pos).replace(/@([^\n@]*)$/, `@${name} `);
        input.value = before + input.value.slice(pos);
        const box = $("[data-bc-suggest]");
        if (box) { box.hidden = true; box.innerHTML = ""; }
        input.focus();
    }

    async function openSharePicker() {
        const host = $("[data-bc-share-list]");
        if (!host) return;
        if (!host.hidden) { host.hidden = true; return; }
        host.hidden = false;
        host.innerHTML = `<div class="bc-loading">Loading your links…</div>`;
        try {
            if (!myLinks) {
                const data = await post(LINKS_API, {action: "myLinks"});
                myLinks = data.links || [];
            }
            const enabled = myLinks.filter(link => link.enabled);
            host.innerHTML = enabled.length
                ? `<div class="bc-share-list">${enabled.slice(0, 30).map(link => `<button type="button" data-bc-action="shareLink" data-id="${link.id}">${esc(link.domain)}</button>`).join("")}</div>`
                : `<p class="bc-small bc-muted">No active links yet. Add one in the Links tab.</p>`;
        } catch (error) {
            host.innerHTML = `<p class="bc-small">${esc(error.message)}</p>`;
        }
    }

    async function shareSavedLink(button) {
        button.disabled = true;
        try {
            const data = await post(LINKS_API, {action: "shareLink", id: Number(button.dataset.id)});
            toast(data.alreadyShared ? "You already shared that casino this hour." : "Shared in chat.");
            const host = $("[data-bc-share-list]");
            if (host) host.hidden = true;
            await pollChat();
            const log = $("[data-bc-chatlog]");
            if (log) log.scrollTop = log.scrollHeight;
        } catch (error) {
            toast(error.message, "bad");
            button.disabled = false;
        }
    }

    async function reportMessage(button) {
        if (!confirm("Report this message?")) return;
        button.disabled = true;
        try {
            await post(LINKS_API, {action: "reportChat", id: Number(button.dataset.id)});
            toast("Report sent. Thanks.", "ok");
        } catch (error) {
            toast(error.message, "bad");
            button.disabled = false;
        }
    }

    async function sendChat(form) {
        const input = form.message;
        const text = input.value.trim();
        if (!text) return;
        const button = form.querySelector("button");
        button.disabled = true;
        try {
            const payload = {action: "sendChat", message: text};
            if (replyDraft?.id) payload.replyTo = replyDraft.id;
            const data = await post(LINKS_API, {action: "sendChat", ...payload});
            if (data.alreadyShared) toast("You already shared that casino this hour.");
            input.value = "";
            setReplyDraft(null);
            const suggest = $("[data-bc-suggest]");
            if (suggest) { suggest.hidden = true; suggest.innerHTML = ""; }
            await pollChat();
            const log = $("[data-bc-chatlog]");
            if (log) log.scrollTop = log.scrollHeight;
            loadState(true).then(renderLevelBar).catch(() => {});
            if (/^https?:\/\//i.test(text)) myLinks = null;
        } catch (error) {
            toast(error.message, "bad");
        } finally {
            button.disabled = false;
            input.focus();
        }
    }

    /* ---------- actions ---------- */

    function handleAction(el, event) {
        const action = el.dataset.bcAction;
        if (action === "claimWeeklyCredits") { claimWeeklyCredits(); }
        else if (action === "myProfile" && state?.profile?.memberId) { openProfile(state.profile.memberId, {customize: true}); }
        else if (action === "retry") { loadState(true).then(renderAll).catch(renderError); }
        else if (action === "retryBulk") { bulkImport.networkError = ""; scheduleBulkPoll(0); renderBulkImport(); }
        else if (action === "toggleLink") toggleLink(el);
        else if (action === "copyShare") copyShare();
        else if (action === "nativeShare") navigator.share?.({title: "Best Pokies List", text: "Latest Aussie pokies sites & bonuses", url: state.share.url}).catch(() => {});
        else if (action === "copyDiscord") copyShareUrl(discordShare?.inviteUrl, "Discord referral copied");
        else if (action === "shareDiscord") navigator.share?.({title: "Best Pokies Discord", text: "Join Best Pokies on Discord", url: discordShare?.inviteUrl}).catch(() => {});
        else if (action === "getDiscord") loadDiscordShare(true);
        else if (action === "chatView") { chatView = el.dataset.view; applyChatView(); }
        else if (action === "playCasino") { event.preventDefault(); playCasino(el.dataset.domain); }
        else if (action === "reply") { setReplyDraft({id: Number(el.dataset.id), name: el.dataset.name || "member"}); }
        else if (action === "cancelReply") setReplyDraft(null);
        else if (action === "mention") insertMention(el.dataset.name || "");
        else if (action === "sharePicker") openSharePicker();
        else if (action === "shareLink") shareSavedLink(el);
        else if (action === "report") reportMessage(el);
        else if (action === "manageBoosts") {
            const box = document.getElementById("bc-my-boosts");
            if (box) box.scrollIntoView({behavior: "smooth", block: "start"});
        }
        else if (action === "managePromos") {
            const box = document.getElementById("bc-my-promos");
            if (box) { box.scrollIntoView({behavior: "smooth", block: "start"}); box.style.boxShadow = "0 0 0 2px #8b6bff"; setTimeout(() => { box.style.boxShadow = ""; }, 1600); }
        }
        else if (action === "walletFilter") {
            walletFilter = el.dataset.kind || "all";
            const panel = $('[data-bc-panel="wallet"]');
            if (panel && walletView) paintWallet(panel);
        }
        else if (action === "findCasino") {
            event.preventDefault();
            const domain = el.dataset.domain;
            closeDrawer();
            const input = document.getElementById("domainSearchInput");
            if (input && domain) {
                input.value = domain;
                if (typeof window.applyDomainSearch === "function") window.applyDomainSearch(domain);
                else input.dispatchEvent(new Event("input", {bubbles: true}));
                input.scrollIntoView({behavior: "smooth", block: "center"});
            }
        }
    }

    async function claimWeeklyCredits() {
        if (weeklyClaiming || state?.weeklyCreditClaim?.claimed || state?.weeklyCreditClaim?.eligible === false) return;
        weeklyClaiming = true;
        if (activeTab === "home") renderHome();
        try {
            const result = await post(COMMUNITY_API, {action: "claimWeeklyCredits"});
            state.weeklyCreditClaim = result.weeklyCreditClaim;
            walletView = null;
            walletLoadedAt = 0;
            toast(result.alreadyClaimed ? "You’ve already claimed this week’s credits." : `🎉 ${num(result.weeklyCreditClaim?.credits || 20)} weekly credits added!`, result.alreadyClaimed ? "ok" : "xp");
            loadState(true).catch(() => {});
        } catch (error) {
            toast(error.message || "Could not claim weekly credits.", "bad");
        } finally {
            weeklyClaiming = false;
            if (activeTab === "home") renderHome();
        }
    }

    /* ---------- boot ---------- */

    function boot() {
        const button = document.getElementById("communityButton");
        if (button) {
            button.addEventListener("click", event => {
                if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey) return;
                event.preventDefault();
                if (typeof window.closeSideDrawerBeforeAction === "function") window.closeSideDrawerBeforeAction();
                openDrawer("home");
            });
        }
        document.querySelectorAll("[data-open-community]").forEach(el => el.addEventListener("click", event => {
            event.preventDefault();
            if (typeof window.closeSideDrawerBeforeAction === "function") window.closeSideDrawerBeforeAction();
            openDrawer(el.dataset.openCommunity || "home");
        }));
        window.bplOpenCommunity = openDrawer;
        window.BPLCommunity = {
            openProfile,
            refresh() { lastPulseKey = ""; loadPulse(); ranksLoadedAt = 0; },
        };
        bootHub();
        bootBadges();
        bootProfiles();

        const legacyHash = {"#view-live": "chat", "#view-links": "links", "#view-ranks": "ranks", "#view-earn": "share"}[location.hash];
        const requested = new URLSearchParams(location.search).get("community") ?? legacyHash ?? null;
        if (requested !== null) {
            openDrawer(TABS.includes(requested) ? requested : "home");
        } else {
            const idle = window.requestIdleCallback || (cb => setTimeout(cb, 1200));
            idle(() => loadState().catch(() => {}), {timeout: 4000});
        }
        document.addEventListener("visibilitychange", () => {
            if (!document.hidden && chatTimer) pollChat();
            if (!document.hidden && bulkImport.id && !bulkIsTerminal()) scheduleBulkPoll(0);
        });
        chatDockQuery.addEventListener("change", syncChatDock);
        bindChatKeyboard();
    }

    function bindChatKeyboard() {
        const viewport = window.visualViewport;
        if (!viewport) return;
        const mobile = window.matchMedia("(max-width: 1199px)");
        const place = () => {
            const panel = drawer?.querySelector(".bc-drawer");
            if (!panel) return;
            const typing = mobile.matches && document.activeElement?.matches?.("[data-bc-form=chat] input");
            if (!typing) {
                panel.style.top = "";
                panel.style.bottom = "";
                panel.style.height = "";
                return;
            }
            panel.style.top = `${Math.max(0, Math.round(viewport.offsetTop))}px`;
            panel.style.bottom = "auto";
            panel.style.height = `${Math.max(280, Math.round(viewport.height))}px`;
        };
        viewport.addEventListener("resize", place);
        document.addEventListener("focusin", event => {
            if (event.target?.matches?.("[data-bc-form=chat] input")) requestAnimationFrame(place);
        });
        document.addEventListener("focusout", event => {
            if (event.target?.matches?.("[data-bc-form=chat] input")) setTimeout(place, 60);
        });
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
    else boot();
})();

;
/* Glass domain cards: each card gets a blurred copy of its own favicon
   (span.card-fav-bg, styled in homepage-v2.css). Follows the icon's lazy src,
   so nothing extra is fetched. Wallet (bonus) cards also get --glass set to
   the favicon's main colour so their border/glow/tiles match it.
   Added 2026-10-30. */
(function(){
  function tintFrom(img){
    try{
      var n=20, c=document.createElement('canvas'); c.width=n; c.height=n;
      var x=c.getContext('2d',{willReadFrequently:true}); x.drawImage(img,0,0,n,n);
      var d=x.getImageData(0,0,n,n).data, r=0,g=0,b=0,w=0;
      for(var i=0;i<d.length;i+=4){
        if(d[i+3]<128) continue;
        var R=d[i],G=d[i+1],B=d[i+2],mx=Math.max(R,G,B),mn=Math.min(R,G,B);
        var sat=mx?(mx-mn)/mx:0; if(mx<40||sat<0.25) continue;
        var k=sat*sat; r+=R*k; g+=G*k; b+=B*k; w+=k;
      }
      if(w<0.5) return null;
      r/=w; g/=w; b/=w;
      // normalise to a bright, saturated glow colour
      var mx2=Math.max(r,g,b), mn2=Math.min(r,g,b), l=(mx2+mn2)/510, h=0, s=0, dd=(mx2-mn2)/255;
      if(dd>0){ s=dd/(1-Math.abs(2*l-1)||1);
        if(mx2===r) h=((g-b)/(mx2-mn2))%6; else if(mx2===g) h=(b-r)/(mx2-mn2)+2; else h=(r-g)/(mx2-mn2)+4; h*=60; if(h<0) h+=360; }
      return 'hsl('+Math.round(h)+' '+Math.round(Math.max(s,0.55)*100)+'% 62%)';
    }catch(e){ return null; }
  }
  function applyTint(card,img){
    var t=tintFrom(img);
    if(t) card.style.setProperty('--fav-glass',t); else card.style.removeProperty('--fav-glass');
  }
  function decorate(){
    // Promoted strip cards: same blurred-favicon glass (span.promoted-fav-bg).
    document.querySelectorAll('a.promoted-card').forEach(function(card){
      var img=card.querySelector('img.promoted-favicon'); if(!img) return;
      var src=img.getAttribute('src'); if(!src) return;
      var bg=card.querySelector(':scope > .promoted-fav-bg');
      if(!bg){ bg=document.createElement('span'); bg.className='promoted-fav-bg'; bg.setAttribute('aria-hidden','true'); card.insertBefore(bg,card.firstChild); }
      if(bg.dataset.src!==src){ bg.dataset.src=src; bg.style.setProperty('--fav','url("'+src.replace(/"/g,'%22')+'")'); }
    });
    document.querySelectorAll('a.card').forEach(function(card){
      if(card.closest('#resultsBody')) return;
      var img=card.querySelector('img.icon'); if(!img) return;
      var src=img.getAttribute('src'); if(!src) return;
      var bg=card.querySelector(':scope > .card-fav-bg');
      if(!bg){ bg=document.createElement('span'); bg.className='card-fav-bg'; bg.setAttribute('aria-hidden','true'); card.insertBefore(bg,card.firstChild); }
      if(bg.dataset.src!==src){
        bg.dataset.src=src; bg.style.setProperty('--fav','url("'+src.replace(/"/g,'%22')+'")');
        if(card.classList.contains('wallet-card')){
          if(img.complete&&img.naturalWidth) applyTint(card,img);
          else img.addEventListener('load',function(){ if(img.getAttribute('src')===src) applyTint(card,img); },{once:true});
        }
      }
    });
  }
  decorate();
  var queued=false;
  new MutationObserver(function(){ if(queued) return; queued=true; requestAnimationFrame(function(){ queued=false; decorate(); }); })
    .observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['src']});
})();
