/* Best Pokies List — Community drawer "Reports" tab: payout reports + scam reports.
   Rendered into the drawer panel by homepage-community.js (window.bplReportsTab).
   Everything members send is checked by the admin before it shows. Added 2026-10-31. */
(() => {
    "use strict";

    const API = "api/community-reports.php";
    const MAX_MB = 8;
    const IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"];
    let feed = null;
    let feedAt = 0;
    let feedLoading = null;
    let domains = null;
    let domainsLoading = null;
    let view = "feed";
    let panelRef = null;

    const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]));
    const money = value => { const n = Number(value || 0); return "$" + n.toLocaleString("en-AU", {minimumFractionDigits: Number.isInteger(n) ? 0 : 2, maximumFractionDigits: 2}); };

    function timeAgo(ts) {
        if (!ts) return "";
        const diff = Math.max(0, Date.now() / 1000 - ts);
        if (diff < 60) return "just now";
        if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
        if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
        if (diff < 86400 * 7) return `${Math.floor(diff / 86400)}d ago`;
        return new Date(ts * 1000).toLocaleDateString("en-AU", {day: "numeric", month: "short"});
    }

    async function call(body, isForm) {
        const response = await fetch(API, {
            method: "POST",
            credentials: "same-origin",
            cache: "no-store",
            headers: isForm ? {} : {"Content-Type": "application/json"},
            body: isForm ? body : JSON.stringify(body),
        });
        let data;
        try { data = await response.json(); } catch { data = {ok: false, error: "Unexpected server response."}; }
        if (!response.ok || data?.ok === false) {
            const error = new Error(data?.error || `Request failed (${response.status})`);
            error.status = response.status;
            throw error;
        }
        return data;
    }

    function loadFeed(force) {
        if (feedLoading) return feedLoading;
        if (!force && feed && Date.now() - feedAt < 60000) return Promise.resolve(feed);
        feedLoading = call({action: "feed"})
            .then(data => { feed = data; feedAt = Date.now(); return data; })
            .finally(() => { feedLoading = null; });
        return feedLoading;
    }

    function loadDomains() {
        if (domains) return Promise.resolve(domains);
        if (domainsLoading) return domainsLoading;
        domainsLoading = call({action: "domains"})
            .then(data => { domains = Array.isArray(data.domains) ? data.domains : []; return domains; })
            .finally(() => { domainsLoading = null; });
        return domainsLoading;
    }

    function shellHtml() {
        return `
            <div class="bc-card rp-intro">
                <h3>🧾 Reports</h3>
                <p class="bc-explain">Got paid? Got scammed? Tell the community — every report is checked by the admin before it shows.</p>
                <div class="bc-seg rp-seg" role="tablist" aria-label="Reports">
                    <button type="button" class="bc-seg-btn" data-rp-view="feed">📰 Feed</button>
                    <button type="button" class="bc-seg-btn" data-rp-view="payout">💸 Got paid</button>
                    <button type="button" class="bc-seg-btn" data-rp-view="scam">⚠️ Report scam</button>
                </div>
            </div>
            <div data-rp-body></div>`;
    }

    function signInCard(what) {
        return `<div class="bc-card bc-signin">
            <h3>Sign in to ${esc(what)}</h3>
            <p class="bc-small bc-muted">Use your Bonus Fetcher phone number and password. Reports are checked by the admin before anything shows.</p>
            <a class="bc-btn bc-btn-primary bc-btn-block" href="bonus-fetch.php">Sign in with Bonus Fetcher</a>
        </div>`;
    }

    function optionsHtml(map, placeholder) {
        return `<option value="">${esc(placeholder)}</option>` +
            Object.entries(map || {}).map(([value, label]) => `<option value="${esc(value)}">${esc(label)}</option>`).join("");
    }

    function domainList() {
        return `<datalist id="rpDomains">${(domains || []).map(d => `<option value="${esc(d)}"></option>`).join("")}</datalist>`;
    }

    function feedHtml(data) {
        const scams = data.scams || [];
        const payouts = data.payouts || [];
        const paying = data.paying || [];
        const mine = data.mine || [];
        const statusLabel = {pending: "⏳ Waiting for review", approved: "✅ Approved", rejected: "✗ Not approved", confirmed: "✅ Confirmed", dismissed: "✗ Dismissed"};
        let html = "";
        if (mine.length) {
            html += `<div class="bc-card"><h3>Your reports</h3><ul class="rp-list">${mine.map(m => `
                <li><span><b>${esc(m.domain)}</b> <small class="bc-muted">${m.kind === "payout" ? "Payout" : "Scam"} · ${esc(timeAgo(m.ts))}</small></span>
                <span class="rp-status rp-status-${esc(m.status)}">${esc(statusLabel[m.status] || m.status)}</span></li>`).join("")}</ul></div>`;
        }
        html += `<div class="bc-card rp-scams"><h3>🚫 Confirmed scam casinos</h3>`;
        if (!scams.length) html += `<p class="bc-small bc-muted">No casinos are marked as scams right now.</p>`;
        else html += `<ul class="rp-list">${scams.map(s => `
            <li class="rp-scam-row"><span><b>${esc(s.domain)}</b> <span class="rp-scam-tag">SCAM</span>
            <small class="bc-muted">${s.reasons.length ? s.reasons.map(r => `${esc(r.label)}${r.count > 1 ? ` ×${r.count}` : ""}`).join(" · ") : "Confirmed by the admin"}${s.note ? ` — ${esc(s.note)}` : ""}</small></span>
            <small class="bc-muted">${esc(timeAgo(s.markedAt))}</small></li>`).join("")}</ul>`;
        html += `</div>`;
        if (paying.length) {
            html += `<div class="bc-card"><h3>✅ Paying casinos</h3><p class="bc-small bc-muted">Casinos with payouts confirmed by members (checked by the admin).</p>
                <ul class="rp-list">${paying.map(p => `<li><span><b>${esc(p.domain)}</b> <small class="bc-muted">last ${esc(timeAgo(p.last))}</small></span>
                <span class="rp-paid">✓ ${p.count} payout${p.count === 1 ? "" : "s"}</span></li>`).join("")}</ul></div>`;
        }
        html += `<div class="bc-card"><h3>💸 Latest payouts</h3>`;
        if (!payouts.length) html += `<p class="bc-small bc-muted">No payout reports yet. Got paid? Be the first — tap “Got paid”.</p>`;
        else html += `<ul class="rp-list rp-payouts">${payouts.map(p => `
            <li><span class="rp-main"><b>${esc(p.domain)}</b> <span class="rp-amt">${esc(money(p.amount))}</span>
            <small class="bc-muted">${p.time ? `⏱ ${esc(p.time)} · ` : ""}${esc(p.by?.name || "Community member")} · ${esc(timeAgo(p.ts))}</small>
            ${p.note ? `<small class="rp-note">“${esc(p.note)}”</small>` : ""}</span></li>`).join("")}</ul>`;
        html += `</div>`;
        return html;
    }

    function payoutFormHtml(data) {
        const o = data.options || {};
        const l = data.limits || {};
        return `<form class="bc-card rp-form" data-rp-form="payout" novalidate>
            <h3>💸 Report a payout</h3>
            <p class="bc-small bc-muted">Show the community which casinos really pay. Add a screenshot of the money arriving (bank app, PayID or crypto wallet). Hide anything private first.</p>
            <label class="bc-field">Casino<input name="domain" list="rpDomains" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Start typing a casino…" required></label>
            <label class="bc-field">Amount paid (AUD)<input name="amount" inputmode="decimal" placeholder="e.g. 250" required></label>
            <label class="bc-field">How long did it take?<select name="payoutTime" required>${optionsHtml(o.times, "Choose…")}</select></label>
            <label class="bc-field">Note (optional)<textarea name="note" maxlength="300" placeholder="Anything helpful, e.g. withdrew after a bonus, KYC asked for ID"></textarea></label>
            <label class="bc-field">Screenshot (required)<input type="file" name="screenshot" accept="image/jpeg,image/png,image/webp,image/gif" required></label>
            <p class="bc-small bc-muted">Images only, up to ${esc(l.maxImageMb || MAX_MB)} MB. Up to ${esc(l.payoutPerDay || 3)} payout reports a day. Screenshots are only seen by the admin.</p>
            <div class="rp-msg" data-rp-msg role="status" aria-live="polite"></div>
            <button type="submit" class="bc-btn bc-btn-primary bc-btn-block">Send for review</button>
            ${domainList()}
        </form>`;
    }

    function scamFormHtml(data) {
        const o = data.options || {};
        const l = data.limits || {};
        return `<form class="bc-card rp-form rp-form-scam" data-rp-form="scam" novalidate>
            <h3>⚠️ Report a scam casino</h3>
            <p class="bc-small bc-muted">Didn't get paid? Let the community know. The admin checks every report, and a casino is only marked as a scam once it's confirmed.</p>
            <label class="bc-field">Casino domain<input name="domain" list="rpDomains" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Pick from the list or type the domain" required></label>
            <label class="bc-field">What happened?<select name="reason" required>${optionsHtml(o.reasons, "Choose…")}</select></label>
            <label class="bc-field">Details<textarea name="details" maxlength="2000" placeholder="What happened, when, and how much was involved" required></textarea></label>
            <label class="bc-field">Proof screenshots (optional, up to ${esc(l.scamImages || 3)})<input type="file" name="proof[]" accept="image/jpeg,image/png,image/webp,image/gif" multiple></label>
            <p class="bc-small bc-muted">Images only, up to ${esc(l.maxImageMb || MAX_MB)} MB each. Up to ${esc(l.scamPerDay || 3)} scam reports a day.</p>
            <div class="rp-msg" data-rp-msg role="status" aria-live="polite"></div>
            <button type="submit" class="bc-btn bc-btn-block rp-btn-danger">Send report for review</button>
            ${domainList()}
        </form>`;
    }

    function renderBody() {
        const panel = panelRef;
        if (!panel) return;
        const body = panel.querySelector("[data-rp-body]");
        if (!body) return;
        panel.querySelectorAll("[data-rp-view]").forEach(btn => {
            const on = btn.dataset.rpView === view;
            btn.classList.toggle("bc-seg-on", on);
            btn.setAttribute("aria-selected", on ? "true" : "false");
        });
        if (!feed) { body.innerHTML = `<div class="bc-loading">Loading…</div>`; return; }
        if (view === "feed") { body.innerHTML = feedHtml(feed); return; }
        if (!feed.loggedIn) { body.innerHTML = signInCard(view === "payout" ? "report a payout" : "report a scam"); return; }
        if (body.querySelector(`[data-rp-form="${view}"]`)) return; /* keep what the member typed */
        body.innerHTML = view === "payout" ? payoutFormHtml(feed) : scamFormHtml(feed);
        if (!domains) loadDomains().then(() => {
            const form = body.querySelector("[data-rp-form]");
            const old = form?.querySelector("#rpDomains");
            if (old) old.outerHTML = domainList();
        }).catch(() => {});
    }

    function setMsg(form, text, kind) {
        const el = form.querySelector("[data-rp-msg]");
        if (!el) return;
        el.textContent = text || "";
        el.className = "rp-msg" + (kind ? ` rp-msg-${kind}` : "");
    }

    function checkFiles(files, max, required) {
        const list = Array.from(files || []);
        if (required && !list.length) return "Add a screenshot of the payout.";
        if (list.length > max) return `Add up to ${max} screenshot${max === 1 ? "" : "s"}.`;
        for (const f of list) {
            if (!IMAGE_TYPES.includes(f.type)) return "Screenshots must be JPG, PNG, WebP or GIF images.";
            if (f.size > MAX_MB * 1048576) return `Each screenshot must be under ${MAX_MB} MB.`;
        }
        return "";
    }

    async function submit(form) {
        const kind = form.dataset.rpForm;
        const button = form.querySelector("button[type=submit]");
        if (button.disabled) return;
        const f = form.elements;
        let problem = "";
        if (!String(f.domain.value || "").trim()) problem = kind === "payout" ? "Pick a casino from the list." : "Enter the casino domain.";
        else if (kind === "payout" && !String(f.amount.value || "").trim()) problem = "Enter the amount you were paid.";
        else if (kind === "payout" && !f.payoutTime.value) problem = "Choose how long the payout took.";
        else if (kind === "scam" && !f.reason.value) problem = "Choose what happened.";
        else if (kind === "scam" && String(f.details.value || "").trim().length < 20) problem = "Please describe what happened (at least 20 characters).";
        else problem = kind === "payout" ? checkFiles(f.screenshot.files, 1, true) : checkFiles(f["proof[]"].files, feed?.limits?.scamImages || 3, false);
        if (problem) { setMsg(form, problem, "bad"); return; }
        const data = new FormData(form);
        data.set("action", kind === "payout" ? "submitPayout" : "submitScam");
        button.disabled = true;
        const label = button.textContent;
        button.textContent = "Sending…";
        setMsg(form, "", "");
        try {
            const result = await call(data, true);
            form.reset();
            setMsg(form, result.message || "Sent for review.", "good");
            loadFeed(true).catch(() => {});
        } catch (error) {
            setMsg(form, error.status === 401 ? "Please sign in again, then try once more." : error.message, "bad");
        } finally {
            button.disabled = false;
            button.textContent = label;
        }
    }

    function wire(panel) {
        if (panel.dataset.rpWired === "1") return;
        panel.dataset.rpWired = "1";
        panel.addEventListener("click", event => {
            const tab = event.target.closest("[data-rp-view]");
            if (!tab) return;
            event.stopPropagation();
            view = tab.dataset.rpView;
            if (view === "feed") loadFeed(false).then(renderBody).catch(showError);
            renderBody();
        });
        panel.addEventListener("submit", event => {
            const form = event.target.closest("[data-rp-form]");
            if (!form) return;
            event.preventDefault();
            submit(form);
        });
    }

    function showError(error) {
        const body = panelRef?.querySelector("[data-rp-body]");
        if (body) body.innerHTML = `<div class="bc-empty">⚠️ ${esc(error?.message || "Reports are unavailable right now.")}<br><button type="button" class="bc-btn" data-rp-view="${esc(view)}">Try again</button></div>`;
    }

    function render(panel, ctx) {
        if (!panel) return;
        panelRef = panel;
        if (!panel.querySelector("[data-rp-body]")) panel.innerHTML = shellHtml();
        wire(panel);
        if (ctx && feed && Boolean(ctx.loggedIn) !== Boolean(feed.loggedIn)) feedAt = 0;
        renderBody();
        loadFeed(false).then(data => {
            const typing = view !== "feed" && panel.querySelector("[data-rp-form]");
            if (!typing) renderBody();
            else if (!data.loggedIn) renderBody();
            return data;
        }).catch(showError);
    }

    window.bplReportsTab = {render, show(v) { if (["feed", "payout", "scam"].includes(v)) view = v; }};
})();
